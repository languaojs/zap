document.addEventListener('DOMContentLoaded', () => {

    // 1. DOM Formatting Tweaks

    document.querySelectorAll('.code').forEach((el) => {
        el.classList.add('small', 'text-red-400');
    });

    document.querySelectorAll('.title').forEach((title) => {
        title.classList.add('text-blue-400', 'mb-3');
    });


    // 2. Viewport / ScrollSpy Navigation

    const headersId = document.querySelectorAll('#article-content div[id]');
    const navLinks = document.querySelectorAll('#sidebar-nav .nav-link');

    function isInViewport(element) {
        const rect = element.getBoundingClientRect();

        return (
            rect.top >= 0 &&
            rect.top <= (
                window.innerHeight ||
                document.documentElement.clientHeight
            ) / 2
        );
    }

    window.addEventListener('scroll', () => {
        headersId.forEach((el) => {

            if (isInViewport(el)) {

                const id = el.getAttribute('id');

                navLinks.forEach((nav) => {

                    if (nav.getAttribute('href') === `#${id}`) {

                        nav.classList.add(
                            'border-start',
                            'border-danger',
                            'border-2',
                            'ps-2'
                        );

                    } else {

                        nav.classList.remove(
                            'border-start',
                            'border-danger',
                            'border-2',
                            'ps-2'
                        );

                    }

                });
            }

        });
    });


    // 3. Search Box Navigation

    const searchInput = document.getElementById('docsSearch');

    if (searchInput) {

        const docsMap = JSON.parse(
            searchInput.dataset.routes || '{}'
        );

        function navigateToDoc() {

            const query = searchInput.value.trim();

            if (docsMap[query]) {
                window.location.href = docsMap[query];
            }

        }

        searchInput.addEventListener('input', navigateToDoc);
        searchInput.addEventListener('change', navigateToDoc);
    }

    // 4. Code Indentation Trimming

    // trimCodeIndentation();


    // 5. Syntax Highlighting

    if (typeof hljs !== 'undefined') {
        hljs.highlightAll();
    }

});


function trimCodeIndentation() {

    document.querySelectorAll('pre code').forEach((block) => {

        let lines = block.textContent
            .replace(/\r\n/g, '\n')
            .replace(/\r/g, '\n')
            .split('\n');


        // Remove empty lines from the beginning

        while (lines.length && lines[0].trim() === '') {
            lines.shift();
        }


        // Remove empty lines from the end

        while (lines.length && lines[lines.length - 1].trim() === '') {
            lines.pop();
        }


        if (!lines.length) {
            return;
        }


        // Find the smallest indentation

        let minIndent = Infinity;

        lines.forEach((line) => {

            // Ignore completely empty lines

            if (line.trim() === '') {
                return;
            }

            // Convert tabs to four spaces for measurement

            const expanded = line.replace(/\t/g, '    ');

            const match = expanded.match(/^ */);

            if (match) {
                minIndent = Math.min(
                    minIndent,
                    match[0].length
                );
            }

        });


        // Remove the common indentation

        if (minIndent > 0 && minIndent !== Infinity) {

            lines = lines.map((line) => {

                let remaining = minIndent;
                let index = 0;

                while (
                    index < line.length &&
                    remaining > 0
                ) {

                    if (line[index] === ' ') {

                        remaining--;
                        index++;

                    } else if (line[index] === '\t') {

                        // Treat tab as four spaces

                        remaining -= 4;
                        index++;

                    } else {

                        break;

                    }

                }

                return line.substring(index);

            });

        }


        // Put the cleaned code back

        block.textContent = lines.join('\n');


        // Preserve whitespace

        block.style.whiteSpace = 'pre';

    });

}