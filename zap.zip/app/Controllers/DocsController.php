<?php

namespace Zap\App\Controllers;

use Zap\Core\Base\BaseController;
use Zap\Core\Http\Request;
use Zap\Core\Utils\Container;
use Zap\Core\Utils\SessionManager;
use Zap\Core\Utils\File;
use Zap\Core\Utils\Flasher;
use Zap\Core\Utils\ArrayEngine;

class DocsController extends BaseController
{

    private function getRouterMaps(array $docs){
        $routerUrlMap = [];
        foreach ($docs as $routeName => $meta) {
            $url = route($routeName);
            if (isset($meta['title'])) {
                $routerUrlMap[$meta['title']] = $url;
            }
            if (!empty($meta['keywords']) && is_array($meta['keywords'])) {
                foreach ($meta['keywords'] as $keyword) {
                    $routerUrlMap[$keyword] = $url;
                }
            }
        }
        return $routerUrlMap;
    }

    public function index()
    {
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Introduction',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => '',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
                'routes' => $docs,
            'docsTitle' => 'Getting Started',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'None',
                'route' => '',
            ],
            'next' => [
                'title' => 'Configuration',
                'route' => route('docs.basic.configuration')
            ],
        ];


        $html = $this->render('docs/index', $data);
        return $this->response($html);
    }

    public function basicConfiguration()
    {
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Basic Configuration',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => '',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Configuration',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Getting Started',
                'route' => route('docs.index'),
            ],
            'next' => [
                'title' => 'Routing',
                'route' => route('docs.routing')
            ],
        ];


        $html = $this->render('docs/basic-configuration', $data);
        return $this->response($html);
    }

    public function routing()
    {
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Routing',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => '',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Routing',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Configuration',
                'route' => route('docs.basic.configuration'),
            ],
            'next' => [
                'title' => 'Session Manager',
                'route' => route('docs.session')
            ],
        ];
        $html = $this->render('docs/routing', $data);
        return $this->response($html);
    }

    public function sessionManager()
    {
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $sessionMgr = Container::getInstance()->make(SessionManager::class);
        $testSessionData = [
            'text' => 'This is a test session data'
        ];
        $sessionName = 'testSession';
        $sessionMgr->set($sessionName, $testSessionData);
        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Session Manager',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => '',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Session Manager',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Routing',
                'route' => route('docs.routing'),
            ],
            'next' => [
                'title' => 'File',
                'route' => route('docs.file')
            ],
            'validSessionData' => $sessionMgr->get($sessionName),
            'invalidSessionData' => $_SESSION[$sessionName],
            'sessionName' => $sessionName
        ];
        $html = $this->render('docs/session-manager', $data);
        $sessionMgr->unset($sessionName);
        return $this->response($html);
    }

    public function file(File $file)
    {
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);


        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | File',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => '',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'File',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Session Manager',
                'route' => route('docs.session'),
            ],
            'next' => [
                'title' => 'Security',
                'route' => route('docs.security')
            ],
            'fileList' => $file::list_files('/app/Controllers'),
            'testLog' => $file::get(BASE_PATH . '/storage/logs/test.log')
        ];
        $html = $this->render('docs/file', $data);
        return $this->response($html);
    }

    public function download(Request $request)
    {
        $filePath = $request->input('file_path') ?? '';
        $customFilename = $request->input('file_name') ?? null;

        if ($filePath === '') {
            return $this->response('No file path provided.');
        }

        return File::download($filePath, $customFilename);
    }

    public function security()
    {
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Security',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Security',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'File',
                'route' => route('docs.file')
            ],
            'next' => [
                'title' => 'Validator',
                'route' => route('docs.validator')
            ],
        ];

        $html = $this->render('docs/security', $data);
        return $this->response($html);
    }

    public function validator()
    {
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Validator',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Validator',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Security',
                'route' => route('docs.security')
            ],
            'next' => [
                'title' => 'Flasher',
                'route' => route('docs.flasher')
            ],
        ];
        $html = $this->render('docs/validator', $data);
        return $this->response($html);
    }

    public function flasher(Flasher $flasher){
        // $flasher->set('info', 'test', 'message');
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Flasher',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Flasher',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Validator',
                'route' => route('docs.validator')
            ],
            'next' => [
                'title' => 'Hasher',
                'route' => route('docs.hasher')
            ],
        ];
        $html = $this->render('docs/flasher', $data);
        return $this->response($html);
    }

    public function hasher(){
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Hasher',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Hasher',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Flasher',
                'route' => route('docs.flasher')
            ],
            'next' => [
                'title' => 'Array Engine',
                'route' => route('docs.arrayengine')
            ],
        ];
        $html = $this->render('docs/hasher', $data);
        return $this->response($html);
    }

    public function arrayEngine(){
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Array Engine',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Array Engine',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Hasher',
                'route' => route('docs.hasher')
            ],
            'next' => [
                'title' => 'Database',
                'route' => route('docs.database')
            ],
        ];
        $html = $this->render('docs/arrayengine', $data);
        return $this->response($html);
    }

    public function database(){
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Database',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Database',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Array Engine',
                'route' => route('docs.arrayengine')
            ],
            'next' => [
                'title' => 'CLI',
                'route' => route('docs.cli')
            ],
            
        ];
        $html = $this->render('docs/database', $data);
        return $this->response($html);
    }

    public function cli(){
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | CLI',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'CLI',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Database',
                'route' => route('docs.database')
            ],
            'next' => [
                'title' => 'Litewire',
                'route' => route('docs.litewire')
            ],
            
        ];
        $html = $this->render('docs/cli', $data);
        return $this->response($html);
    }

    public function litewire(){
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'litewire', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Litewire',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Litewire',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'CLI',
                'route' => route('docs.cli')
            ],
            'next' => [
                'title' => 'Vite',
                'route' => route('docs.vite')
            ],
            
        ];
        $html = $this->render('docs/litewire', $data);
        return $this->response($html);
    }

    public function vite(){
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Vite',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Vite',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Litewire',
                'route' => route('docs.litewire')
            ],
            'next' => [
                'title' => 'Asset Management',
                'route' => route('docs.assetsmanagement')
            ],
            
        ];
        $html = $this->render('docs/vite', $data);
        return $this->response($html);
    }

    public function assetsManagement(){
        $docs = config('docs');
        $routerUrlMap = $this->getRouterMaps($docs);

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos', 'docs']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP | Assets Management',
            '_description' => "",
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            // 'navbar' => 'navbars.docs-navbar',
            'footer' => 'footers.docs-footer',
            'routes' => $docs,
            'docsTitle' => 'Assets Management',
            'routerUrlMap' => $routerUrlMap,
            'prev' => [
                'title' => 'Vite',
                'route' => route('docs.vite')
            ],
            'next' => [
                'title' => 'None',
                'route' => ''
            ],
            
        ];
        $html = $this->render('docs/assets-management', $data);
        return $this->response($html);
    }
}
