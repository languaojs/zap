<?php

namespace Zap\App\Controllers;

use Zap\Core\Base\BaseController;
use Zap\Core\Http\Request;
use Zap\Core\Utils\File;
use Zap\Core\Utils\Security;
use Zap\Core\Utils\Validator;

class HomeController extends BaseController
{
    
    public function index(Request $request)
    {       

        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos']),
            // 'vite' => ['resources/css/app.css', 'resources/js/app.js'],
            '_title' => 'Zap PHP',
            '_description' => "" ,
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            'db' => config('database')
            // 'navbar' => '',
            // 'footer' => '',
        ];


        $html = $this->render('home/index', $data);
        return $this->response($html);
    }

    

    public function upload(Request $request, Security $security){
        $security->get_instance();
        if(!$security->validate_request()){
            return $this->json(['error'=>'Invalid token'], 403);
        }
        $file = new File;
        $upload_path = $request->input('upload_path');
        $file_name = $request->input('file_name', null);
        
        $encrypt_name = ($file_name === null);
        
        // if($file_name !== null){
        //     $encrypt_name = false;
        // }else{
        //     $encrypt_name = true;
        // }

        $upload_config = [
            'upload_path' => BASE_PATH . $upload_path,
            'max_size' => $request->input('maxsize'),
            'allowed_types' => ['jpg', 'png'],
            'encrypt_name', $encrypt_name
        ];

        $file->init_upload($upload_config);
        $file->do_upload('file', $file_name);
        return $this->json($file->get_upload_errors());
    }

    public function testPhpX(Request $request, Security $security){
        if(!$request->input('comment')) {
            $html = $this->render('home/test');
            return $this->response($html);
        }else{
            $security::get_instance();
            if(!$security->validate_request()){
                return $this->json(['error'=>'Invalid token'], 403);
            }

            $data = [
                'comment' => $request->input('comment')
            ];
            $html = $this->render('home/test2', $data);
            return $this->response($html);
        }
    }

    public function search(Request $request)
    {
        $query = $request->input('q', '');
        $search = $this->model('HomeModel')->searchUser($query);
        $data = [
            'users' => $search
        ];

        $html = $this->render('home/search', $data);
        return $this->response($html);
    }

    public function login(Request $request)
    {
        if($request->method()==='GET'){
            $html = $this->render('components/login-form', []);
            return $this->response($html);
        }

        $rules = [
            'name' => 'required|min:5',
            'email' => 'required|email|min:10'
        ];

        $validator = Validator::make($request->all(), $rules);
     
        if($validator->fails()){
            $data = [
                'errors' => $validator->errors(),
                'old' => $request->all(),
            ];

            $html = $this->render('components/login-form', $data);
            return $this->response($html);
        }

        $data = ['success' => 'Login success'];
        $html = $this->render('components/login-success', $data);
        return $this->response($html);
    }
}
