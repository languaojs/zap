<?php

namespace Zap\App\Models;

use Zap\Core\Base\BaseModel;
use Zap\Core\Utils\Container;
use Zap\Core\Db\Database;

class HomeModel extends BaseModel
{
    protected $connection;

    public function __construct()
    {
        $this->connection = Container::getInstance()->make(Database::class);
        parent::__construct();
    }
    public function testBuilder()
    {
        $builder = $this->builder();
        $data = [
            'email' => 'test@mail.com',
            'name' => 'Test Zap',
            'id' => 1
        ];

        $query = $builder->select(
            'products',
            ['products.name', 'categories.title', 'products.price'],
            [
                'products.stock' => ['>' => 0],
                '_or' => [
                    'products.price' => ['<' => 50000],
                    'products.is_featured' => 1
                ]
            ],
            [
                'join' => [
                    ['categories', 'products.category_id', 'categories.id', 'INNER']
                ]
            ]
        );

        $query2 = $builder->delete('users', ['_or' => [
            'status' => 'inactive',
            'score' => ['<' => 12]
        ]]);
        return $query;
    }

    public function searchUser(string $name){

        $trimmed = trim($name);
        if(empty($trimmed)){
            return [];
        };

        $searchTerm = '%'.$trimmed.'%';
        $search = $this->db()->query("SELECT * FROM user_profiles WHERE fullname LIKE ?", [$searchTerm])->fetchAll();
        return $search ?? [];
    }
}
