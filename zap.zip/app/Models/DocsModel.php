<?php 

namespace Zap\App\Models;

use Zap\Core\Base\BaseModel;
use Zap\Core\Utils\Container;
use Zap\Core\Db\Database;

class DocsModel extends BaseModel {

    protected mixed $connection;

    public function __construct()
    {
        $this->connection = Container::getInstance()->make(Database::class);
        parent::__construct();
    }

    public function getActiveUsers(){
        $users = $this->db()->query('SELECT * FROM user_profiles')->fetchAll();
        $users = $this->connection->query('SELECT * FROM user_profiles');
        return $users->fetchAll();
    }

    public function testBuilder(){
        $selectQuery = $this->builder()::select('users', ['name', 'email', 'status'], [], []);
        
    }

}