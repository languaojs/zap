
@extends('layouts.base')
@section('content')
    <main class="container">
        <section class="row">
            <div class="col-12">
                <div id="dashboard"></div>
            </div>
        </section>
    </main>
@endsection

@push('scripts')
    <script type="module">
        const data = {
            'name': 'Umang'
        };
        const {renderDashboard} = await import(
            window.AppConfig.baseUrl + "/frontend/pages/Dashboard.js"
        );
        renderDashboard(
            document.querySelector('#dashboard'),
            data
        );
    </script>
@endpush
