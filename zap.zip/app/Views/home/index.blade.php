@extends('layouts.base')
@section('content')
    <main class="zap-home">
        <style>
            .zap-home {
                --zap-ink: #18221f;
                --zap-muted: #68756f;
                --zap-green: #146c52;
                --zap-lime: #d5f36a;
                color: var(--zap-ink);
                background:
                    radial-gradient(ellipse at 82% 3%, rgba(213, 243, 106, .28), transparent 30rem),
                    #f7f8f4;
                overflow: hidden;
            }
            .zap-home .home-wrap { max-width: 1180px; }
            .zap-home .eyebrow {
                color: var(--zap-green);
                font-size: .76rem;
                font-weight: 700;
                letter-spacing: .16em;
                text-transform: uppercase;
            }
            .zap-home .hero {
                min-height: 650px;
                padding: 5.5rem 0 5rem;
                display: flex;
                align-items: center;
            }
            .zap-home .hero-title {
                max-width: 760px;
                font-size: clamp(3.2rem, 7vw, 6.8rem);
                font-weight: 700;
                letter-spacing: -.075em;
                line-height: .98;
            }
            .zap-home .hero-title span { color: var(--zap-green); }
            .zap-home .hero-copy {
                max-width: 570px;
                color: var(--zap-muted);
                font-size: 1.12rem;
                line-height: 1.8;
            }
            .zap-home .btn-zap {
                color: #fff;
                background: var(--zap-green);
                border: 1px solid var(--zap-green);
                border-radius: 999px;
                padding: .9rem 1.4rem;
                font-weight: 600;
            }
            .zap-home .btn-zap:hover { color: #fff; background: #105740; }
            .zap-home .btn-outline-zap {
                color: var(--zap-ink);
                border: 1px solid #cbd2cb;
                border-radius: 999px;
                padding: .9rem 1.4rem;
                font-weight: 600;
            }
            .zap-home .btn-outline-zap:hover { background: #fff; border-color: var(--zap-green); }
            .zap-home .hero-art {
                position: relative;
                min-height: 370px;
                display: grid;
                place-items: center;
            }
            .zap-home .orbit {
                width: min(360px, 75vw);
                aspect-ratio: 1;
                display: grid;
                place-items: center;
                border: 1px solid rgba(20, 108, 82, .17);
                border-radius: 50%;
                background: radial-gradient(circle, rgba(213, 243, 106, .28), rgba(255,255,255,.15) 68%);
            }
            .zap-home .orbit:before, .zap-home .orbit:after {
                position: absolute;
                content: "";
                width: min(290px, 60vw);
                aspect-ratio: 1;
                border: 1px solid rgba(20, 108, 82, .12);
                border-radius: 50%;
            }
            .zap-home .orbit:after { width: min(220px, 46vw); }
            .zap-home .logo-mark {
                z-index: 1;
                width: 148px;
                height: 148px;
                display: grid;
                place-items: center;
                border-radius: 40px;
                background: #fff;
                box-shadow: 0 24px 80px rgba(22, 57, 43, .14);
                transform: rotate(-7deg);
            }
            .zap-home .logo-mark img { width: 105px; }
            .zap-home .float-tag {
                position: absolute;
                z-index: 2;
                padding: .65rem .9rem;
                color: #29443a;
                background: rgba(255,255,255,.9);
                border: 1px solid rgba(20, 108, 82, .1);
                border-radius: 999px;
                box-shadow: 0 12px 30px rgba(22, 57, 43, .08);
                font-size: .85rem;
                font-weight: 600;
            }
            .zap-home .tag-one { top: 14%; right: 2%; }
            .zap-home .tag-two { bottom: 17%; left: 0; }
            .zap-home .section-space { padding: 6rem 0; }
            .zap-home .section-heading {
                max-width: 680px;
                font-size: clamp(2rem, 4vw, 3.4rem);
                font-weight: 650;
                letter-spacing: -.055em;
                line-height: 1.1;
            }
            .zap-home .section-copy { color: var(--zap-muted); line-height: 1.75; }
            .zap-home .feature-card {
                height: 100%;
                padding: 1.6rem;
                background: rgba(255,255,255,.8);
                border: 1px solid #e6eae3;
                border-radius: 20px;
                transition: transform .2s ease, box-shadow .2s ease;
            }
            .zap-home .feature-card:hover {
                transform: translateY(-4px);
                box-shadow: 0 18px 45px rgba(24, 54, 41, .08);
            }
            .zap-home .feature-icon {
                width: 44px;
                height: 44px;
                display: grid;
                place-items: center;
                margin-bottom: 1.3rem;
                color: var(--zap-green);
                background: #edf5e9;
                border-radius: 14px;
                font-size: 1.2rem;
            }
            .zap-home .feature-card h3 { font-size: 1.05rem; font-weight: 700; }
            .zap-home .feature-card p { margin: 0; color: var(--zap-muted); font-size: .94rem; line-height: 1.7; }
            .zap-home .feature-card a { color: inherit; text-decoration: none; }
            .zap-home .feature-card a:hover { color: var(--zap-green); }
            .zap-home .docs-panel {
                padding: clamp(2rem, 6vw, 4.5rem);
                color: #f5f8f3;
                background: #17382e;
                border-radius: 28px;
            }
            .zap-home .docs-panel .section-copy { color: #bac8bf; }
            .zap-home .docs-link {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 1rem;
                padding: 1rem 0;
                color: #f5f8f3;
                border-bottom: 1px solid rgba(255,255,255,.15);
                text-decoration: none;
            }
            .zap-home .docs-link:hover { color: var(--zap-lime); }
            .zap-home .docs-link span:last-child { color: #a9b9af; }
            .zap-home .closing {
                padding: 5rem 0;
                text-align: center;
            }
            @@media (max-width: 767.98px) {
                .zap-home .hero { min-height: auto; padding: 4rem 0 3rem; }
                .zap-home .hero-art { min-height: 320px; }
                .zap-home .section-space { padding: 4rem 0; }
            }
        </style>

        <section class="hero">
            <div class="container home-wrap">
                <div class="row align-items-center g-5">
                    <div class="col-lg-7" data-aos="fade-up" data-aos-duration="800">
                        <p class="eyebrow mb-4">A thoughtful PHP framework</p>
                        <h1 class="hero-title mb-4">Build with <span>clarity.</span><br>Ship with confidence.</h1>
                        <p class="hero-copy mb-4">Zap gives you a clean foundation for modern PHP applications: practical tools, expressive workflows, and just enough structure to stay focused on what matters.</p>
                        <div class="d-flex flex-wrap gap-3">
                            <a class="btn btn-zap" href="{{ route('docs.index') }}">Explore the documentation <i class="bi bi-arrow-up-right ms-2"></i></a>
                            <a class="btn btn-outline-zap" href="{{ route('docs.basic.configuration') }}">Get started</a>
                        </div>
                        <p class="small text-secondary mt-4 mb-0">Routing · data · security · interactive UI</p>
                    </div>
                    <div class="col-lg-5" data-aos="zoom-in" data-aos-duration="1000" data-aos-delay="150">
                        <div class="hero-art">
                            <div class="orbit">
                                <div class="logo-mark">
                                    <img src="{{ service('\Zap\Core\Utils\File')->get_media('svgs/zap-logo.svg') }}" alt="Zap logo">
                                </div>
                            </div>
                            <span class="float-tag tag-one"><i class="bi bi-lightning-charge-fill me-2"></i>Fast to build</span>
                            <span class="float-tag tag-two"><i class="bi bi-layers-fill me-2"></i>Ready to grow</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section-space pt-0">
            <div class="container home-wrap">
                <div class="row align-items-end g-4 mb-4">
                    <div class="col-lg-7" data-aos="fade-up">
                        <p class="eyebrow mb-3">The toolkit</p>
                        <h2 class="section-heading mb-0">Everything you need to move from idea to application.</h2>
                    </div>
                    <div class="col-lg-5" data-aos="fade-up" data-aos-delay="100">
                        <p class="section-copy mb-0">The documentation walks through the essentials and the batteries included, with focused guides for each part of your stack.</p>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6 col-lg-4" data-aos="fade-up">
                        <article class="feature-card">
                            <div class="feature-icon"><i class="bi bi-signpost-split"></i></div>
                            <h3><a href="{{ route('docs.routing') }}">Routing & middleware <i class="bi bi-arrow-up-right small"></i></a></h3>
                            <p>Define expressive routes, work with HTTP methods and named URLs, and protect endpoints with middleware.</p>
                        </article>
                    </div>
                    <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="75">
                        <article class="feature-card">
                            <div class="feature-icon"><i class="bi bi-database"></i></div>
                            <h3><a href="{{ route('docs.database') }}">Database & queries <i class="bi bi-arrow-up-right small"></i></a></h3>
                            <p>Connect to your database and build common data workflows with the framework's database tools.</p>
                        </article>
                    </div>
                    <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="150">
                        <article class="feature-card">
                            <div class="feature-icon"><i class="bi bi-shield-check"></i></div>
                            <h3><a href="{{ route('docs.security') }}">Security & validation <i class="bi bi-arrow-up-right small"></i></a></h3>
                            <p>Learn the available security utilities and validate incoming data with clear, reusable rules.</p>
                        </article>
                    </div>
                    <div class="col-md-6 col-lg-4" data-aos="fade-up">
                        <article class="feature-card">
                            <div class="feature-icon"><i class="bi bi-window-stack"></i></div>
                            <h3><a href="{{ route('docs.litewire') }}">Interactive interfaces <i class="bi bi-arrow-up-right small"></i></a></h3>
                            <p>Build reactive experiences with Litewire's component and request workflow.</p>
                        </article>
                    </div>
                    <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="75">
                        <article class="feature-card">
                            <div class="feature-icon"><i class="bi bi-boxes"></i></div>
                            <h3><a href="{{ route('docs.assetsmanagement') }}">Assets & frontend <i class="bi bi-arrow-up-right small"></i></a></h3>
                            <p>Manage registered CSS and JavaScript assets, or use Vite for modern frontend entrypoints.</p>
                        </article>
                    </div>
                    <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="150">
                        <article class="feature-card">
                            <div class="feature-icon"><i class="bi bi-tools"></i></div>
                            <h3><a href="{{ route('docs.cli') }}">Utilities & CLI <i class="bi bi-arrow-up-right small"></i></a></h3>
                            <p>Explore the command line, sessions, files, hashing, flash messages, and other built-in helpers.</p>
                        </article>
                    </div>
                </div>
            </div>
        </section>

        <section class="section-space pt-0">
            <div class="container home-wrap">
                <div class="docs-panel" data-aos="fade-up">
                    <div class="row g-5 align-items-center">
                        <div class="col-lg-5">
                            <p class="eyebrow mb-3" style="color: var(--zap-lime);">A clear path forward</p>
                            <h2 class="section-heading mb-3">Start with the foundations.</h2>
                            <p class="section-copy mb-4">Begin with setup and configuration, then follow the guides into routing, core utilities, and the framework's built-in batteries.</p>
                            <a class="btn btn-light rounded-pill px-4 py-3 fw-semibold" href="{{ route('docs.index') }}">Browse all documentation <i class="bi bi-arrow-right ms-2"></i></a>
                        </div>
                        <div class="col-lg-6 offset-lg-1">
                            <a class="docs-link" href="{{ route('docs.basic.configuration') }}"><span><strong>01</strong> &nbsp; Configure your application</span><span>Environment & setup <i class="bi bi-arrow-up-right ms-2"></i></span></a>
                            <a class="docs-link" href="{{ route('docs.routing') }}"><span><strong>02</strong> &nbsp; Connect routes to actions</span><span>Routing guide <i class="bi bi-arrow-up-right ms-2"></i></span></a>
                            <a class="docs-link" href="{{ route('docs.database') }}"><span><strong>03</strong> &nbsp; Work with application data</span><span>Database guide <i class="bi bi-arrow-up-right ms-2"></i></span></a>
                            <a class="docs-link" href="{{ route('docs.vite') }}"><span><strong>04</strong> &nbsp; Bring in your frontend</span><span>Vite guide <i class="bi bi-arrow-up-right ms-2"></i></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="closing" data-aos="fade-up">
            <div class="container home-wrap">
                <p class="eyebrow mb-3">Your next build starts here</p>
                <h2 class="section-heading mx-auto mb-4">Make something meaningful with Zap.</h2>
                <a class="btn btn-zap" href="{{ route('docs.index') }}">Read the documentation <i class="bi bi-arrow-right ms-2"></i></a>
            </div>
        </section>
    </main>
@endsection
