@extends('layouts.base')
@section('content')
    <main class="container">
        <section class="row my-3">

            <div class="col-12">
                <div lw-component="frontend/pages/Dashboard.js" data-name="Umang"></div>
            </div>
            
            {{-- <div class="col-12">
                <form action="{{ route('home.login') }}" method="post">
                    <div class="mb-3">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username">
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn btn-dark btn-sm">Submit</button>
                    </div>
                </form>
            </div> --}}
            
            {{-- <div lw-get="/login" lw-trigger="load">
                
            </div> --}}

            {{-- <div lw-get="/testphpx" lw-trigger="load"></div> --}}

            {{-- <form lw-post="/testphpx" lw-target="#preview">
                <textarea name="comment"></textarea>
                <button type="submit">Send</button>
            </form>
            <div id="preview"></div> --}}

            {{-- <input type="text" lw:model="preview"> --}}

            {{-- <select lw:model="preview">
                <option value="Putri">Putri</option>
                <option value="Najwa">Najwa</option>
            </select> --}}

            {{-- <p>You typed: <span lw:text="preview"></span></p> --}}


            {{-- <input type="text" name="q" placeholder="Search user" class="form-control" lw-get="/search" lw-trigger="keyup" lw-target="#user-table-body">

            <table>
                <tbody id="user-table-body">

                </tbody>
            </table> --}}

            {{-- <div class="col-12" id="root" lw-component="/frontend/components/ImageUploader.js" data-action="{{ route('upload') }}" data-maxsize="2048", data-upload-path="/storage/uploads/images" data-accept="image/png, image/jpg, image/jpeg">
            </div> --}}

            {{-- <div lw:state="{ count: 0 }">
                <button type="button" lw:click="count--">
                    −
                </button>
                <span lw:text="count"></span>
                <button type="button" lw:click="count++">
                    +
                </button>
            </div> --}}

            {{-- <div lw:state="{ count: 5 }">
                <p lw:text="count"></p>
                <p lw:text="count * 10"></p>
                <p lw:text="count >= 5 ? 'Enough' : 'Not enough'"></p>
                <button lw:click="count += 5">
                    Add 5
                </button>
                <button lw:click="count = Math.max(0, count - 1)">
                    Decrease
                </button>
            </div> --}}
        </section>
    </main>
@endsection

@push('scripts')
    <script type="module"></script>
@endpush
