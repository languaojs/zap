@if (!empty($users))
    @foreach ($users as $index => $user)
        <tr>
            <td>{{ $index + 1 }}</td>
            <td>{{ $user['fullname'] }}</td>
        </tr>
    @endforeach
@endif
