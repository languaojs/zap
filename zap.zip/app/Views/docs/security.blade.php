@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#adding-csrf-token">Adding CSRF Token</a>
                        <a class="nav-link p-0" href="#validating-csrf-token">Validating CSRF Token</a>
                        <a class="nav-link p-0" href="#flushing-token">Flushing Token</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>
                    <div id="adding-csrf-token" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Adding CSRF Token</h3>
                        <p>By default, a CSRF token has been set in the <code>meta:csrf-token</code> dynamically in the base layout. This meta csrf token will be sent along with Livewire "AJAX" requests (e.g., <span class="code">lw-get, lw-post</span>, etc.)</p>
                        <p>To add a CSRF token to a normal HTML form, you need to call the helper <code class="text-primary">service()</code>, passing the <code class="code">Security</code> class and chaining with the <code class="text-primary">set_token_field()</code> inside the form.</p>

<pre><code class="language-html">&lt;form method=&quot;post&quot; action=&quot;@{{ route('update.user') }}&quot;&gt;
    &lt;!-- form fields --&gt;
    @{!! service(&quot;Zap\Core\Utils\Security&quot;)-&gt;set_token_field() !!}
&lt;/form&gt;</code></pre>

                    <p>Since Zap includes Litewire by default, you can also load its plugin <span class="code">livewire-auto-csrf-plugin.js</span>. The plugin will automatically add a hidden CSRF token field to the form.</p>
                    <p>If using XHR or jQuery for sending AJAX requests, add a key (e.g., _token) while the value is a generated token.</p>

<pre><code class="language-javascript">data:{
    //other keys
    _token: "@{{ service('Zap\Core\Utils\Security')-&gt;generate_token() }}"
}</code></pre>

                </div>

                <div id="validating-csrf-token" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Validating CSRF Token</h3>
                    <p>CSRF tokens are validated in the target controller method. Whether it receives requests from normal HTML form or AJAX/XHR, the method used is <code class="text-primary">validate_request()</code>. Here is an example:</p>

<pre><code class="language-php">public function updateUsername(Request $request, Security $security) {
    $security::get_instance();
    if(!$security->validate_request()){
        return $this->json(['error_message'=>'Invalid token']);
    }
    // rest of the code
}</code></pre>
                </div>

                <div id="flushing-token" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Flushing Token</h3>
                    <p>Flushing a token means invalidating, clearing, or deleting all or particular CSRF token so they can no longer be used. There are two distinct ways to do this, depending on whether you want to flush the entire tokens or a specific token.</p>

<pre><code class="language-php">//flushing the entire CSRF tokens
$security->flush_token()
//flushing only token being validated
if(!$security->validate_request(flush: true)){
    // rest of your code
}</code></pre>

                <h4 class="text-red-300 fw-bold">Warning!</h4>
                <p>Flushing CSRF tokens improves security by preventing replay attacks, but it can disrupt user experience when applied too aggressively. In single-use flushing (<code class="text-primary">validate_token(flush: true)</code>), deleting a token immediately upon submission breaks standard browser behaviors. If a user submits a form, navigates backward, and attempts to submit again, or if they work across multiple open browser tabs simultaneously, subsequent requests will fail with expired session errors because the original token was already consumed and removed from memory.</p>

                <p>Global token flushing (<code class="text-primary">flush_token()</code>) carries even broader consequences by wiping out every active CSRF token stored in the user's session at once. This instantly invalidates all other open tabs, active background AJAX requests, and auto-save scripts, causing unexpected authorization failures across the entire application.</p>
                <p>To balance security and usability, token flushing is best reserved for critical actions like logging out or changing credentials, while standard form submissions rely on time-based token expiration and automatic garbage collection instead.</p>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#security-page').classList.add('text-success');
    </script>
@endpush
