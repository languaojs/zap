@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#overview">Overview</a>
                        <a class="nav-link p-0" href="#entrypoints">Register entrypoints</a>
                        <a class="nav-link p-0" href="#development">Development</a>
                        <a class="nav-link p-0" href="#production">Production build</a>
                        <a class="nav-link p-0" href="#troubleshooting">Troubleshooting</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="overview" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Using Vite</h3>
                        <p>Zap integrates Vite through <code class="text-primary">Zap\Core\Utils\Assets::vite()</code>. Pass Vite entrypoint paths from your controller as the <code class="text-primary">vite</code> view value. The shared <code class="text-primary">layouts.base</code> layout sends the resulting script and stylesheet tags to the browser.</p>
                        <p>The project includes Vite and the <code class="text-primary">dev</code> and <code class="text-primary">build</code> npm scripts. Install the JavaScript dependencies from the project root:</p>
<pre><code class="language-bash">npm install</code></pre>
                        <p>The starter Vite configuration uses <code class="text-primary">resources/js/app.js</code> and <code class="text-primary">resources/css/app.css</code> as its entrypoints.</p>
                    </div>

                    <div id="entrypoints" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Register entrypoints</h3>
                        <p>Add the entrypoint paths to the data passed to the view. These names must match the paths configured in <code class="text-primary">vite.config.js</code> and, for production, the keys in Vite's manifest.</p>
<pre><code class="language-php">$data = [
    'vite' => [
        'resources/css/app.css',
        'resources/js/app.js',
    ],
    // Other view data...
];

$html = $this->render('pages/home', $data);</code></pre>
                        <p>Use <code class="text-primary">vite</code> as the view-data key: the base layout reads that value and calls the asset service. You can supply one entrypoint or an array. CSS entrypoints are emitted as stylesheet links; other entrypoints are emitted as JavaScript modules. CSS imported by a JavaScript entrypoint is also included in production.</p>
                        <p>Alternatively, call the global <code class="text-primary">vite()</code> helper directly in a Blade view when you need to place the tags yourself. It returns an HTML string, so render it unescaped:</p>
<pre><code class="language-php">@{!! vite(['resources/css/app.css', 'resources/js/app.js']) !!}</code></pre>
                        <p>Use either the shared layout integration or the direct helper for the same entrypoints, not both, to avoid loading the assets twice.</p>
                    </div>

                    <div id="development" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Development</h3>
                        <p>Set <code class="text-primary">ENVIRONMENT=development</code> in <code class="text-primary">.env</code>, then run the PHP application and Vite in separate terminals:</p>
<pre><code class="language-bash">npm run dev</code></pre>
                        <p>In development the asset service bypasses the manifest and points entries to <code class="text-primary">http://localhost:5173</code>. It injects Vite's <code class="text-primary">/@vite/client</code> once per page and serves each entrypoint from the dev server. Vite is configured on port <code class="text-primary">5173</code> with strict port checking and automatic browser reload when PHP view files change.</p>
                        <p>Ensure the browser can reach <code class="text-primary">localhost:5173</code>. The <code class="text-primary">DEV_SERVER</code> setting controls how built files are addressed; it does not change the development server URL.</p>
                    </div>

                    <div id="production" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Production build</h3>
                        <p>Build the frontend before deploying:</p>
<pre><code class="language-bash">npm run build</code></pre>
                        <p>Vite writes the compiled files and manifest under <code class="text-primary">public/build</code>. In production, Zap reads <code class="text-primary">public/build/.vite/manifest.json</code> (or <code class="text-primary">public/build/manifest.json</code> if the first path is absent) and maps each requested entrypoint to its built files.</p>
                        <p>Set <code class="text-primary">ENVIRONMENT=production</code> for production requests. The browser URL prefix depends on <code class="text-primary">DEV_SERVER</code>: <code class="text-primary">NATIVE</code> uses <code class="text-primary">/build/</code>; other values, including the default WAMP/XAMPP setup, use <code class="text-primary">/public/build/</code>. The manifest remains on disk under <code class="text-primary">public/build</code> in either case.</p>
                    </div>

                    <div id="troubleshooting" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Troubleshooting</h3>
                        <ul>
                            <li><strong>Development assets fail to load:</strong> confirm <code class="text-primary">npm run dev</code> is running and the browser can access <code class="text-primary">localhost:5173</code>.</li>
                            <li><strong>Production reports a missing manifest:</strong> run <code class="text-primary">npm run build</code> and ensure <code class="text-primary">public/build</code> is deployed.</li>
                            <li><strong>An entrypoint is missing:</strong> check that its path exactly matches an input in <code class="text-primary">vite.config.js</code>. Unknown manifest keys are skipped.</li>
                            <li><strong>Built URLs return 404:</strong> check <code class="text-primary">DEV_SERVER</code> against the web-server setup and the public URL prefix it serves.</li>
                        </ul>
                    </div>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#vite-page').classList.add('text-success');
    </script>
@endpush
