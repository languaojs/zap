@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#database-configuration">Database Configuration</a>
                        <a class="nav-link p-0" href="#making-connection">Making Connection</a>
                        <a class="nav-link p-0" href="#basic-crud">Basic CRUD Operations</a>
                        <ul>
                            <li><a href="#basic-create">Basic Create</a></li>
                            <li><a href="#basic-read">Basic Read (Select)</a></li>
                            <li><a href="#basic-update">Basic Update</a></li>
                            <li><a href="#basic-delete">Basic Delete</a></li>
                        </ul>
                        <a class="nav-link p-0" href="#query-builder">Using Query Builder</a>
                        <ul>
                            <li><a href="#complex-select">Complex Select</a></li>
                            <li><a href="#complex-update">Complex Update</a></li>
                            <li><a href="#complex-delete">Complex Delete</a></li>
                        </ul>
                        <a class="nav-link p-0" href="#schema-builder">Using Schema and Blueprint</a>
                        <ul>
                            <li><a href="#creating-tables">Creating Tables</a></li>
                            <li><a href="#modifying-tables">Modifying Tables</a></li>
                            <li><a href="#schema-inspection">Schema Inspection and Column Operations</a></li>
                        </ul>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="database-configuration" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Database Configuration</h3>
                        <p>All information regarding the database (credentials) should be stored in the <code class="text-secondary">.env</code> file and retrieved by <code class="text-secondary">/config/database.php</code>. This configuration information includes the host, username, password, database name, driver, port, and path to sqlite file (if the selected driver is sqlite).</p>

                        <p>Currently, Zap only supports MySQL and SQLite drivers. If you wish, you can replace Zap database wrapper with those used in other PHP frameworks.</p>

                        <p>When the selected driver is MySQL (written just mysql, all lowercase), the database needs to be ready. In the development mode, you can use <code class="text-secondary">php console make:database</code> to create a new local database. This CLI command does not work when the selected driver is SQLite (written just sqlite, all lowercase). However, once the database connection is made, the sqlite file will be created automatically in the given path.</p>

                        <p>Database structure can be created programmatically by using migration through CLI. If your app creates database structure during setup, you can use <code class="code">Schema Builder</code> in a dedicated model for setup.</p>

                    
                    </div>

                    <div id="making-connection" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Making Connection</h3>
                        <p>Database connection can be made or created anywhere in the app, and it has been registered in the <code class="code">Container</code> in <code class="text-secondary">/bootstrap/bindings.php</code>. By default, the database connection is made in the <code class="code">BaseModel</code>, using the <code class="text-primary">db()</code> method. By doing this, the connection is only made when we really need it.</p>

                        <p>There are many ways to use the connection in the model. You can store the instance in a protected variable like <code class="code">$connection</code> or directly use the <code class="text-primary">$this->db()->query(...)</code>. Here are a few examples:</p>

<pre><code class="language-php">&lt;?php
namespace Zap\App\Models;
use Zap\Core\Base\BaseModel;
use Zap\Core\Utils\Container;
use Zap\Core\Db\Database;

class UsersModel extends BaseModel {
protected mixed $connection;
public function __construct(){
    $this->connection = Container::getInstance()->make(Database::class);
    parent::__construct();
}
public function getActiveUsers(){
    $users = $this->connection->query('SELECT * FROM users WHERE status = ?', ['active']);
    return $users->fetchAll();
}
}</code></pre>

                        <p>While this may be convenient for most people, doing this will always open a database connection whenever the model is instantiated in the controller method. This is less productive, particularly when you call a method in the model that does not need the connection. Use this alternative instead:</p>

<pre><code class="language-php">&lt;?php
namespace Zap\App\Models;
use Zap\Core\Base\BaseModel;

class UsersModel extends BaseModel {

public function getActiveUsers(){
    $users = $this->db()->query('SELECT * FROM users WHERE status = ?', ['active'])->fetchAll();
    return $users;
}

public function sayHello(string $name){
    return 'Hello ' . $name;
}
}</code></pre>


                    </div>

                    <div id="basic-crud" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Basic CRUD Operations</h3>
                        <p>To perform basic Create, Read, Update, and Delete operations, you can use built-in methods in the <code class="code">BaseModel</code> class you extend. It is very convenient, particularly when the data you send has been well prepared in the controller method.</p>

                        <h4 class="text-black-50" id="basic-create">Create</h4>
                        <p>To insert new record, you can use the <code class="text-primary">create(string $table, array $data)</code> method, which returns boolean (true if success, otherwise, false). Using Try/Catch is also recommended.</p>

<pre><code class="language-php">public function addNewUser($userData){
try{
    $this->create('users', $userData);
    return [
        'status' => 'success',
        'message' => 'New user added'
    ];
}catch(\Exception $e){
    return [
        'status' => 'error',
        'message' => 'Error occured: ' . $e->getMessage()
    ];
}
}</code></pre>

                        <p>While this does not implement technique like $fillable, such as in Laravel, you can prepare the data in the controller method by using Zap <code class="code">ArrayEngine</code>. That class can be used to remove particular keys or to include only particular keys from the data.</p>

                        <h4 class="text-black-50" id="basic-read">Read</h4>
                        <p>To retrieve data from the database, you can use the built-in method <code class="text-primary">read(string $callback, string $table, array $where, array $options)</code>. For instance,</p>

<pre><code class="language-php">public function getUsersByStatus(string $status){
    $users = $this->read('fetchAll', 'users', ['status'=>'active']);
    return $users;
}

public function getUserById(int $id){
    $user = $this->read('fetchArray', 'users', ['id' => $id], ['limit' => 1]);
    return $user;
}</code></pre>

                        <p>The <code>$callback</code> argument can be <code class="code">fetchAll</code> or <code class="code">fetchArray</code>. This depends on whether you want to return a list of records or only one record.</p>

                        <h4 class="text-black-50" id="basic-update">Update</h4>
                        <p>To update records, you can use the built-in method <code class="text-primary">update(string $table, array $data, array $where)</code>, which returns boolean.</p>

<pre><code class="language-php">public function updateUser(int $id, array $newData) {
try{
    $this->update('users', $newData, ['id' => $id]);
    return [
        'status' => 'success',
        'message' => 'User data updated'
    ];
}catch(\Exception $e){
    return [
        'status' => 'error',
        'message' => 'Error occured: ' . $e->getMessage()
    ];
}
}</code></pre>

                        <h4 class="text-black-50" id="basic-delete">Delete</h4>
                        <p>To delete records from the database, you can use the built-in method <code class="text-primary">delete(string $table, array $where)</code>. For example:</p>


<pre><code class="language-php">public function deleteUserById(int $id){
try{
    $this->delete('users', ['id' => $id]);
    return [
    'status' => 'success',
    'message' => 'User deleted'
];
}catch(\Exception $e){
    return [
    'status' => 'error',
    'message' => 'Error occured: ' . $e->getMessage()
];
}
}</code></pre>


                    </div>

                    <div id="query-builder" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Using Query Builder</h3>
                        <p>For more complex queries, you can use either <code class="text-primary">db()</code>-><code class="text-primary">query(string $sql, array $params)</code> or Zap <code class="code">QueryBuilder</code> by using <code class="text-primary">builder()</code>. The power of <code class="text-primary">builder()</code> is that it can create SQL string with complex where clauses and options. The <code class="code">QueryBuilder</code> returns an associative array containing two keys, the <code>sql</code> (generated SQL query with named PDO placeholders), and the <code>params</code> (an associative array mapping parameter placeholders to their bound values).</p>

                        <h4 class="text-black-50" id="complex-select">Complex Select</h4>
                        <p>The basic syntax for select is this:</p>

<pre><code class="language-php">QueryBuilder::select(
    string $table,
    string|array $columns = '*',
    array $where = [],
    array $options = []
): array

//in the model method, you can do $this->builder()::select()
</code></pre>

                        <p>In the where clause, you can use various operators, like:</p>

<pre><code class="language-php">
$result = QueryBuider::select(
    table: 'users',
    columns: ['id', 'username', 'email'],
    where: [
        'status' => 'active',
        'age' => ['>=', 19],
        'name%' => 'john'
    ]
);
</code></pre>

                        <p>The builder will look for users age = or > 19 and name LIKE john. It automatically appends <code>LIKE %john%</code>.</p>

                        <p>It also support IN and NULL checks:</p>

<pre><code class="language-php">$result = QueryBuilder::select(
    table: 'products',
    columns: '*',
    where: [
        'category_id'  => ['IN' => [1, 5, 12]],
        'deleted_at'   => null,                    // IS NULL
        'published_at' => ['NOT NULL']             // IS NOT NULL
    ]
);</code></pre>

                        <p>For nested logic (_or groups), you can use the special _or key to build logical OR conditions as follows:</p>

<pre><code class="language-php">//direct OR
$result1 = QueryBuilder::select(
table: 'orders',
columns: '*',
where: [
    'status' => 'pending',
    '_or'    => [
        'total' => ['>', 500],
        'is_vip' => 1
    ]
]
);

//grouped OR with sequential list (A AND B) OR (C AND D)
$result2 = QueryBuilder::select(
table: 'accounts',
columns: ['id', 'email', 'role'],
where: [
    'active' => 1,
    '_or' => [
        ['role' => 'admin', 'level' => ['>=', 3]],
        ['role' => 'manager', 'department' => 'finance']
    ]
]
);</code></pre>

                        <h4 class="text-black-50">Select with JOIN</h4>
                        <p>The <code class="code">QueryBuilder</code>::<code class="text-primary">select()</code> method supports INNER, LEFT, RIGHT, FULL, and CROSS joins via the <code class="code">$options['join']</code> array parameter. Join operations build table relationships and resolve qualified column names (table.column) without breaking PDO parameter binding.</p>

                        <p>Joins are passed as an array of tuples inside $options['join']. Each join definition requires an indexed array with 3 mandatory elements and 1 optional element:</p>

<pre><code class="language-php">[
    'table_to_join',   // [0] Foreign table name or alias
    'column_1',        // [1] Left column identifier (e.g., table1.id)
    'column_2',        // [2] Right column identifier (e.g., table2.foreign_id)
    'JOIN_TYPE'        // [3] Optional. 'INNER', 'LEFT', 'RIGHT', 'FULL', 'CROSS' (Default: 'INNER')
]</code></pre>

                        <h5>Join Types and Examples</h5>
                        <p class="fw-bold">Single INNER JOIN (Default)</p>
                        <p>If the 4th element (join type) is omitted, <code class="code">QueryBuilder</code> defaults to INNER JOIN.</p>


<pre><code class="language-php">$query = QueryBuilder::select(
    table: 'posts',
    columns: ['posts.id', 'posts.title', 'users.username AS author'],
    where: [
        'posts.status' => 'published'
    ],
    options: [
        'join' => [
            ['users', 'posts.author_id', 'users.id'] // Defaults to INNER JOIN
        ],
        'order' => 'posts.created_at DESC'
    ]
);</code></pre>

                        <div class="alert alert-secondary">
                            <strong class="d-block">Generated SQL</strong>
                            SELECT posts.id,posts.title,users.username AS author FROM posts INNER JOIN users ON posts.author_id = users.id WHERE posts.status = :w_posts_status_0 ORDER BY posts.created_at DESC
                            <strong class="d-block">Parameters</strong>
                            ['w_posts_status_0' => 'published']
                        </div>
                        <p class="fw-bold">LEFT JOIN with Complex Filters</p>
                        <p>Specify 'LEFT' as the 4th element to preserve records from the primary table even when matching join rows are absent.</p>

<pre><code class="language-php">$query = QueryBuilder::select(
table: 'users',
columns: ['users.id', 'users.email', 'orders.id AS order_id', 'orders.total'],
where: [
    'users.status'  => 'active',
    'orders.status' => null // Find users with NO matching orders (IS NULL)
],
options: [
    'join' => [
        ['orders', 'users.id', 'orders.user_id', 'LEFT']
    ]
]
);</code></pre>

                        <div class="alert alert-secondary">
                            <strong class="d-block">Generated SQL</strong>
                            SELECT users.id,users.email,orders.id AS order_id,orders.total FROM users LEFT JOIN orders ON users.id = orders.user_id WHERE users.status = :w_users_status_0 AND orders.status IS NULL
                        </div>

                        <p class="fw-bold">Multiple Joined Tables (INNER + LEFT)</p>
                        <p>Multiple table relationships can be chained by passing additional join definitions inside the $options['join']</p>

<pre><code class="language-php">$query = QueryBuilder::select(
table: 'order_items',
columns: [
    'order_items.id',
    'orders.code AS order_code',
    'products.name AS product_name',
    'categories.title AS category_title'
],
where: [
    'orders.created_at' => ['>=', '2026-01-01'],
    '_or' => [
        'products.price' => ['>', 100],
        'categories.is_featured' => 1
    ]
],
options: [
    'join' => [
        ['orders', 'order_items.order_id', 'orders.id', 'INNER'],
        ['products', 'order_items.product_id', 'products.id', 'INNER'],
        ['categories', 'products.category_id', 'categories.id', 'LEFT']
    ],
    'order' => 'orders.created_at DESC',
    'limit' => 20
]
);</code></pre>

                        <div class="alert alert-secondary">
                            <span class="d-block fw-bold">Generated SQL</span>
                            SELECT order_items.id,orders.code AS order_code,products.name AS product_name,categories.title AS category_title FROM order_items INNER JOIN orders ON order_items.order_id = orders.id INNER JOIN products ON order_items.product_id = products.id LEFT JOIN categories ON products.category_id = categories.id WHERE orders.created_at >= :w_orders_created_at_0 AND (wor_products_price_0 > :wor_products_price_0 OR wor_categories_is_featured_1 = :wor_categories_is_featured_1) ORDER BY orders.created_at DESC LIMIT 20
                        </div>

                        <p>Finally, you can execute the queries with <code class="text-primary">$this->db()</code>-><code class="text-primary">query()</code>.</p>
                    
<pre><code class="language-php">$query = QueryBuilder::select(
    table: 'comments',
    columns: ['comments.body', 'users.username', 'posts.title AS post_title'],
    where: [
        'comments.approved' => 1
    ],
    options: [
        'join' => [
            ['users', 'comments.user_id', 'users.id', 'INNER'],
            ['posts', 'comments.post_id', 'posts.id', 'INNER']
        ],
        'limit' => 5
    ]
);

// Fetch joined rows from the database instance
$recentComments = $this->db()->select($query['sql'], $query['params']);</code></pre>

                        <h4 class="text-black-50" id="complex-update">Complex Update</h4>
                        <p><code class="code">QueryBuilder</code>::<code class="text-primary">update()</code> accepts $data for the values to set and a $where array that supports all the same filtering features as <code class="text-primary">select()</code> (including comparison operators, IN clauses, auto-wildcard %, and _or grouping).</p>

                        <div class="alert alert-info">
                            <span class="fw-bold">Parameter Namespace Safety</span>: QueryBuilder::update() automatically prefixes SET placeholders as :set_field and WHERE placeholders as :w_field to avoid name collisions when updating a column that is also used in the WHERE condition.
                        </div>

                        <p class="fw-bold">Bulk Status Update with Condition Groups (_or + IN)</p>

<pre><code class="language-php">$table = 'users';
$data = [
    'status'        => 'suspended',
    'suspended_at'  => '2026-10-04 18:00:00',
    'updated_by'    => 'system'
];

$where = [
    'account_type' => ['IN' => ['standard', 'freemium']],
    '_or' => [
        'failed_logins' => ['>=', 5],
        'last_login%'    => '2025-' // Auto-LIKE pattern matching
    ]
];

// 1. Generate SQL and Params via QueryBuilder
$query = QueryBuilder::update($table, $data, $where);

// 2. Execute via Database
$affectedRows = $this->db()->query($query['sql'], $query['params'])->numRows();</code></pre>

                        <div class="alert alert-secondary">
                            <span class="d-block fw-bold">Generated SQL</span>
                            UPDATE users SET status = :set_status, suspended_at = :set_suspended_at, updated_by = :set_updated_by WHERE account_type IN (:w_account_type_0_0,:w_account_type_0_1) AND (wor_failed_logins_0 >= :wor_failed_logins_0 OR wor_last_login_1 LIKE :wor_last_login_1)
                            <span class="d-block fw-bold">Parameters</span>
                            [
                                'set_status'          => 'suspended',
                                'set_suspended_at'    => '2026-10-04 18:00:00',
                                'set_updated_by'      => 'system',
                                'w_account_type_0_0'  => 'standard',
                                'w_account_type_0_1'  => 'freemium',
                                'wor_failed_logins_0' => 5,
                                'wor_last_login_1'    => '%2025-%'
                            ]
                        </div>

                        <h4 class="text-black-50" id="complex-delete">Complex Delete</h4>
                        <p><code class="code">QueryBuilder</code>::<code class="text-primary">delete()</code> enforces non-empty WHERE arrays to prevent accidental full-table wipes. It leverages <code class="text-primary">buildWhere()</code> to allow precise scoping.</p>
                        <p class="fw-bold">Soft-Delete Cleanup with Multi-Condition Scoping</p>
                        <p>Delete inactive records that meet multiple age/status metrics using _or array list syntax: (A AND B) OR (C AND D).</p>

<pre><code class="language-php">$where = [
'is_archived' => 1,
'_or' => [
    // Group 1: Guest accounts inactive over 30 days
    ['role' => 'guest', 'last_seen' => ['<', '2026-09-01']],
    
    // Group 2: Unverified accounts with null tokens
    ['role' => 'unverified', 'email_verified_at' => null]
]
];

// Generate SQL statement
$query = QueryBuilder::delete('users', $where);

// Execute directly through Database instance
$deletedCount = $this->db()->delete('users', $where);</code></pre>

                        <div class="alert alert-info">
                            Remember that in the model that extends BaseModel, you can always use $this->builder().
                        </div>
                    </div>

                    <div id="schema-builder" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Using Schema and Blueprint</h3>
                        <p>The <code class="code">Schema</code> class provides database-agnostic DDL (Data Definition Language) management for table creation, structural modifications, and column management across MySQL and SQLite drivers. It utilizes <code class="code">Blueprint</code> instances to define columns, indexes, and foreign keys using a fluent interface.</p>
                        
                        <p><code class="code">Schema</code> and <code class="code">Blueprint</code> are used in migrations. However, they are also available in the <code class="code">BaseModel</code> via <code class="text-primary">db()->schema()</code>.</p>

                        <h4 class="text-black-50" id="creating-tables">Creating Tables</h4>
                        <p>The <code class="text-primary">create()</code> method initializes new database tables. In SQLite, it automatically enforces foreign keys via PRAGMA foreign_keys = ON;. In MySQL, tables are created with ENGINE=InnoDB.</p>

<pre><code class="language-php">use Zap\Core\Db\Blueprint;

$schema->create('users', function (Blueprint $table) {
    // Auto-increment primary key
    $table->id();
    // VARCHAR(100)           
    $table->string('name', 100);
    // Unique index                         
    $table->string('email')->unique('email');                   
    $table->string('password');
    // Driver-aware ENUM or CHECK constraint
    $table->enum('role', ['admin', 'user', 'editor']);
    $table->boolean('is_active')->default(1);
    $table->timestamps();             
});</code></pre>

                        <p class="fw-bold">Table with Foreign Key Constraints</p>
                        <p>Use the fluent foreign key methods (<code class="text-primary">foreign()</code>, <code class="text-primary">references()</code>, <code class="text-primary">on()</code>, <code class="text-primary">onDelete()</code>, <code class="text-primary">onUpdate()</code>) to define relationships.</p>

<pre><code class="language-php">$schema->create('posts', function (Blueprint $table) {
    $table->id();
    $table->integer('user_id');
    $table->string('title');
    $table->text('body')->nullable();
    $table->timestamps();

    // Foreign Key definition
    $table->foreign('user_id')
          ->references('id')
          ->on('users')
          ->onDelete('CASCADE')
          ->onUpdate('CASCADE');

    // Composite/named secondary indexes
    $table->index('title', 'idx_posts_title');
});</code></pre>

                        <h4 class="text-black-50" id="modifying-tables">Modifying Tables</h4>
                        <p>The <code class="text-primary">table()</code> method inspects existing columns using driver metadata (PRAGMA table_info for SQLite or DESCRIBE for MySQL) to dynamically add new columns or alter existing ones.</p>

                        <p class="fw-bold">Adding New Columns to Existing Tables</p>

<pre><code class="language-php">$schema->table('users', function (Blueprint $table) {
    $table->string('phone', 20)->nullable();
    $table->date('birthdate')->nullable();
});</code></pre>

                        <p class="fw-bold">Modifying Column Definitions</p>
                        <p>To modify a column, chain the <code class="text-primary">change()</code> method.</p>
                        <div class="alert alert-danger">
                            Note: SQLite does not support direct column modification via ALTER TABLE MODIFY. Attempting to call change() on SQLite will throw a RuntimeException.
                        </div>

<pre><code class="language-php">$schema->table('users', function (Blueprint $table) {
    // Change name length to VARCHAR(150) (MySQL only)
    $table->string('name', 150)->nullable()->change();
});</code></pre>

                        <h4 class="text-black-50" id="schema-inspection">Schema Inspection and Column Operations</h4>
                        <p><code class="code">Schema</code> includes built-in methods for checking tables/columns and executing structural modifications safely across drivers.</p>

                        <p class="fw-bold">Checking Table and Column Existence</p>

<pre><code class="language-php">// Check if table exists
if ($schema->hasTable('orders')) {
    // Check if column exists
    if ($schema->hasColumn('orders', 'tracking_code')) {
        // ...
    }
}</code></pre>

                        <p class="fw-bold">Renaming Columns</p>
                        <p>Handles column renaming across drivers. On SQLite, <code class="code">Schema</code> automatically rebuilds the table via a temporary table (__tmp_tablename) to preserve data integrity when renaming.</p>

<pre><code class="language-php">$schema->renameColumn('users', 'phone', 'phone_number');</code></pre>

                        <p class="fw-bold">Dropping Columns and Tables</p>
                        <p>Safely drops columns. On SQLite, it executes a table rebuild while verifying that the table's last remaining column is not removed.</p>

<pre><code class="language-php">//dropping column birthdate from users table
    $schema->dropColumn('users', 'birthdate');
    //dropping table posts
    $schema->drop('posts');
    </code></pre>


                    </div>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#database-page').classList.add('text-success');
    </script>
@endpush