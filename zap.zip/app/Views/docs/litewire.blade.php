@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#getting-started">Getting Started</a>
                        <a class="nav-link p-0" href="#reactive-state">Reactive State</a>
                        <a class="nav-link p-0" href="#models">Binding Input Models</a>
                        <a class="nav-link p-0" href="#server-requests">Server Requests</a>
                        <a class="nav-link p-0" href="#indicators">Loading Indicators</a>
                        <a class="nav-link p-0" href="#js-components">JavaScript Components</a>
                        <a class="nav-link p-0" href="#events">Events and Modifiers</a>
                        <a class="nav-link p-0" href="#security">Security Notes</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="getting-started" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Getting Started</h3>
                        <p>Litewire is Zap's lightweight browser-side interaction layer. It is loaded by default and scans the page for request directives, reactive state, input models, expressions, and JavaScript components. When Litewire replaces or inserts response markup, it scans the updated content too.</p>
                        <p>Directive names beginning with <code class="code">lw-</code> handle server requests. Directives beginning with <code class="code">lw:</code> handle client-side state and DOM behavior.</p>
                    </div>

                    <div id="reactive-state" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Reactive State</h3>
                        <p>Put <code class="text-primary">lw:state</code> on a container and initialize it with a JavaScript object. Use <code class="text-primary">lw:click</code> to update the state, <code class="text-primary">lw:text</code> to display an expression, and <code class="text-primary">lw:show</code> to conditionally show an element.</p>

<pre><code class="language-html">&lt;div lw:state=&quot;{ count: 0 }&quot;&gt;
    &lt;button type=&quot;button&quot; lw:click=&quot;count--&quot;&gt;−&lt;/button&gt;
    &lt;span lw:text=&quot;count&quot;&gt;&lt;/span&gt;
    &lt;button type=&quot;button&quot; lw:click=&quot;count++&quot;&gt;+&lt;/button&gt;
    &lt;p lw:show=&quot;count &gt;= 5&quot;&gt;Five or more&lt;/p&gt;
&lt;/div&gt;</code></pre>

                        <div class="border rounded p-3 my-3" lw:state="{ count: 0 }">
                            <div class="d-flex align-items-center gap-2">
                                <button class="btn btn-outline-primary" type="button" lw:click="count--" aria-label="Decrease count">−</button>
                                <span class="fw-bold" lw:text="count">0</span>
                                <button class="btn btn-outline-primary" type="button" lw:click="count++" aria-label="Increase count">+</button>
                            </div>
                            <p class="text-success mt-2 mb-0" lw:show="count >= 5" hidden>Five or more</p>
                        </div>

                        <p>Assignments and deletions of top-level state properties trigger a render of the state container. The render updates its <code class="text-primary">lw:text</code> and <code class="text-primary">lw:show</code> descendants.</p>
                    </div>

                    <div id="models" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Binding Input Models</h3>
                        <p>Bind a field with <code class="text-primary">lw:model</code>. A regular model updates on input; <code class="text-primary">lw:model.change</code> updates on change, and <code class="text-primary">lw:model.blur</code> updates on blur. Use a model name matching a property in the nearest state container to keep that state in sync.</p>

<pre><code class="language-html">&lt;div lw:state=&quot;{ name: 'Ada' }&quot;&gt;
    &lt;input class=&quot;form-control&quot; value=&quot;Ada&quot; lw:model=&quot;name&quot;&gt;
    &lt;p&gt;Hello, &lt;span lw:text=&quot;name&quot;&gt;&lt;/span&gt;!&lt;/p&gt;
&lt;/div&gt;</code></pre>

                        <div class="border rounded p-3 my-3" lw:state="{ name: 'Ada' }">
                            <label class="form-label" for="litewire-name">Your name</label>
                            <input class="form-control" id="litewire-name" value="Ada" lw:model="name">
                            <p class="mt-2 mb-0">Hello, <span lw:text="name">Ada</span>!</p>
                        </div>

                        <p>Models can also update a DOM target by using a selector as the model value, for example <code class="text-primary">lw:model="#preview"</code>. Without a state container or target selector, the value is stored in Litewire's global models object.</p>
                    </div>

                    <div id="server-requests" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Server Requests</h3>
                        <p>Use <code class="text-primary">lw-get</code>, <code class="text-primary">lw-post</code>, <code class="text-primary">lw-put</code>, or <code class="text-primary">lw-delete</code> to request a URL. By default, buttons are triggered by click and forms by submit. Set <code class="text-primary">lw-trigger</code> to use another DOM event, or set it to <code class="text-primary">load</code> to request as soon as the element is scanned.</p>

<pre><code class="language-html">&lt;form lw-post=&quot;/profile&quot; lw-target=&quot;#profile-result&quot; lw-swap=&quot;innerHTML&quot;&gt;
    &lt;input class=&quot;form-control&quot; name=&quot;display_name&quot;&gt;
    &lt;button type=&quot;submit&quot;&gt;Save&lt;/button&gt;
    &lt;span class=&quot;litewire-indicator&quot; hidden&gt;Saving…&lt;/span&gt;
&lt;/form&gt;
&lt;div id=&quot;profile-result&quot;&gt;&lt;/div&gt;</code></pre>

                        <p>GET requests include form data as query parameters. POST, PUT, and DELETE requests send form data as <code class="code">FormData</code>. If a CSRF meta token is present, Litewire sends it in the <code class="code">X-CSRF-TOKEN</code> header. The server response is treated as HTML and swapped into the target.</p>
                        <p>Use <code class="text-primary">lw-target</code> to choose the destination (the requesting element is the default) and <code class="text-primary">lw-swap</code> to choose how to insert the response: <code class="code">innerHTML</code> (default), <code class="code">outerHTML</code>, <code class="code">append</code>, or <code class="code">prepend</code>. Use <code class="text-primary">lw-push-url</code> to add a URL to browser history; its value can be <code class="text-primary">true</code> to use the request URL or a URL string to set a specific one.</p>
                        <p>Failed HTTP requests are logged in the console and dispatch <code class="code">litewire:error</code>. Successful requests dispatch <code class="code">litewire:beforeRequest</code> and <code class="code">litewire:afterRequest</code> events around the request.</p>
                    </div>

                    <div id="indicators" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Loading Indicators</h3>
                        <p>Litewire adds the <code class="code">litewire-request</code> class to the requesting element while a request is in progress, then removes it when the request ends. Put an element with class <code class="code">litewire-indicator</code> inside the requesting element to mark it as an indicator. Alternatively, point <code class="text-primary">lw-indicator</code> to a selector elsewhere on the page.</p>

<pre><code class="language-css">.litewire-request {
    opacity: 0.6;
    pointer-events: none;
}

.litewire-indicator {
    display: none;
}

.litewire-indicator.litewire-request {
    display: inline;
}</code></pre>
                    </div>

                    <div id="js-components" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">JavaScript Components</h3>
                        <p>Use <code class="text-primary">lw-component</code> to mount a JavaScript ES module on an element. Its path is relative to the application base URL. Litewire imports the module and calls its default export with the element and a plain object made from the element's <code class="code">data-*</code> attributes.</p>

<pre><code class="language-html">&lt;div lw-component=&quot;frontend/components/Counter.js&quot; data-start=&quot;3&quot;&gt;&lt;/div&gt;
&lt;div lw-component=&quot;frontend/components/Greeting.js&quot; data-name=&quot;Ada&quot;&gt;&lt;/div&gt;
&lt;div lw-component=&quot;frontend/components/TaskList.js&quot;&gt;&lt;/div&gt;</code></pre>

                        <h4 class="text-black-50">Counter Component</h4>
                        <div class="border rounded p-3 my-3" lw-component="frontend/components/Counter.js" data-start="3"></div>

                        <h4 class="text-black-50">Greeting Component</h4>
                        <div class="border rounded p-3 my-3" lw-component="frontend/components/Greeting.js" data-name="Ada"></div>

                        <h4 class="text-black-50">Task List Component</h4>
                        <div class="border rounded p-3 my-3" lw-component="frontend/components/TaskList.js"></div>

                        <p>Components can be class constructors or functions. Keep module paths publicly accessible to the browser, and use <code class="text-primary">textContent</code> when displaying untrusted values.</p>
                    </div>

                    <div id="events" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Events and Modifiers</h3>
                        <p>Expressions are supported on <code class="text-primary">lw:click</code>, <code class="text-primary">lw:input</code>, <code class="text-primary">lw:change</code>, <code class="text-primary">lw:submit</code>, <code class="text-primary">lw:keydown</code>, <code class="text-primary">lw:keyup</code>, <code class="text-primary">lw:focus</code>, and <code class="text-primary">lw:blur</code>. Expressions can refer to <code class="code">$event</code>, <code class="code">$el</code>, <code class="code">$value</code>, <code class="code">$state</code>, and <code class="code">$wire</code>.</p>

<pre><code class="language-html">&lt;input lw:keydown.debounce=&quot;query = $value&quot;&gt;
&lt;button lw:click.prevent=&quot;$event.target.textContent = 'Saved'&quot;&gt;Submit&lt;/button&gt;
&lt;div lw:click.outside=&quot;open = false&quot;&gt;...&lt;/div&gt;</code></pre>

                        <p>Supported event modifiers include <code class="code">.prevent</code>, <code class="code">.stop</code>, <code class="code">.self</code>, <code class="code">.outside</code>, <code class="code">.once</code>, <code class="code">.window</code>, <code class="code">.document</code>, <code class="code">.capture</code>, <code class="code">.passive</code>, <code class="code">.debounce</code>, and <code class="code">.throttle</code>. Debounce and throttle use a fixed default delay of 250 ms.</p>
                    </div>

                    <div id="security" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Security Notes</h3>
                        <p>Litewire evaluates expressions in directive values as JavaScript. Only put trusted code in these attributes; do not construct expressions by inserting user-provided content. For displaying text, <code class="text-primary">lw:text</code> writes to <code class="code">textContent</code>, but server responses swapped as HTML should still be escaped and validated by the application.</p>
                        <p>Litewire attaches the CSRF meta-token header to requests when the token exists. Server-side endpoints must still validate CSRF tokens, authorization, and input data.</p>
                    </div>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#litewire-page').classList.add('text-success');
    </script>
@endpush
