@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#setting-flasher">Setting Flasher</a>
                        <a class="nav-link p-0" href="#flashing">Flashing</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="setting-flasher" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Setting Flasher</h3>
                        

                    
                    </div>

                    <div id="flashing" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Flashing</h3>
                        
                    </div>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        
    </script>
@endpush