@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#getting-started">Getting Started</a>
                        <a class="nav-link p-0" href="#generating-files">Generating Files</a>
                        <a class="nav-link p-0" href="#database">Database</a>
                        <a class="nav-link p-0" href="#migrations">Migrations</a>
                        <a class="nav-link p-0" href="#routes">Route Cache</a>
                        <a class="nav-link p-0" href="#clearing-resources">Clearing Resources</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="getting-started" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Getting Started</h3>
                        <p>Zap includes a command line interface (CLI) for generating application files, preparing databases, running migrations, caching routes, and clearing resources. Run commands from the project root with PHP installed and available in your terminal.</p>
                        <p>The <code class="code">console</code> entry point registers the available commands. List them by running:</p>

<pre><code class="language-bash">php console
php console list</code></pre>

                        <p>To see command-specific usage and examples, append <code class="text-primary">--help</code> or <code class="text-primary">-h</code> where supported. Commands that accept a name generally show their usage when no name is provided.</p>
                    </div>

                    <div id="generating-files" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Generating Files</h3>
                        <p>Use the <code class="text-primary">make:controller</code> and <code class="text-primary">make:model</code> commands to create classes from the built-in stubs. Controller files are created in <code class="code">app/Controllers</code>, and model files are created in <code class="code">app/Models</code>. Existing files are not overwritten.</p>

<pre><code class="language-bash">php console make:controller UserController
php console make:model User</code></pre>

                        <p>The model stub derives a table name by lowercasing the model name and adding <code>s</code>. Review and adjust the generated file if your class or database table uses a different naming convention.</p>

                        <h4 class="text-black-50">Generating an Environment File or Key</h4>
                        <p>The <code class="text-primary">generate</code> command can print a fresh application key or create <code class="code">.env</code> from its stub:</p>

<pre><code class="language-bash">php console generate --key
php console generate --env</code></pre>

                        <p>Copy the generated key into <code class="code">ZAP_KEY</code> in your environment file. If <code class="code">.env</code> already exists, the environment-file command asks before replacing it.</p>

                        <h4 class="text-black-50">Creating a Migration File</h4>
                        <p>Migration names determine which stub is selected. Use names like <code class="code">create_users_table</code>, <code class="code">add_email_to_users_table</code>, <code class="code">drop_column_email_from_users</code>, <code class="code">drop_table_users</code>, or <code class="code">change_users_table</code>. Other names use the general update stub.</p>

<pre><code class="language-bash">php console make:migration create_users_table
php console make:migration add_email_to_users_table
php console make:migration drop_table_users</code></pre>

                        <p>Generated migration files are timestamped and placed in the project-level <code class="code">migrations</code> directory. Open each generated file and define the schema changes in its <code class="text-primary">up()</code> and <code class="text-primary">down()</code> methods as appropriate.</p>
                    </div>

                    <div id="database" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Database</h3>
                        <p>For MySQL, <code class="text-primary">make:database</code> creates a database using the connection settings in <code class="code">config/database.php</code>. You can pass a database name directly. Without one, the command prompts for a name and may offer the configured default.</p>

<pre><code class="language-bash">php console make:database myapp_db
php console make:database</code></pre>

                        <p>This command creates MySQL databases; it is not used to create an SQLite database. SQLite files are created when the application connects using the configured SQLite path.</p>
                    </div>

                    <div id="migrations" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Migrations</h3>
                        <p>After configuring the database and adding migration files to <code class="code">migrations</code>, run pending migrations with <code class="text-primary">migrate:start</code>. Zap records completed migrations and assigns them to a batch.</p>

<pre><code class="language-bash">php console migrate:start
php console migrate:status</code></pre>

                        <p>Use <code class="text-primary">migrate:status</code> to compare the migration files with the recorded migrations. Run <code class="text-primary">migrate:start</code> first to initialize the migration tracking table.</p>

                        <p>Rollback accepts either <code class="text-primary">--last</code> to undo the most recently recorded migration or <code class="text-primary">--all</code> to process all recorded migrations in reverse order. When a migration has a <code class="text-primary">down()</code> method, it is called before the migration record is removed.</p>

<pre><code class="language-bash">php console migrate:rollback --last
php console migrate:rollback --all</code></pre>

                        <div class="alert alert-danger">
                            <span class="fw-bold">Warning:</span> <code class="text-primary">migrate:fresh</code> rolls migrations back, drops the migration tracking table, and runs migrations again. It asks for confirmation, but can remove application data. Back up your database before using it.
                        </div>

<pre><code class="language-bash">php console migrate:fresh</code></pre>
                    </div>

                    <div id="routes" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Route Cache</h3>
                        <p>After changing route definitions, use <code class="text-primary">cache:routes</code> to build the route cache from <code class="code">routes/web.php</code>. The cache is written under <code class="code">storage/cache/routes</code>.</p>

<pre><code class="language-bash">php console cache:routes</code></pre>
                    </div>

                    <div id="clearing-resources" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Clearing Resources</h3>
                        <p>The <code class="text-primary">clear</code> command clears logs by default. Select a resource with a subcommand or its short/long option. The <code class="text-primary">all</code> subcommand clears logs, session files, and cache; <code class="text-primary">views</code> clears compiled views.</p>

<pre><code class="language-bash">php console clear
php console clear logs
php console clear sessions
php console clear cache
php console clear views
php console clear all</code></pre>

                        <p>The available flags are <code class="text-primary">-l</code>/<code class="text-primary">--log</code>, <code class="text-primary">-s</code>/<code class="text-primary">--session</code>, <code class="text-primary">-c</code>/<code class="text-primary">--cache</code>, <code class="text-primary">-v</code>/<code class="text-primary">--views</code>, and <code class="text-primary">-a</code>/<code class="text-primary">--all</code>. To clear a custom directory, provide its path after <code class="text-primary">dir</code>:</p>

<pre><code class="language-bash">php console clear -v
php console clear dir storage/tmp</code></pre>

                        <p>Clearing a custom directory removes its contents recursively. Check the target path carefully before running that command.</p>
                    </div>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#cli-page').classList.add('text-success');
    </script>
@endpush
