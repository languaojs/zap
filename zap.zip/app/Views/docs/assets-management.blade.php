@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#overview">Overview</a>
                        <a class="nav-link p-0" href="#registering">Register assets</a>
                        <a class="nav-link p-0" href="#loading">Load assets in a page</a>
                        <a class="nav-link p-0" href="#sources">Local files and CDN</a>
                        <a class="nav-link p-0" href="#defaults">Default assets</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="overview" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Asset Management</h3>
                        <p>Zap's <code class="text-primary">Zap\Core\Utils\Assets</code> service loads registered CSS and JavaScript files into a page. Register asset nicknames and their local file names, CDN URLs, and optional defaults in <code class="text-primary">config/css.php</code> and <code class="text-primary">config/js.php</code>. Controllers choose which nicknames a page needs and whether to prefer local files or CDN URLs.</p>
                        <p>Asset loading is separate from Vite. Use the asset registry for prebuilt files placed in the framework's assets directories or served from a CDN. For Vite source entrypoints and manifest-based builds, see the <a href="{{ route('docs.vite') }}">Vite guide</a>.</p>
                    </div>

                    <div id="registering" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Register assets</h3>
                        <p>Each key is the nickname used by a controller. CSS records provide <code class="text-primary">local</code>, <code class="text-primary">cdn</code>, and optional <code class="text-primary">default</code> values. JavaScript records also specify the script <code class="text-primary">type</code> and extra HTML <code class="text-primary">attributes</code>.</p>
<pre><code class="language-php">// config/css.php
return [
    'site' => [
        'local' => 'site.css',
        'cdn' => 'https://cdn.example.com/site.css',
        'default' => 'none',
    ],
];</code></pre>
<pre><code class="language-php">// config/js.php
return [
    'site' => [
        'local' => 'site.js',
        'cdn' => 'https://cdn.example.com/site.js',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => 'defer',
    ],
];</code></pre>
                        <p>For local assets, put CSS files in <code class="text-primary">public/assets/css</code> and JavaScript files in <code class="text-primary">public/assets/js</code>. With <code class="text-primary">DEV_SERVER=NATIVE</code>, the generated URLs use <code class="text-primary">/assets/css/</code> and <code class="text-primary">/assets/js/</code>; other values use <code class="text-primary">/public/assets/css/</code> and <code class="text-primary">/public/assets/js/</code>. Set an unavailable local or CDN option to the string <code class="text-primary">none</code>.</p>
                    </div>

                    <div id="loading" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Load assets in a page</h3>
                        <p>Use <code class="text-primary">setAssets()</code> in the controller and pass its result to the view as <code class="text-primary">assets</code>. The base layout loads CSS and header JavaScript in the document head, then footer JavaScript before the closing body tag.</p>
<pre><code class="language-php">$data = [
    'assets' => $this->assets->setAssets(
        source: 'local',
        header_css: ['site'],
        header_js: [],
        footer_js: ['site']
    ),
];

$html = $this->render('pages/home', $data);</code></pre>
                        <p>The asset lists contain registered nicknames, not file paths. You can request the same nickname on different pages and give each page only the assets it needs.</p>
                    </div>

                    <div id="sources" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Choose local files or CDN</h3>
                        <p>Pass <code class="text-primary">source: 'local'</code> to prefer each asset's local file. If that asset's local value is <code class="text-primary">none</code>, the service uses its CDN URL when one is configured. For any source other than <code class="text-primary">local</code>, the service uses the CDN URL; if that URL is <code class="text-primary">none</code>, the asset is not emitted.</p>
                        <p>Unregistered nicknames are skipped. CSS is rendered as a stylesheet link. JavaScript is rendered as a script tag using the registered <code class="text-primary">type</code> and <code class="text-primary">attributes</code>.</p>
                    </div>

                    <div id="defaults" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Default assets</h3>
                        <p>Set <code class="text-primary">default</code> to <code class="text-primary">header</code> in a CSS registration or to <code class="text-primary">header</code>/<code class="text-primary">footer</code> in a JavaScript registration to include it on every page that calls <code class="text-primary">setAssets()</code>. The method adds these defaults to the page's explicit lists and removes duplicate nicknames. Entries without a recognized placement are not automatically loaded.</p>
<pre><code class="language-php">// Example CSS default
'bootstrap' => [
    'local' => 'bootstrap.min.css',
    'cdn' => 'https://cdn.example.com/bootstrap.min.css',
    'default' => 'header',
],</code></pre>
                        <p>Choose defaults for files that are genuinely needed site-wide; add page-specific files through the named arguments to <code class="text-primary">setAssets()</code>.</p>
                    </div>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#assets-management-page').classList.add('text-success');
    </script>
@endpush
