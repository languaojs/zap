@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#starting-session">Starting Session</a>
                        <a class="nav-link p-0" href="#adding-session">Adding Session</a>
                        <a class="nav-link p-0" href="#checking-getting-session">Checking and Getting Session</a>
                        <a class="nav-link p-0" href="#updating-session">Updating Session</a>
                        <a class="nav-link p-0" href="#unset-destroy-session">Unsetting and Destroying Session</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="starting-session" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Starting Session</h3>
                    <p>Session starts in the "front controller," which is the <em>/public/index.php</em>. By default, the class <code class="code">SessionManager</code> has been registered (or bound) using the <code class="code">Container</code> class in the <em>/bootstrap/bindings.php</em>. Thus, to use the methods from the <code class="code">SessionManager</code> class, one can make new instance of the class or better call it using <code class="code">Container</code> class.</p>
                    <p>This is an example of starting the session using both ways:</p>

<pre><code class="language-php">use Zap\Core\Utils\SessionManager;
$sessionMgr = new SessionManager;
$sessionMgr->start();

//or

use Zap\Core\Utils\Container;
use Zap\Core\Utils\SessionManager;

$sessionMgr = Container::getInstance()->make(SessionManager::class);
$sessionMgr->start();</code></pre>
                    
                    <p>The difference between both is that the second one does not create a new instance but use the existing one (singleton).</p>
                </div>

                <div id="adding-session" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Adding Session</h3>
                    <p>Sessions can be added for different purposes, but typically, a session is added to store the logged user data. For this purpose, <code class="code">SessionManager</code> can be used in the model or controller method (e.g., validating login) and in the middleware (e.g., validating access).</p>
                    <p>All sessions are stored in an encrypted array, with the top-level key is taken from the SESSION_NAME in the .env. However, you are free to store sessions as many as possible with the name of your choice. Here are some examples for adding or storing sessions:</p>

<pre><code class="language-php">$sessionMgr = Container::getInstance()->make(SessionManager::class);
$userdata = [
    'name' => 'John Doe',
    'status' => 'active',
    'role' => 'user',
    'contact' => [
        'address' => 'Elm Street number 404',
        'email' => 'johndoe@example.com'
    ]
];
$sessionMgr->regenerate(true); //important when access previlege is concerned
$sessionMgr->set(config('app.session'), $userdata);

$editedPost = [
    'id' => 500,
    'title' => 'A Nightmare on Elm Street',
    'author' => 'Jane Doe'
];
$sessionMgr->set('editedPost', $editedPost);</code></pre>

                <p>Keep in mind that the session name is string, while the session data is array.</p>
                </div>

                <div id="checking-getting-session" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Checking and Getting Session</h3>
                    <p>To check whether a session exists (by session name), you can use <code class="text-primary">has()</code> method. This method returns boolean (true if exists, otherwise, false). Meanwhile, to get the session data, use <code class="text-primary">get()</code> method.</p>

<pre><code class="language-php">//assuming that you are using Container
//checking session
$sessionName = config('app.session'); // or any session name you set
$sessionExist = $sessionMgr->has($sessionName); // return true or false

//getting session
$sessionData = $sessionMgr->get($sessionName); // return array or false if the session does not exist</code></pre>

                <p>In Zap, sessions stored using <code class="code">SessionManager</code> cannot be read by using $_SESSION, unless they are stored using $_SESSION. Trying <code>$sessionData = $_SESSION[</code><code class="text-primary">config('app.session')</code><code>]</code> will return encrypted string.</p>
                <p>I have stored a session data with name {{ $sessionName }}. This is what it looks like when the session data is retrieved using $_SESSION:</p>

<pre><code class="language-bash">{!! print_r($invalidSessionData) !!}</code></pre>

            <p>Without the ZAP_KEY, even Tony Stark and Jarvis cannot decrypt this session data!</p>
            <p>Meanwhile, with the correct method, the session data looks like this:</p>

<pre><code class="language-php">{!! print_r($validSessionData) !!}</code></pre>
                </div>
            
                <div id="updating-session" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Updating Session</h3>
                    <p><code class="code">SessionManager</code> enables you for updating session data entirely or by keys. For instance, when a logged user changes their email or name, their status (in session data) can be updated without having to log in again.</p>
                    <p>For updating the entire session data, first prepare the updated data array, then use <code class="text-primary">$sessionMgr->set($sessionName, $updatedData)</code>. This will replace the entire session data with the new array. Meanwhile, for updating specific keys within the session data, use <code class="text-primary">$sessionMgr->updateVal($sessionName, $key, $value)</code> for a single key, and <code class="text-primary">$sessionMgr->update($sessionName, $updates)</code> for multiple keys.</p>

<pre><code class="language-php">//update single key 
$sessionName = config('app.session'); // or any session name you set
$sessionMgr->updateVal($sessionName, 'email', 'newemail@example.com');

//update multiple keys

$updatedData = [
    'email' => 'newemail@example.com',
    'name' => 'New Name'
];
$sessionMgr->updateVal($sessionName, $updatedData);

//replace entire session data
$newSessionData = [
    'name' => 'New Name',
    'status' => 'active',
    'role' => 'user',
    'contact' => [
        'address' => 'New Address',
        'email' => 'newemail@example.com'
    ]
];
$sessionMgr->set($sessionName, $newSessionData);</code></pre>
                
                </div>
                
                <div id="unset-destroy-session" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Unsetting and Destroying Session</h3>
                    <p>To unset a session, use <code class="text-primary">$sessionMgr->unset()</code>. This will remove the session data from the session storage. To destroy the entire session, use <code class="text-primary">$sessionMgr->destroy()</code>. This will remove all session data and end the session.</p>

<pre><code class="language-php">//unset a session
$sessionName = config('app.session'); // or any session name you set
$sessionMgr->unset($sessionName);

//destroy the entire session
$sessionMgr->destroy();</code></pre>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#session-manager-page').classList.add('text-success');
    </script>
@endpush
