@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#environment-setting">Environment Setting</a>
                        <a class="nav-link p-0" href="#dev-server">Development Server</a>
                        <a class="nav-link p-0" href="#session-name">Session Name</a>
                        <a class="nav-link p-0" href="#database-email">Database and Email</a>
                        <a class="nav-link p-0" href="#zap-key">Zap Key</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="environment-setting" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h2 class="title">Environment Setting</h3>

                    <p>First of all, you will need to look at the <code>.env.example</code> file located in the app root directory. Then, rename it to <code>.env</code></p>
                    <p>By default, it has the following keys:</p>

                    <pre><code class="language-html">
                    # ---ENVIRONMENT--- #
                    ## development or production
                    ## DEV_SERVER=NATIVE or WAMP or XAMPP
                    ## When using PHP NATIVE development server, BASE_URL=localhost:8000
                    ## and run php -S localhost:8000 -t public server.php
                    ## Otherwise, when using WAMP or XAMPP, BASE_URL=localhost/app_folder
                    ## In production, BASE_URL=your-domain without protocol

                    ENVIRONMENT=development
                    DEV_SERVER=WAMP
                    BASE_URL=localhost/zap

                    # ---SESSION_NAME--- #
                    SESSION_NAME=zapapp

                    # ---DATABASE--- #
                    ## DRIVER = mysql or sqlite
                    DB_HOST=localhost
                    DB_USER=root
                    DB_PASS=
                    DB_NAME=mydb
                    DB_DRIVER=mysql
                    DB_PORT=
                    SQLITE_PATH=storage/database/${DB_NAME}.sqlite

                    # ---EMAIL--- #
                    EMAIL_HOST=
                    EMAIL_USER=
                    EMAIL_PASS=
                    EMAIL_PORT=
                    EMAIL_SECURE=

                    # ---KEYS--- #
                    ##Generate new key using php console generate --key
                    ZAP_KEY=
                    </code></pre>
                    
                    <p>The content is actually self-explained.</p>
                    <p>The most important thing is that initially <code>.env</code> <span class="fw-bold text-red-600">does not exist and this will trigger an error</span>. Thus, you will need to rename .env.example to .env as said before.</p>
                    <p>Set the <span class="code">ENVIRONMENT</span> properly, whether <em>development</em> or <em>production</em> (production: when the development finished and the app is ready to deploy).</p>

                    <p>To get the key of the ENV key, you can use the <code class="text-primary">read_env()</code> helper:</p>

<pre><code class="language-php">read_env(string $key, mixed $default = null);
//example: $dbDriver = read_env('DB_DRIVER', 'mysql')</code></pre>

                    <p>This will return mysql if the value of the key DB_DRIVER is empty or the key does not exist.</p>

                    <p>You can also use global variable like <em class="code">$_ENV['DB_DRIVER']</em> to get the same key. However, to prevent errors due to the key inexistence, please use the helper instead.</p>
                </div>

                <div id="dev-server" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Development Server</h3>
                    <p>Zap is developed using the WAMP Server app. However, it does not stop you from using other local PHP server app like XAMPP or the built-in PHP development server.</p>
                    <p>When using the PHP built-in development server, set the <em class="code">DEV_SERVER</em> to <em class="code">NATIVE</em>. Without this, the app cannot read the assets because the server app behaves differently. The <em class="code">BASE_URL</em> is then need to be set to <em class="code">localhost:8000</em> or another open port in your machine.</p>
                    <p>To run the native development server, open terminal in the root folder and run the following command:</p>

                    <pre><code class="language-bash">
                    php -S localhost:8000 -t public server.php
                    </code></pre>
                    
                    <p>In our machine, using native or built-in PHP server is significantly slow. Thus, you are encouraged to use a third-party PHP development server app like WAMP or XAMPP.</p>
                    <div class="alert alert-warning">
                        Do not add protocol to the BASE_URL (e.g., http:// or https://) because Zap will figure out the protocol automatically.
                    </div>
                    <p>In production, the <em class="code">BASE_URL</em> needs to be adjusted. If the app is in the main domain, then put the domain name, e.g., <em>yourdomain.com</em>. Likewise, if the app is in a subdomain, use <em>subdomain.domain.com</em>. Once again, the BASE_URL is without the host protocol.</p>
                </div>

                <div id="session-name" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Session Name</h3>
                    <p>Session name should be a space-free string, unique, and secret. This session name will be the default top-level key for <em class="code">$_SESSION['the_session_name']</em> of your app. Of course, new session names can be added when needed.</p>
                    <p>The session can be retrieved by using the following helper:</p>

                    <pre><code class="language-php">
                        config('app.session');
                    </code></pre>
                    
                    <p>In fact, the <code class="text-primary">config()</code> helper function can be used for retrieving any configurations from the <em>/config</em> directory. In this case, <em>app</em> is the config file name, while <em>session</em> is the key. It is strongly recommended to change the key name, though the value remains (for security).</p>
                </div>
                
                <div id="database-email" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Database and Email</h3>
                    <p>Database configuration consists of information, such as the host, username, password, port, and driver. When the driver is <em class="code">sqlite</em>, the path to the sqlite file is required.</p>
                    <p>Currently, Zap database wrapper supports MySql and Sqlite. You can replace the database wrapper with those used in Laravel or Symfony. However, replacing the default database wrapper disables you from using Zap <code class="code">QueryBuilder</code> and <code class="code">Schema</code> (for migration).</p>
                    <p>By default, Zap initiates database connection in the <code class="code">BaseModel</code> class. Singleton approach is used here to prevent multiple database initiation, which results in overheat. Moreover, although you extend the <code class="code">BaseModel</code> in a model, database connection will be made when you use the built-in method <code class="text-primary">db()</code> or other CRUD methods in the <code class="code">BaseModel</code>.</p>
                    <p>Email credential is optional, unless your app sends email, such as confirmation, password reset, campaign, etc.</p>
                    <p>By default, Zap uses <code class="code">PHPMailer</code> as the email class. An utility class <code class="code">Email</code> can also be used, which employs fluent. The basic use of this utility class is as follow:</p>

<pre><code class="language-php">use Zap\Core\Utils\Email;

$result = (new Email())
    ->sender_name('John Doe')
    ->addressee('jane@example.com', 'Jane Doe')
    ->subject('Welcome aboard!')
    ->body('&lt;h1&gt;Welcome!&lt;/h1&gt;&lt;p&gt;Thanks for joining us.&lt;/p&gt;')
    ->execute();

if ($result['status'] === 'success') {
    echo "Email sent successfully!";
} else {
    echo "Failed to send: " . $result['message'];
}</code></pre>
                    
                    <p>You can also pass multiple BBCs by using:</p>

<pre><code class="language-php">->bbc([
    ['email'=>'manager@example.com', 'name'=>'Manager'],
    'archive@example.com'
])</code></pre>
                    <p>And you can add attachments, whether from path or <em class="code">$_FILES['documents']</em></p>

<pre><code class="language-php">->attachment_from_path('path_to_attachment_1', 'path_to_attachment_2')
// or
->attachments($_FILES['documents'] ?? [])</code></pre>
                    
                    <div class="alert alert-warning">
                        Be advised that if you remove <em class="code">PHPMailer</em> from your app, this Email class cannot be used!
                    </div>
                </div>
                
                <div id="zap-key" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Zap Key</h3>
                    <p>Zap key is used to cipher and decipher sessions. Do not use the default key, if any, but generate one by using Zap CLI. Open the terminal in the root folder and use this command to generate a new key:</p>
                    
                    <pre><code class="language-bash">
                        php console generate --key
                    </code></pre>
                    
                    <p>Then, copy the newly generated key and make it the value for ZAP_KEY in the .env file.</p>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#basic-configuration').classList.add('text-success');
    </script>
@endpush