@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#listing-files">Listing Files</a>
                        <a class="nav-link p-0" href="#get-file-content">Get File Content</a>
                        <a class="nav-link p-0" href="#writing-file">Writing File Contents</a>
                        <a class="nav-link p-0" href="#append-file-content">Appending File Contents</a>
                        <a class="nav-link p-0" href="#deleting-file">Deleting Files</a>
                        <a class="nav-link p-0" href="#get-media">Retrieving Public Media</a>
                        <a class="nav-link p-0" href="#uploading-file">Uploading File</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="listing-files" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Listing Files</h3>
                    
                    <p>The <code class="code">File</code> utility class has several methods, some are static, while others are not. Listing files using the <code class="code">File</code>::<code class="text-primary">list_files()</code> method is the first thing you can do with this class. This method retrieves a list of all files stored within a specific directory, relative to your app's base directory. This can be useful for getting specific files to download or something else.</p>

<pre><code class="language-php">use Zap\Core\Utils\File;
$files = File::list_files('path/to/directory');
//loop through the returned array to access file names and paths
foreach ($files as $file) {
    echo "File Name: " . $file['name'] . "\n";
    echo "File Path: " . $file['path'] . "\n";
}</code></pre>

                    <p>First, the method will scan a given target directory and filters out directory navigational dots (like . or .. ) automatically. Then, it returns an array containing the plain file name and URL-encoded full file path for every file in the given directory.</p>
                    <p>By default, <code class="code">File</code> class operations are restricted to <em>allowed_roots</em> defined in the <em>/config/app.php</em>. When this class is used to list file located in a directory unlisted in the <em>allowed_roots</em>, it will return:</p>

<pre><code class="language-php">//trying to list files in the app/Controllers directory
{{ print_r($fileList) }}</code></pre>

                <p>It is important to know that the files listed by using this method are for server-side file operations like getting the file content, deleting the file, appending content to the file, etc. They are not directly downloadable by web clients.</p>
                </div>

                <div id="get-file-content" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Get File Content</h3>
                    <p>The method <code class="code">File</code>::<code class="text-primary">get()</code> can be used to retrieve the raw string contents of a file licated within allowed directories. It works just like the previous method, where a request is validated against allowed roots and directory traversal is blocked</p>
                    <p>The following content is retrieved from the <em>/storage/logs/test.log</em>:</p>

<pre><code class='language-php'>use Zap\Core\Utils\File;
// Retrieve contents of a storage file
$result = File::get(BASE_PATH . '/storage/logs/test.log');
//$result is an array with keys 'error', 'message', and 'data'
{{ print_r($testLog) }}</code></pre>

                </div>

                <div id="writing-file" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Writing File Contents</h3>

                    <p>The <code class="text-primary">put()</code> method writes string data to a file at the specified path, overwriting any existing contents.</p>
                    <p>This method inspects the parent directory structure and recursively creates missing folders with <code>0775</code> permissions prior to writing. It also Wraps underlying file writing calls to handle failures gracefully without throwing unhandled PHP exceptions.</p>
                    <p>Pass the destination target path and the string payload to <code class="code">File</code>::<code class="text-primary">put()</code>. Check the returned <code>error</code> key (<code>0</code> on success, <code>1</code> on failure) to verify if the file was saved.</p>

<pre><code class='language-php'>use Zap\Core\Utils\File;
$path = BASE_PATH . '/storage/exports/report.txt';
$data = "Status: Completed\nTimestamp: " . date('Y-m-d H:i:s');
$result = File::put($path, $data);
if ($result['error'] === 0) {
    echo "Success: " . $result['message'];
} else {
    echo "Error: " . $result['message'];
}</code></pre>
                </div>

                <div id="append-file-content" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Appending File Contents</h3>
                    <p>The <code class="code">File</code>::<code class="text-primary">append()</code> method adds string data to the end of an existing file, creating the file if it does not already exist. This can be useful for logging into text files.</p>
                    <p>As the name suggests, it preserves existing file contents while adding new data at the end. When it does not find the target file, it creates one, ensuring that the operation always succeeds.</p>
                    <p>Provide the target file path and the string data to be appended <code class="code">File</code>::<code class="text-primary">append()</code>. Check the returned <code>error</code> key to determine if the operation was successful.</p>

<pre><code class='language-php'>use Zap\Core\Utils\File;
$logPath = BASE_PATH . '/storage/logs/activity.log';
$logEntry = '[' . date('Y-m-d H:i:s') . '] User logged in from IP 127.0.0.1';
$result = File::append($logPath, $logEntry);
if ($result['error'] === 0) {
echo "Log entry recorded.";
} else {
echo "Error: " . $result['message'];
}</code></pre>
                </div>
 
                <div id="deleting-file" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Deleting Files</h3>
                    <p>The <code class="code">File</code>::<code class="text-primary">delete_file()</code> method safely removes a target file from disk after verifying path permissions.</p>
                    <p>As with <code class="text-primary">get()</code>, <code class="text-primary">put()</code>, and <code class="text-primary">append()</code>, it prevents path traversal by evaluating paths against allowed roots. This will prevent unauthorized deletion of critical system files.</p>
                    <p>Pass the target file path to <code class="code">File</code>::<code class="text-primary">delete_file()</code>. Check the returned <code>error</code> key (<code>0</code> for successful deletion, <code>1</code> for failure or access denial).</p>

<pre><code class='language-php'>use Zap\Core\Utils\File;
$filePath = BASE_PATH . '/storage/uploads/temp_report.pdf';
$result = File::delete_file($filePath);
if ($result['error'] === 0) {
echo $result['message'];
} else {
echo "Deletion failed: " . $result['message'];
}</code></pre>
                </div>
 
                <div id="get-media" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Retrieving Public Media</h3>
                    <p>Media located within the <em>/public/media</em> directory (e.g., images or vides) can be retrieved by using the <code class="text-primary">get_media()</code> method. This method resolves and generates the full web URL for the retrieved media. If the media file does not exists, particularly image, it will return a default image URL for <code>media-not-found</code>.</p>
                    <p>Instantiate the <code class="code">File</code> class and pass the relative asset path to <code class="text-primary">get_media()</code>. The method returns the full URL string to the media file or the fallback image.</p>

<pre><code class='language-php'>use Zap\Core\Utils\File;
$file = new File();
// Get public URL for an avatar image
$imageUrl =$file->get_media('avatars/user_123.jpg');
echo '&lt;img src="' . $imageUrl . '" alt="User Avatar" class="img-fluid"&gt;';</code></pre>

                <p>When used in the view, use: <code>$imageUrl = </code><code class="text-primary">service('Zap\Core\Utils\File')</code>-><code class="text-primary">get_media('svgs/image.svg')</code></p>
                </div>

                <div id="uploading-file" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Uploading File</h3>
                    <p>Uplading file becomes more covenient with the <code class="text-primary">$file->do_upload()</code> method. One only need to set the upload configuration by doing <code class="text-primary">init_upload()</code> and pass the <code>$_FILES</code> field name to the <code class="text-primary">do_upload()</code> method.</p>
                    <p>Custom file name is supported, as well as the target location. However, for security reason, the target location is restricted to the allowed roots set in the <em>/config/app.php</em>. Also, by default, this class prevents users from uploading executables.</p>

<pre><code class="language-php">// in controller 
public function upload(Request $request) {
    $file = new File;
    $uploadPath = $request->input('target_location'); // or any form field you set
    $customFileName = $request->input('filename', null); // if empty, then null
    $maxSize = $request->input('max_size'); // or any form field you set
    $allowedTypes = ['jpg', 'png'];
    $encryptName = ($customFileName === null); //if not null, then false
    $upload_config = [
        'upload_path' => BASE_PATH . $uploadPath,
        'max_size' => $maxSize,
        'allowed_types' => $allowedTypes,
        'encrypt_name' => $encryptName
    ];
    $file->init_upload($upload_config);
    $file->do_upload('file', $customFileName); // assuming $_FILES['file'];
    return $this->json($file->get_upload_errors()); // assuming upload via AJAX
}</code></pre>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#file-page').classList.add('text-success');
    </script>
@endpush
