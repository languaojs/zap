@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0 my-2" href="#meet-zap">Meet Zap</a>
                        <ul>
                            <li><a href="#backend">Backend</a></li>
                            <li><a href="#frontend">Frontend</a></li>
                            <li><a href="#between-both">Between Both</a></li>
                        </ul>
                        <a class="nav-link p-0 my-2" href="#features">Zap Features</a>
                        <ul>
                            <li><a href="#routing-pattern">Familiar Routing Pattern</a></li>
                            <li><a href="#controller-pattern">Familiar Controller Pattern</a></li>
                            <li><a href="#view-pattern">Familiar View Pattern</a></li>
                            <li><a href="#model-pattern">Familiar Model Pattern</a></li>
                            <li><a href="#security">Security</a></li>
                            <li><a href="#assets-loading">Dynamic Assets Loading</a></li>
                            <li><a href="#litewire">Litewire</a></li>
                            <li><a href="#console">Command Line Interface (CLI)</a></li>
                        </ul>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="meet-zap" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Meet Zap</h3>
                        <div class="p-3 bg-light border rounded text-secondary my-3">
                        Zap is simply a framework for creating a PHP-based web application, employing the PHP Model-View-Controller (MVC) paradigm, where JavaScript Single-Page-Application (SPA) style can also be applied.
                    </div>

                    <p>Zap offers flexibility without unnecessary complexity. Thus who are familiar with other popular PHP frameworks will find Zap simpler and easier to use. Even when you are new in PHP-based web development, Zap suits you.</p>

                    <p>Zap can be used for building PHP-based web apps in any scale. Is it a small project or larger? Zap can be your choice. As with other frameworks, Zap also supports <em class="text-primary fw-bold">Vite</em>, if you like to work with JavaScript-based frontend.</p>

                    <p>Not familiar with Vite? No problem! Zap uses <em class="code fw-bold">Litewire</em>, which is an inherent part of the framework. <span class="bg-amber-100"> Litewire is an HTML-first AJAX engine and dynamic component loader designed to build modern, interactive single-page-like applications with minimal client-side JavaScript configuration</span>.</p>

                    <h4 class="text-black-50" id="backend" style="scroll-margin-top: 200px;">Backend</h4>
                    <p>Pure PHP!</p>
                    <p>Behind the screen, Zap works with controllers, models, middlewares, and a list of other backend utilities. For database, currently Zap only supports <code>MySql</code> and <code>Sqlite</code>. However, you can use other database layers, though you will need to make adjustments.</p>

                    <h4 class="text-black-50" id="frontend" style="scroll-margin-top: 200px;">Frontend</h4>
                    <p>Zap PHP uses <code class="code">BladeOne</code>, just like Laravel. However, as said, <em class="text-primary">Vite</em> is also welcome. JavaScript components can also be injected or imported using Zap <code class="code">Litewire</code>. We haven't tested whether Zap can work with other frontend frameworks like React, Vue, Svelte, etc.</p>
                    <p>By default, Zap includes Bootstrap for styling, but you can replace it with other CSS frameworks like Tailwind, Bulma, Material CSS, etc.</p>
                    <p>The look of your web app will depend on how creative you are, by the way.</p>
                    
                    <h4 class="text-black-50"id="between-both" style="scroll-margin-top: 200px;">Between both</h4>
                    <p>Well, with Litewire, you can call a method in the controller, as long as it is defined in the <em>route</em>, and put whatever it returns to the target element. Form validation, for instance, can be made without doing AJAX manually.</p>
                    <p>Assets (CSS and JS) are loaded dynamically, depending on how you set them in the controller. You can also decide whether a JS asset is put on the header or footer. You can learn about <em>Dynamic Assets Loading</em> later.</p>
                </div>

                <div id="features" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Zap Features</h3>
                    <p>Zap is a lightweight PHP framework, not as robust as Laravel or others. We do not want to make a full-stack PHP framework. However, users can always extend and expand the functionalities of their Zap-based app.</p>
                    
                    <h4 class="text-black-50" id="routing-pattern" style="scroll-margin-top: 200px;">Familiar Routing Pattern</h4>
                    <p>Zap uses familiar routing patterns for routes, with middleware and named routes supported.</p>

<pre><code class="language-php">// routes/web.php
use Zap\Core\Routing\RouteFacade as Route;
Route::get('/', 'HomeController@index')->name('home.index')->middleware('guest');
Route::post('/upload', 'HomeController@upload')->name('upload');</code></pre>
                    
                    <p>With named routes, you can get the route by using our <code class="text-primary">route()</code> helper anywhere in the app.</p>

<pre><code class="language-php">route('home.index')</code></pre>

                    <h4 class="text-black-50" id="controller-pattern" style="scroll-margin-top: 200px;">Familiar Controller Pattern</h4>
                    <p>Zap also uses familiar controller pattern. Given the example routes above, the <code class="code">HomeController</code> may look like this:</p>
                    
<pre><code class="language-php">&lt;?php
namespace Zap\App\Controllers;

use Zap\Core\Base\BaseController;
use Zap\Core\Http\Request;
use Zap\Core\Utils\Security;

class HomeController extends BaseController {
    public function index(){
        $data = [
            'assets' => $this->assets->setAssets(source: 'local', header_css: ['icons', 'aos'], header_js: [], footer_js: ['aos']),
            //'vite' => ['resources/css/app.css','resources/js/app.js'],
            '_title' => 'Zap PHP',
            '_description' => "" ,
            '_robots' => 'index, follow',
            '_bodyClass' => 'bg-light',
            //'navbar' => 'navbars.home',
            //'footer' => 'footers.home',
        ];
        
        $html = $this->render('home/index', $data);
        return $this->response($html);
    }

    public function upload(Request $request, Security $security){
        $security->get_instance();
        if(!$security->validate_request()){
            return $this->json(['error'=>'Invalid token'], 403);
        }

        $file = new File;
        $upload_path = $request->input('upload_path');
        $file_name = $request->input('file_name', null);

        $encrypt_name = ($file_name === null);
        
        $upload_config = [
            'upload_path' => BASE_PATH . $upload_path,
            'max_size' => $request->input('maxsize'),
            'allowed_types' => ['jpg', 'png'],
            'encrypt_name', $encrypt_name
        ];

        $file->init_upload($upload_config);
        $file->do_upload('file', $file_name);
        return $this->json($file->get_upload_errors());
    }
}</code></pre>
                    <p>As you can see, the <code class="text-primary">index()</code> method returns a view, while the <code class="text-primary">upload()</code> method does not.</p>
                    <p>When a method (or route, in this case) returns a view, except for components, <em>assets</em> are managed. In the example above, <em>Vite</em> is not implemented.If the page has a navbar and footer, uncomment the keys and make sure that the file <em>home-navbar.blade.php</em> exists in the navbars directory, also with the footer, respectively.</p>
                    <p>The <code class="text-primary">upload()</code> method in this example receives request via AJAX and returns a json response. It uses the <code class="code">Security</code> class to validate the request to prevent CSRF attack. This also applies with normal non-GET requests via forms.</p>
                    
                    <h4 class="text-black-50" id="view-pattern" style="scroll-margin-top: 200px;">Familiar View Pattern</h4>
                    <p>Zap uses BladeOne, a Blade templating engine for non-Laravel apps. In the <code class="text-primary">index()</code> method above, a blade file <em>index.blade.php</em> exists in the <em>home</em> directory.</p>

<pre><code class="language-php">@@extends('layouts.base')
@@section('content')
    Content goes here...
@@endsection 
@@push('scripts')
&lt;script&gt;
    JavaScript here...
&lt;/script&gt;
@@endpush</code></pre>

                    <p>This view extends a layout, which is <em>base.blade.php</em>, which exists in the <em>layouts</em> directory.</p>

                    <h4 class="text-black-50" id="model-pattern" style="scroll-margin-top: 200px;">Familiar Model Pattern</h4>
                    <p>Models are used to interact with database, and they are called from the controller method. For instance, inside the <em>Models</em> directory, there is a <code class="code">TestModel</code> class with a method like <code class="text-primary">sayHello(string $name)</code>. The model may look like this:</p>

<pre><code class="language-php">&lt;?php
namespace Zap\App\Models;
use Zap\Core\Base\BaseModel;

class TestModel extends BaseModel {
    public function sayHello(string $name){
        return "Hello " . $name;
    }
}</code></pre>

                    <p>In the controller method, this model method can be called and the return can be stored into a <em>$data</em> key:</p>

<pre><code class="language-php">$data = [
    //other keys...,
    'hello' => $this->model('TestModel')->sayHello('John Doe')
];</code></pre>

                     <p>When working with the database, one can use the <code class="text-primary">db()</code> method or built-in CRUD methods from the <code class="code">BaseModel</code> class.</p>

<pre><code class="language-php">public function addNewUser(array $userdata){
    $table = 'users';
    try{
        //$this->db()->query(string sqlquery..., array parameters...);
        $this->create($users, $userdata);
        return [
            'error' => false,
            'message' => 'New user added'
        ];
    } catch (\Exception $e) {
        return [
            'error' => true,
            'messagge' => 'Error: ' . $e->getMessage()
        ];
    }
}</code></pre>

                    <h4 class="text-black-50" id="security" style="scroll-margin-top: 200px;">Security</h4>
                    <p>Zap is not a fort or castle, but it is secure. By default, a CSRF token is added in the head as a meta tag. This token will be sent along with Litewire AJAX and validated in the controller method. With normal form, one can add the following line to add the token:</p>

<pre><code class="language-php">@{!! service('\Zap\Core\Utils\Security')->set_token_field() !!}</code></pre>

                    <p>Alternatively, enable <em>litewire-auto-csrf-plugin</em> in the <em>config/js.php</em> file by setting the <em>default</em> key to <em>footer</em>. This will automatically add a token field in the forms. The <em>upload</em> method above shows how you can validate the token.</p>
                    <p>To prevent your app directories from being accessed, except for public directory, two <em>.htaccess</em> files have been added. However, you may want to put another <em>.htaccess</em> or an <em>index.html</em> file into each directory to make it more secure.</p>

                    <h4 class="text-black-50" id="assets-loading" style="scroll-margin-top: 200px;">Dynamic Assets Loading</h4>
                    <p>You do not want to load jQuery or Datatables assets on pages that do not need them, but you want some assets to load on all pages by default. This helps you prevent loading unneeded CSS and JS assets. Also, you can determine whether a JS assets should be put within the header or somewhere right before the closing body tag.</p>
                    <p>In Zap, you do this in the controller methods that return a view.</p>

<pre><code class="language-php">$data = [
    'assets' => $this->assets->setAssets(source: 'local', header_css: ['css1', 'css2'], header_js: ['js1', 'js2'], footer_js: ['js3', 'js4']),
    //other keys...
];</code></pre>
                    
                    <p>The array keys in the header_css, header_js, and footer_js are "nicknames" of the assets. Meanwhile, the <em>source</em> can be either "local" or "cdn". You do not put full URLs here, but the nicknames. First, you need to register the assets in the <em>css.php</em> and <em>js.php</em> files in the <em>config</em> directory.</p>
                    <p>If there is no other assets to load but the default ones, just leave the arrays empty, except for the source.</p>
                    <div class="alert alert-info">
                        "local" means local assets stored in the <em>public/assets/css</em> and <em>public/assets/js</em> directories.
                    </div>
                    <p>Whenever you add new assets to your app, register them first.</p>

<pre><code class="language-php">&lt;?php
//config/css.php
//By default, local reads the file in public/assets/css directory

return [
    //other css registry
    'assetnickname' => [
        'local' => 'assetfilename.css', //if in subdirectory, dir/dir/assetfilename.css
        'cdn' => 'cdn URL of the asset',
        'default' => 'header' //or none
    ],
    //other css registry
];</code></pre>

<pre><code class="language-php">&lt;?php
//config/js.php
//By default, local reads the file in public/assets/js directory

return [
    //other js registry
    'assetnickname' => [
        'local' => 'assetfilename.js', //if in subdirectory, dir/dir/assetfilename.js
        'cdn' => 'cdn URL of the asset',
        'default' => 'header' //or footer or none,
        'type' => 'text/javascript', //or module
        'attributes' => '' // or defer
    ],
    //other js registry
];</code></pre>

                    <h3 class="text-black-50" id="litewire" style="scroll-margin-top: 200px;">Litewire</h3>
                    <p>Zap introduces to you <em>Litewire</em>, a partial blend of Livewire, HTMX, and AlpineJS. Litewire is as Livewire to Laravel, but Litewire can be used in any PHP frameworks.</p>
                    <p>Due to its vast coverage, it will be documented in another page.</p>
                    <h3 class="text-black-50" id="console" style="scroll-margin-top: 200px;">Command Line Interface (CLI)</h3>
                    <p>Zap has a simple <em>console</em> for making controllers, models, migrations, etc. This too, will be documented in another page.</p>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#getting-started').classList.add('text-success');
    </script>
@endpush