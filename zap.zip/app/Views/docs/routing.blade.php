@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                       <a class="nav-link p-0" href="#routing">Routing</a>
                        <a class="nav-link p-0" href="#http-methods">HTTP Methods</a>
                        <a class="nav-link p-0" href="#named-routes">Named Routes</a>
                        <a class="nav-link p-0" href="#middleware">Middleware</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>
                    <div id="routing" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Routing</h3>
                    <p>Routing is the process or mechanism inside a framework that inspects incoming HTTP requests and matches them against defined routes to invoke the appropriate code. Meanwhile, a route is a specific path definition that pairs a URL pattern and HTTP method with a destination action. It defines where a request should go.</p>
                    <p>The URL pattern of a route can be something like <em>/</em>, <em>/users/profile</em>, or <em>/posts/{id}</em>. Meanwhile, the HTTP method can be <em>GET</em>, <em>POST</em>, <em>PUT</em>, or <em>DELETE</em>.</p>
                    <p>As with other PHP frameworks, in Zap, a route defines a controller action, closure, or class method. For instance, when a <em>GET</em> request comes in for <em>/posts/5</em>, send this request to <code class="code">PostsController</code>@<code class="text-primary">show()</code> with ID=5.</p>
                    <p>In Zap, all routes are defined in the <em>/routes/web.php</em> file. Of course, you can add more routes file and require them in the <em>/public/index.php</em>. In the <em>/routes/web.php</em>, you can add new routes as follows:</p>

<pre><code class="language-php">Route::get('/login', 'AccountController@login')->name('account.login');</code></pre>

                    <p>In this example, <em>/login</em> is the path, <code class="code">AccountController</code>@<code class="text-primary">login()</code> means that the action or method is <code class="text-primary">login()</code> in the <code class="code">AccountController</code> class. Meanwhile, <em>account.login</em> is the route name (this is arbitrary name, but make sure that it is unique).</p>
                    <p>Two or more routes can have the same path, but they should have their own action. For instance:</p>

<pre><code class="language-php">Route::post('/login', 'AccountController@loginHandler')->name('account.loginHandler');</code></pre>

                    <p>If a single action method is used for different requests, the method will be messy and hard to maintain.</p>
                </div>

                <div id="http-methods" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">HTTP Request Methods</h3>
                    <p>An HTTP request can be GET, POST, PUT, or DELETE. Native HTML form, however, only supports GET and POST. Meanwhile, AJAX (e.g., native XHR or via jQuery.ajax) supports all.</p>
                    <p>In Zap, when native HTML form is used for PUT or DELETE, the actual method must be set to POST, while adding a hidden field named <em>_method</em> with the value of PUT or DELETE.</p>

<pre><code class="language-html">&lt;form action="@{{ route('update.user') }}"; method=&quot;post&quot;&gt;
    &lt;div class=&quot;form-floating mb-3&quot;&gt;
        &lt;input type=&quot;text&quot; name=&quot;user_fullname&quot; id=&quot;user_fullname&quot;/&gt;
        &lt;label for=&quot;user_fullname&quot;&gt;Fullname&lt;/label&gt;
    &lt;/div&gt;
    &lt;div class=&#39;form-floating mb-3&#39;&gt;
        &lt;input type=&quot;email&quot; name=&quot;email&quot; id=&quot;email/&gt;
        &lt;label for=&quot;email&quot;&gt;Email&lt;/label&gt;
    &lt;/div&gt;
    &lt;div class=&quot;mb-3&quot;&gt;
        &lt;input type=&quot;hidden&quot; name=&quot;userid&quot; value=&quot;@{{ $user['id'] }}&quot;/&gt;
        &lt;input type=&quot;hidden&quot; name=&quot;_method&quot; value=&quot;PUT&quot;/&gt;
        &lt;button type=&quot;submit&quot; class=&quot;btn btn-dark&quot;&gt;Update&lt;/button&gt;
    &lt;/div&gt;
&lt;/form&gt;</code></pre>

                    <p>In defining the route, you do not use <code class="text-primary">post()</code> but <code class="text-primary">put()</code>. For example:</p>

<pre><code class="language-php">Route::put('/user/update', 'UsersController@updateUser')->name('update.user');</code></pre>

                    <p>Then, in the controller method, you process the request just like POST requests.</p>
                </div>

                <div id="named-routes" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Named Routes</h3>
                    <p>Routes should be named by using <code class="text-primary">->name('routename')</code>, as you have seen above. Named routes are easier to call in the view, especially as the value of the <em>href</em> attribute. However, it is not required.</p>
                    <p>When a route name has been registered this way, you can use the helper <code class="text-primary">route('routename')</code> wherever you want in the app, except in using Litewire. In Litewire, you only use the path (e.g., <em>/user/update</em>) without the helper function.</p>
<pre><code class="language-html">&lt;!-- Using helper --&gt;
    &lt;a href="@{{ route('users.list') }}"&gt;List User&lt;/a&gt;

    &lt;!-- Using Litewire --&gt;
    &lt;div lw-get="/users/list" lw-trigger="load"&gt;&lt;/div&gt;</code></pre>

                    <p>Using route helper function in the Litewire will duplicate the full URL and trigger errors.</p>
                </div>
    
                <div id="middleware" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                    <h3 class="title">Middleware</h3>
                    <p>A middleware intercepts an HTTP request and evaluates the request against conditions or rules defined in it. For instance, particular routes may be restricted to only those who are logged in, while those who are not will not have access to the routes.</p>
                    <p>All middleware classes must be located in the <em>app/Middlewares</em> directory and use proper namespace. Every middleware class must also have a <code class="text-primary">handle()</code> method. This is an example of a middleware:</p>

<pre><code class="language-php">&lt;?php 
namespace Zap\App\Middlewares;
use Zap\Core\Http\Request;
use Zap\Core\Utils\SessionManager;
use Zap\Core\Utils\Container;
class GuestMiddleware {
 public function handle(Request $request, array $params, callable $next, string ...$roles) {
    $session = Container::getInstance()->make(SessionManager::class);
        if($session->has(config('app.session'))) {
            $loggedAccount = $session->get(config('app.session'));
            $route = $loggedAccount['account']['role'] . '.index';
            $this->go_to($route);
        }
        return $next($request, $params);
    }
    private function go_to(string $route) {
        header('location:'. route($route));
        exit;
    }
}</code></pre>
                <p>Then, each middleware must be registered in the <em>/bootstrap/app.php</em>.</p>

<pre><code class="language-php">&lt;?php
//bootstrap/app.php
use Zap\App\Middlewares\AuthMiddleware;
use Zap\Core\Routing\Router;
use Zap\Core\Routing\RouteFacade;
use Zap\App\Middlewares\GuestMiddleware;
$router = new Router();
// Register all middleware aliases here
$router->aliasMiddleware('guest', GuestMiddleware::class);
$router->aliasMiddleware('auth', AuthMiddleware::class);
RouteFacade::setRouter($router);
return $router;</code></pre>
               
                <p>As you can see, you create an <em>alias</em> for each middleware and use the alias in defining the route.</p>

<pre><code class="language-php">Route::get('/login', 'AccountController@login')->name('account.login')->middleware('guest');
Route::get('/users', 'AccountController@users')->name('account.users')->middleware('auth', ['admin']);</code></pre>
                </div>

            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#routing-page').classList.add('text-success');
    </script>
@endpush
