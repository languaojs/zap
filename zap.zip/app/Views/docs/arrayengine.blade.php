@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#instantiation">Instantiation</a>
                        <a class="nav-link p-0" href="#accessing-retrieving">Accessing and Retrieving Values</a>
                        <a class="nav-link p-0" href="#filtering-querying">Filtering and Querying Collections</a>
                        <a class="nav-link p-0" href="#inserting-pushing">Inserting and Pushing Data</a>
                        <a class="nav-link p-0" href="#transforming-mapping">Transforming and Mapping Elements</a>
                        <a class="nav-link p-0" href="#working-dot">Working with Dot-Notation</a>
                        <a class="nav-link p-0" href="#cleaning-sanitizing">Cleaning and Sanitizing Input Data</a>
                        <a class="nav-link p-0" href="#sorting-grouping-indexing">Sorting, Grouping, and Indexing Data</a>
                        <a class="nav-link p-0" href="#computing-statistics">Computing Aggregates Statistics</a>
                        <a class="nav-link p-0" href="#condition-validation">Checking Condition and Validation</a>
                        <a class="nav-link p-0" href="#slicing-splitting-chunking">Slicing, Splitting, and Chunking Arrays</a>
                        <a class="nav-link p-0" href="#exporting-resetting">Exporting and Resetting Internal State</a>
                        <a class="nav-link p-0" href="#misc-operations">Miscellaneous Operations</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="instantiation" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Instantiation</h3>
                        <p>The <code class="code">Zap\Core\Utils\ArrayEngine</code> class is a fluent utility wrapper designed to simplify array manipulation, filtering, and transformation in PHP. It encapsulates a native array property and provides an extensive chainable API for array operations—ranging from basic element access (<code class="text-primary">get()</code>, <code class="text-primary">has()</code>, <code class="text-primary">first()</code>, <code class="text-primary">last()</code>) and mutation (<code class="text-primary">push()</code>, <code class="text-primary">prepend()</code>, <code class="text-primary">merge()</code>, <code class="text-primary">sort()</code>, <code class="text-primary">except()</code>, <code class="text-primary">only()</code>) to functional utilities (<code class="text-primary">map()</code>, <code class="text-primary">filter()</code>, <code class="text-primary">reject()</code>, <code class="text-primary">reduce()</code>, <code class="text-primary">where()</code>) and specialized data formatting like dot-notation nesting (<code class="text-primary">dot()</code>, <code class="text-primary">undot()</code>, <code class="text-primary">getDot()</code>, <code class="text-primary">setDot()</code>), string sanitization (<code class="text-primary">escapeHtml()</code>, <code class="text-primary">trim()</code>), and data aggregation (<code class="text-primary">sum()</code>, <code class="text-primary">avg()</code>, <code class="text-primary">min()</code>, <code class="text-primary">max()</code>).</p>
                        
                        <p>To instantiate this utility class, you can either:</p>
                        <ul>
                            <li><span class="code">use</span> it as a class normally; or</li>
                            <li>Retrieve it using <code class="code">Container</code> as it has been registered to Container by default (see: <code class="text-secondary">/bootstrap/bindings.php</code>).</li>
                        </ul>

<pre><code class="language-php">use Zap\Core\Utils\ArrayEngine;
$ae = new ArrayEngine($array); //assuming that $array has been prepared before
$arrayData = $ae->all(); //all() returns the array</code></pre>
                        
                        <p>In the controller method, you can also inject it as a dependency.</p>

<pre><code class="language-php">use Zap\Core\Utils\ArrayEngine;
use Zap\Core\Utils\Container;

$ae = Container::getInstance()->make(ArrayEngine::class);
$arrayData = $ae->set($array)->all(); //set() sets the array to be processed later</code></pre>

                        <p>If using the first is more convenient for you, you can remove the binding in the <code class="text-secondary">bindings.php</code>. Once the class is instantiated, you can use it for various purposes.</p>
                    </div>


                    <div id="accessing-retrieving" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Accessing and Retrieving Values</h3>
                        <p>There are different ways to access and retrieve data from array using this utility class.</p>

<pre><code class="language-php">//basic key retrieval fallbacks
$status = $ae->get('status'); //returning the value of the key 'status'
$role = $ae->get('role', 'user'); //returning the value of the key 'role' if exists, or fallback to user if it does not exist

//fetching first and last item
$first = $ae->first();
$last = $ae->last();

//getting all keys or values only
$keys = $ae->keys()->all();
$values = $ae->values()->all();

//getting all values of specific keys from arrays
$userIds = $ae->pluck('id')->all();</code></pre>
                    </div>
                    <div id="filtering-querying" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Filtering and Querying Collections</h3>
                        <p><code class="code">ArrayEngine</code> can be used to filter and query collections. Here are some practical examples showing how to filter and query collection data using this utility.</p>
                        <p>First, you can use <code class="text-primary">where()</code> for loose equality checks or <code class="text-primary">whereStrict()</code> when strict type matching is required.</p>

<pre><code class="language-php">//let's use new data
$users = new ArrayEngine([
    ['name' => 'Alice', 'role' => 'admin', 'active' => 1],
    ['name' => 'Bob',   'role' => 'editor', 'active' => 0],
    ['name' => 'Charlie', 'role' => 'admin', 'active' => 0],
]);
// Loose equality check (matches active == 1)
$activeUsers = $users->where('active', true)->all();

// Strict equality check
$admins = $users->whereStrict('role', 'admin')->all();</code></pre>

                        <p>Second, you can filter data with whitelists and blacklists by using <code class="text-primary">whereIn()</code> or <code class="text-primary">whereNotIn()</code>.</p>

<pre><code class="language-php">$posts = new ArrayEngine([
    ['id' => 1, 'status' => 'draft'],
    ['id' => 2, 'status' => 'published'],
    ['id' => 3, 'status' => 'archived'],
]);

// Keep items where status matches draft or published
$visiblePosts = $posts->whereIn('status', ['draft', 'published'])->all();

// Exclude archived items
$activePosts = $posts->whereNotIn('status', ['archived'])->all();</code></pre>

                    <p>You can also use custom conditions for filtering and rejection. Use <code class="text-primary">filter()</code> to keep items that pass a callback condition, or <code class="text-primary">reject()</code> to remove items matching a condition.</p>

<pre><code class="language-php">$products = new ArrayEngine([
    ['title' => 'Keyboard', 'price' => 120, 'stock' => 15],
    ['title' => 'Mouse',    'price' => 45,  'stock' => 0],
    ['title' => 'Monitor',  'price' => 300, 'stock' => 8],
]);

// Keep items with price > 50
$expensive = $products->filter(fn($item) => $item['price'] > 50)->all();

// Reject items out of stock
$inStock = $products->reject(fn($item) => $item['stock'] === 0)->all();</code></pre>

                        <p>To find first matching element or key, you can use <code class="text-primary">find()</code> to retrieve the first matching value, or <code class="text-primary">findKey()</code> to obtain its corresponding array key.</p>

<pre><code class="language-php">$accounts = new ArrayEngine([
    'acc_1' => ['name' => 'Sarah', 'verified' => false],
    'acc_2' => ['name' => 'David', 'verified' => true],
]);

// Returns ['name' => 'David', 'verified' => true]
$firstVerified = $accounts->find(fn($item) => $item['verified']);

// Returns 'acc_2'
$verifiedKey = $accounts->findKey(fn($item) => $item['verified']);</code></pre>

                        <p>Finally, you can select or exclude specific keys by using <code class="text-primary">only()</code> or <code class="text-primary">except()</code> to filter dictionary keys in an associative array.</p>

<pre><code class="language-php">$payload = new ArrayEngine([
    'username' => 'johndoe',
    'password' => 'secret123',
    'email'    => 'john@example.com',
    'is_admin' => true,
]);

// Keep only specified keys
$profile = $payload->only(['username', 'email'])->all();

// Omit sensitive or restricted keys
$safePayload = $payload->except(['password', 'is_admin'])->all();</code></pre>

                    </div>
                    <div id="inserting-pushing" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Inserting and Pushing Data</h3>
                        <p>By using <code class="code">ArrayEngine</code>, you can easily insert, append, and merge data. You can use <code class="text-primary">add()</code> to append a sequential scalar value or assign a value to a specific associative key.</p>

<pre><code class="language-php">$engine = new ArrayEngine(['alpha']);

// Append sequential value
$engine->add('beta'); // ['alpha', 'beta']

// Assign to a explicit key
$engine->add('role', 'editor'); // ['alpha', 'beta', 'role' => 'editor']

$result = $engine->all();</code></pre>

                        <p>You can use <code class="text-primary">push()</code> with variadic arguments to append one or more elements to the end of the array.</p>

<pre><code class="language-php">$engine = new ArrayEngine(['Item 1']);

// Push multiple items in a single call
$result = $engine->push('Item 2', 'Item 3', 'Item 4')->all();
// ['Item 1', 'Item 2', 'Item 3', 'Item 4']</code></pre>

                        <p>You can use <code class="text-primary">prepend()</code> to insert a new element at the very start of the array, shifting numerical indexes forward.</p>

<pre><code class="language-php">$engine = new ArrayEngine(['second', 'third']);

// Insert 'first' at index 0
$result = $engine->prepend('first')->all();
// ['first', 'second', 'third']</code></pre>

                        <p>For merging arrays, use <code class="text-primary">merge()</code> to combine the current array with one or more external arrays. Numeric keys will be appended, while string keys with matching names will overwrite existing values.</p>

<pre><code class="language-php">$engine = new ArrayEngine([
    'theme' => 'light',
    'tags'  => ['php']
]);

// Merge with additional arrays
$result = $engine->merge(
    ['theme' => 'dark'],
    ['language' => 'en'], 
    ['tags' => ['framework', 'utility']]
)->all();
// Overwrites 'theme', Appends new 'language' key, Appends framework and utility to 'tags'</code></pre>

                        <p>Finally, you can use <code class="text-primary">replace()</code> to recursively update or substitute matching keys from another array without appending duplicates.</p>

<pre><code class="language-php">$engine = new ArrayEngine([
    'status' => 'pending',
    'attempts' => 1
]);

$result = $engine->replace([
    'status' => 'completed',
    'attempts' => 2
])->all();
</code></pre>
                    </div>
                    <div id="transforming-mapping" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Transforming and Mapping Elements</h3>
                        <p>Here are practical examples showing how to transform and map array contents using this utility class.</p>
                        <p>Use <code class="text-primary">map()</code> to transform every element in the array using a callback function.</p>

<pre><code class="language-php">$prices = new ArrayEngine([10, 20, 30]);

// Apply a 10% tax rate to all values
$taxedPrices = $prices->map(fn($price) => $price * 1.10)->all();
// [11.0, 22.0, 33.0]</code></pre>

                        <p>You can also iterate over elements by using <code class="text-primary">each()</code> to run a function over every item—including key and value—without modifying the array structure.</p>

<pre><code class="language-php">$logs = new ArrayEngine(['error' => 'Disk full', 'warning' => 'High memory']);

$logs->each(function ($message, $level) {
    // Perform side-effects (e.g., write to log file or output text)
    echo "[$level]: $message\n";
});</code></pre>

                        <p>You can also easily transform the case to lower or uppercase without having to iterate the entire array. Use <code class="text-primary">lowercase()</code> or <code class="text-primary">uppercase()</code> to recursively transform all string values within the array using multi-byte string operations.</p>

<pre><code class="language-php">$input = new ArrayEngine([
    'title' => 'Zap Framework',
    'tags'  => ['PHP', 'ROUTING']
]);

// Convert strings to lowercase
$lower = $input->lowercase()->all();
// ['title' => 'zap framework', 'tags' => ['php', 'routing']]

// Convert strings to uppercase
$upper = $input->uppercase()->all();
// ['title' => 'ZAP FRAMEWORK', 'tags' => ['PHP', 'ROUTING']]</code></pre>

                        <p>Use <code class="text-primary">reduce()</code> to iteratively reduce an array to a single value using a callback function and optional initial seed.</p>

<pre><code class="language-php">$cart = new ArrayEngine([
    ['item' => 'Book', 'price' => 15],
    ['item' => 'Pen',  'price' => 3],
]);

// Calculate cumulative price
$totalPrice = $cart->reduce(function ($carry, $item) {
    return $carry + $item['price'];
}, 0); 
// Returns 18 directly (Value-returning method)</code></pre>

                        <p>Finally, you can use <code class="text-primary">flip()</code> to swap all keys with their associated values.</p>

<pre><code class="language-php">$roles = new ArrayEngine([
    'admin' => 1,
    'editor' => 2,
]);

// Swap keys and values
$flipped = $roles->flip()->all();
// [1 => 'admin', 2 => 'editor']</code></pre>


                    </div>
                    <div id="working-dot" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Working with Dot-Notation</h3>
                        <p>Here are practical examples showing how to manipulate multi-dimensional arrays using dot-notation path operations with <code class="code">ArrayEngine</code>.</p>
                        <p>Use <code class="text-primary">dot()</code> to collapse multi-dimensional arrays into a single-level array where nested keys are joined by dots.</p>

<pre><code class="language-php">$config = new ArrayEngine([
    'database' => [
        'host' => '127.0.0.1',
        'credentials' => [
            'username' => 'root',
            'password' => 'secret'
        ]
    ]
]);

$dotted = $config->dot()->all();
/*
[
    'database.host' => '127.0.0.1',
    'database.credentials.username' => 'root',
    'database.credentials.password' => 'secret'
]
*/</code></pre>

                        <p>Use <code class="text-primary">undot()</code> to perform the reverse transformation, converting dot-notated keys back into full nested multi-dimensional arrays.</p>

<pre><code class="language-php">$flat = new ArrayEngine([
    'app.name' => 'Zap Framework',
    'app.environment' => 'production',
    'db.connections.mysql.host' => 'localhost'
]);

$nested = $flat->undot()->all();
/*
[
    'app' => [
        'name' => 'Zap Framework',
        'environment' => 'production'
    ],
    'db' => [
        'connections' => [
            'mysql' => [
                'host' => 'localhost'
            ]
        ]
    ]
]
*/</code></pre>

                        <p>Use <code class="text-primary">getDot()</code> to read values located deep within nested array structures using dot-separated key strings, with support for default fallbacks.</p>

<pre><code class="language-php">$settings = new ArrayEngine([
    'services' => [
        'mailgun' => [
            'domain' => 'mg.example.com',
            'secret' => 'key-12345'
        ]
    ]
]);

// Returns 'key-12345'
$secret = $settings->getDot('services.mailgun.secret');

// Returns 'smtp' fallback because key doesn't exist
$driver = $settings->getDot('services.driver', 'smtp');</code></pre>

                        <p>Use <code class="text-primary">setDot()</code> to update or insert values into nested positions inside the array structure without destroying existing surrounding keys.</p>

<pre><code class="language-php">$settings = new ArrayEngine([
    'app' => ['name' => 'Zap']
]);

// Set nested path dynamically
$settings->setDot('app.services.cache.driver', 'redis');

$result = $settings->all();
/*
[
    'app' => [
        'name' => 'Zap',
        'services' => [
            'cache' => [
                'driver' => 'redis'
            ]
        ]
    ]
]
*/</code></pre>

                        <p>Use <code class="text-primary">flatten()</code> to strip away all keys and collapse nested structures into a single flat list, or <code class="text-primary">collapse()</code> to reduce one level of array nesting.</p>

<pre><code class="language-php">$nestedList = new ArrayEngine([
    'fruits' => ['apple', 'banana'],
    'veggies' => ['carrot', ['spinach', 'kale']]
]);

// Collapse into a single flat numerical array
$flatList = $nestedList->flatten()->all();
// ['apple', 'banana', 'carrot', 'spinach', 'kale']
</code></pre>


                    </div>
                    <div id="cleaning-sanitizing" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Cleaning and Sanitizing Input Data</h3>
                        <p>Here are practical examples showing how to clean, sanitize, and remove empty or untrusted values using this class.</p>
                        <p>Use <code class="text-primary">trim()</code> to recursively strip leading and trailing whitespace from all string elements inside the array, including nested arrays.</p>

<pre><code class="language-php">$input = new ArrayEngine([
    'name' => '  Jane Doe  ',
    'bio'  => "  Software Developer\n  "
]);

$cleaned = $input->trim()->all();
// ['name' => 'Jane Doe', 'bio' => 'Software Developer']</code></pre>

                        <p>Use <code class="text-primary">sanitize()</code> to recursively strip HTML/PHP tags and trim all strings across the array structure.</p>

<pre><code class="language-php">$userInput = new ArrayEngine([
    'title'   => '  <h1>Welcome!</h1>  ',
    'comment' => '&lt;script&gt;alert("xss")&lt;/script&gt;Hello World'
]);

$safeInput = $userInput->sanitize()->all();
// ['title' => 'Welcome!', 'comment' => 'Hello World']</code></pre>

                        <p>Use <code class="text-primary">escapeHtml()</code> to recursively convert special characters to HTML entities (using <code class="code">ENT_QUOTES | ENT_SUBSTITUTE</code> by default) to prevent XSS vulnerabilities when rendering output.</p>

<pre><code class="language-php">$formData = new ArrayEngine([
    'bio'     => 'Me & You',
    'comment' => '&lt;script&gt;alert("xss")&lt;/script&gt;'
]);

$escaped = $formData->escapeHtml()->all();
// [
//     'bio' => 'Me & amp; You',
//     'comment' => '& lt;script& gt;alert(& quot;xss& quot;)& lt;/script& gt;'
// ]
//extra space is added for code render purpose.</code></pre>

                        <p>Use <code class="text-primary">filterNull()</code> to recursively remove all keys with <code>null</code> values while pruning any empty nested arrays left behind.</p>

<pre><code class="language-php">$data = new ArrayEngine([
    'id'       => 101,
    'nickname' => null,
    'profile'  => [
        'avatar' => null
    ]
]);

$filtered = $data->filterNull()->all();
// ['id' => 101]</code></pre>

                        <p>Use <code class="text-primary">filterEmpty()</code> to recursively remove null elements, empty strings ('' or whitespace-only), and nested arrays that end up completely empty.</p>

<pre><code class="language-php">$requestData = new ArrayEngine([
    'title'   => 'Zap Framework',
    'summary' => '   ',
    'tags'    => []
]);

$cleanData = $requestData->filterEmpty()->all();
// ['title' => 'Zap Framework']</code></pre>

                        <p>Use <code class="text-primary">filterFalsy()</code> to recursively purge all values evaluated as falsy in PHP (null, false, 0, "", []).</p>

<pre><code class="language-php">$flags = new ArrayEngine([
    'is_active' => true,
    'is_admin'  => false,
    'count'     => 0,
    'label'     => 'main'
]);

$activeFlags = $flags->filterFalsy()->all();
// ['is_active' => true, 'label' => 'main']</code></pre>


                    </div>
                    <div id="sorting-grouping-indexing" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Sorting, Grouping, and Indexing Data</h3>
                        <p>Here are practical examples showing how to sort, group, and re-index array collections using <code class="code">ArrayEngine</code></p>
                        <p>Use <code class="text-primary">groupBy()</code> to bucket array elements into sub-arrays based on a shared associative field name or a custom callback closure.</p>

<pre><code class="language-php">$employees = new ArrayEngine([
    ['name' => 'Alice',   'dept' => 'Engineering'],
    ['name' => 'Bob',     'dept' => 'Marketing'],
    ['name' => 'Charlie', 'dept' => 'Engineering'],
]);

// Group by string key
$byDept = $employees->groupBy('dept')->all();
/*
[
    'Engineering' => [
        ['name' => 'Alice', 'dept' => 'Engineering'],
        ['name' => 'Charlie', 'dept' => 'Engineering']
    ],
    'Marketing' => [
        ['name' => 'Bob', 'dept' => 'Marketing']
    ]
]
*/

// Group dynamically using a callback function
$byInitial = $employees->groupBy(fn($item) => $item['name'][0])->all();</code></pre>

                        <p>Use <code class="text-primary">keyBy()</code> to re-index an array of associative arrays using the value of a specified field as the primary key.</p>

<pre><code class="language-php">$products = new ArrayEngine([
    ['sku' => 'PROD-A', 'price' => 20],
    ['sku' => 'PROD-B', 'price' => 50],
]);

$indexedBySku = $products->keyBy('sku')->all();
/*
[
    'PROD-A' => ['sku' => 'PROD-A', 'price' => 20],
    'PROD-B' => ['sku' => 'PROD-B', 'price' => 50]
]
*/</code></pre>

                        <p>Use <code class="text-primary">sortBy()</code> or <code class="text-primary">sortDescBy()</code> to reorder an array of associative arrays based on a specified field's value.</p>

<pre><code class="language-php">$scores = new ArrayEngine([
    ['player' => 'Alex', 'points' => 350],
    ['player' => 'Sam',  'points' => 890],
    ['player' => 'John', 'points' => 120],
]);

// Sort ascending by points
$leaderboardAsc = $scores->sortBy('points')->all();

// Sort descending by points
$leaderboardDesc = $scores->sortDescBy('points')->all();</code></pre>

                        <p>Use <code class="text-primary">sort()</code>, <code class="text-primary">rsort()</code>, or <code class="text-primary">ksort()</code> to reorder simple arrays or sort associative array keys.</p>

<pre><code class="language-php">$numbers = new ArrayEngine([5, 2, 8, 1]);

// Standard ascending value sort
$ascending = $numbers->sort()->all(); // [1, 2, 5, 8]

// Reverse descending value sort
$descending = $numbers->rsort()->all(); // [8, 5, 2, 1]

$mapped = new ArrayEngine(['z' => 1, 'a' => 2, 'm' => 3]);

// Sort by associative keys
$keySorted = $mapped->ksort()->all(); // ['a' => 2, 'm' => 3, 'z' => 1]</code></pre>

                        <p>Use <code class="text-primary">shuffle()</code> to randomly reorder all elements within the array.</p>

<pre><code class="language-php">$cards = new ArrayEngine(['Ace', 'King', 'Queen', 'Jack']);
$shuffled = $cards->shuffle()->all();</code></pre>


                    </div>
                    <div id="computing-statistics" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Computing Aggregates Statistics</h3>
                        <p>Here are practical examples showing how to calculate aggregates, totals, and statistical summaries using <code class="code">ArrayEngine</code>.</p>
                        <div class="alert alert-info">
                            Note: All aggregate methods in this section return scalar values (int, float, or direct elements) directly, so you do not call <code class="text-primary fw-bold">all()</code> or <code class="text-primary fw-bold">final()</code> after them.
                        </div>

                        <p>Use <code class="text-primary">sum()</code> without parameters for simple numerical arrays, or pass a key name to total up a specific property across an array of associative arrays.</p>

<pre><code class="language-php">// Summing simple numeric values
$scores = new ArrayEngine([10, 20, 30, 40]);
$totalScore = $scores->sum(); // Returns 100

// Summing specific keys across records
$order = new ArrayEngine([
    ['item' => 'Widget A', 'price' => 29.99],
    ['item' => 'Widget B', 'price' => 15.00],
    ['item' => 'Widget C', 'price' => 5.00],
]);

$totalPrice = $order->sum('price'); // Returns 49.99</code></pre>

                        <p>Use <code class="text-primary">avg()</code> to compute the arithmetic mean of a flat numeric array or a targeted column in a collection. It automatically handles empty array checks to prevent division-by-zero errors.</p>

<pre><code class="language-php">$metrics = new ArrayEngine([
    ['response_time' => 120],
    ['response_time' => 80],
    ['response_time' => 250],
]);

// Returns 150.0
$averageTime = $metrics->avg('response_time');</code></pre>

                        <p>Use <code class="text-primary">min()</code> and <code class="text-primary">max()</code> to extract the lowest or highest scalar value from an array, or to evaluate specific record properties.</p>

<pre><code class="language-php">$temperatures = new ArrayEngine([22.5, 18.0, 31.2, 27.4]);

$lowest  = $temperatures->min(); // Returns 18.0
$highest = $temperatures->max(); // Returns 31.2

$employees = new ArrayEngine([
    ['name' => 'Alice', 'salary' => 75000],
    ['name' => 'Bob',   'salary' => 92000],
    ['name' => 'Carol', 'salary' => 64000],
]);

// Extract min/max values by column key
$minSalary = $employees->min('salary'); // Returns 64000
$maxSalary = $employees->max('salary'); // Returns 92000</code></pre>

                        <p>Use <code class="text-primary">count()</code> to quickly determine the total number of top-level elements in the collection.</p>

<pre><code class="language-php">$items = new ArrayEngine(['apple', 'banana', 'cherry']);

$totalItems = $items->count(); // Returns 3</code></pre>


                    </div>
                    <div id="condition-validation" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Checking Condition and Validation</h3>
                        <p>Here are practical examples showing how to validate array state and test condition callbacks using <code class="code">ArrayEngine</code>.</p>
                        <div class="alert alert-info">
                            Note: All methods in this section return boolean true or false directly, so you do not call <code class="text-primary">all()</code> or <code class="text-primary">final()</code> after them.
                        </div>
                        <p>Use <code class="text-primary">isEmpty()</code>, <code class="text-primary">has()</code>, or <code class="text-primary">contains()</code> to check if the collection is empty, whether a specific key exists, or if a value exists within the array.</p>

<pre><code class="language-php">$settings = new ArrayEngine(['theme' => 'dark', 'debug' => true]);

// Check if array has no elements
$empty = $settings->isEmpty(); // false

// Check key existence
$hasTheme = $settings->has('theme'); // true

// Check value existence (optional strict comparison flag)
$hasDark = $settings->contains('dark', strict: true); // true</code></pre>

                        <p>Use <code class="text-primary">every()</code> to determine if all elements in the array satisfy a given callback condition.</p>

<pre><code class="language-php">$users = new ArrayEngine([
    ['id' => 1, 'verified' => true],
    ['id' => 2, 'verified' => true],
    ['id' => 3, 'verified' => true],
]);

// Returns true only if ALL items pass the condition
$allVerified = $users->every(fn($user) => $user['verified'] === true); // true</code></pre>

                        <p>Use <code class="text-primary">some()</code> to verify if at least one element satisfies a given condition.</p>

<pre><code class="language-php">$orders = new ArrayEngine([
    ['id' => 101, 'status' => 'shipped'],
    ['id' => 102, 'status' => 'pending'],
    ['id' => 103, 'status' => 'shipped'],
]);

// Returns true if AT LEAST ONE item matches
$hasPending = $orders->some(fn($order) => $order['status'] === 'pending'); // true</code></pre>

                        <p>Use <code class="text-primary">none()</code> to confirm that no elements in the collection satisfy a condition.</p>

<pre><code class="language-php">$inventory = new ArrayEngine([
    ['sku' => 'A1', 'stock' => 5],
    ['sku' => 'B2', 'stock' => 12],
]);

// Returns true because NO item has stock equal to 0
$noneOutOfStock = $inventory->none(fn($item) => $item['stock'] === 0); // true</code></pre>

                        <p>Use <code class="text-primary">equal()</code> for loose structural equality checks or <code class="text-primary">identical()</code> for strict value and type comparisons against another array.</p>

<pre><code class="language-php">$a = new ArrayEngine(['id' => '10', 'role' => 'admin']);

// Loose check (equal content, loose type comparison)
$isEqual = $a->equal(['id' => 10, 'role' => 'admin']); // true

// Strict check (matching types required)
$isIdentical = $a->identical(['id' => 10, 'role' => 'admin']); // false</code></pre>


                    </div>
                    <div id="slicing-splitting-chunking" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Slicing, Splitting, and Chunking Arrays</h3>
                        <p>Here are practical examples showing how to slice, split, and chunk array collections using <code class="code">ArrayEngine</code>.</p>
                        <p>Use <code class="text-primary">slice()</code> to extract a specific subset of elements starting at an offset, optionally restricting the total length returned.</p>

<pre><code class="language-php">$items = new ArrayEngine(['a', 'b', 'c', 'd', 'e', 'f']);

// Extract 3 elements starting from index 2
$subset = $items->slice(2, 3)->all();
// ['c', 'd', 'e']</code></pre>

                        <p>Use <code class="text-primary">chunk()</code> to break a single array into multiple smaller arrays of a designated size.</p>
                        <div class="alert alert-info">
                            Note: <code class="text-primary">chunk()</code> returns a raw array of arrays directly, so you do not call <code class="text-primary">all()</code> or <code class="text-primary">final()</code> after it.
                        </div>

<pre><code class="language-php">$records = new ArrayEngine([1, 2, 3, 4, 5, 6, 7]);

// Split into arrays of at most 3 items
$batches = $records->chunk(3);
/*
[
    [1, 2, 3],
    [4, 5, 6],
    [7]
]
*/</code></pre>

                        <p>Use <code class="text-primary">partition()</code> to separate array elements into two distinct groups based on a truth test callback function. It returns a two-element array where index 0 contains items that passed the condition and index 1 contains items that failed.</p>

                        <div class="alert alert-info">
                            Note: Like <code class="text-primary">chunk()</code>, <code class="text-primary">partition()</code> returns an array pair directly, so <code class="text-primary">all()</code> or <code class="text-primary">final()</code> is not required.
                        </div>

<pre><code class="language-php">$numbers = new ArrayEngine([10, 15, 20, 25, 30]);

// Separate even numbers from odd numbers
[$evens, $odds] = $numbers->partition(fn($num) => $num % 2 === 0);

// $evens: [0 => 10, 2 => 20, 4 => 30]
// $odds:  [1 => 15, 3 => 25]</code></pre>

                    </div>
                    <div id="exporting-resetting" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Exporting and Resetting Internal State</h3>
                        <p>Here are practical examples showing how to export, clear, re-assign, and reset the internal state of <code class="code">ArrayEngine</code>.</p>
                        <p>Use <code class="text-primary">all()</code> or <code class="text-primary">final()</code> to finalize your method chain and extract the current internal PHP array state.</p>

<pre><code class="language-php">$engine = new ArrayEngine(['alpha', 'beta']);

$engine->push('gamma')->trim();

// Retrieve the underlying raw PHP array
$rawArray = $engine->all(); // ['alpha', 'beta', 'gamma']

// final() acts as an exact alias to all()
$finalArray = $engine->final(); // ['alpha', 'beta', 'gamma']</code></pre>

                        <p>Use <code class="text-primary">implode()</code> to convert array elements into a single glued string separated by a delimiter.</p>
                        <div class="alert alert-info">
                            Note: <code class="text-primary">implode()</code> returns a string directly, so you do not call <code class="text-primary">all()</code> or <code class="text-primary">final()</code> after it.
                        </div>

<pre><code class="language-php">$tags = new ArrayEngine(['php', 'framework', 'zap']);

// Returns 'php, framework, zap'
$tagString = $tags->implode(', ');</code></pre>

                        <p>Use <code class="text-primary">set()</code> to replace the entire internal array with a brand-new dataset while keeping the same <code class="code">ArrayEngine</code> instance.</p>

<pre><code class="language-php">$engine = new ArrayEngine(['initial' => 'data']);

// Re-assign internal state fluently
$engine->set([
    'user_id' => 42,
    'status'  => 'active'
]);

$data = $engine->all(); // ['user_id' => 42, 'status' => 'active']</code></pre>

                        <p>Use <code class="text-primary">clear()</code> to purge all elements from the array, resetting the internal state back to an empty array ([]).</p>

<pre><code class="language-php">$engine = new ArrayEngine(['temp_1', 'temp_2', 'temp_3']);

// Empties the array fluently
$emptyData = $engine->clear()->all(); // []</code></pre>


                    </div>
                    <div id="misc-operations" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Miscellaneous Operations</h3>
                        <p>Here are practical examples for the remaining Miscellaneous Operations using <code class="code">ArrayEngine</code>.</p>
                        <p>Use <code class="text-primary">removeKey()</code> to unset an element by its associative or numerical key, or <code class="text-primary">removeValue()</code> to filter out all occurrences of a specific value.</p>

<pre><code class="language-php">$payload = new ArrayEngine([
    'username' => 'johndoe',
    'password' => 'secret123',
    'status'   => 'draft',
    'type'     => 'draft'
]);

// Remove a specific key
$payload->removeKey('password');

// Remove all matching values (loose comparison by default)
$cleaned = $payload->removeValue('draft')->all();
// ['username' => 'johndoe']</code></pre>

                        <p>Use <code class="text-primary">search()</code> to locate the key of a given value.</p>
                        <div class="alert alert-info">
                            Note: <code class="text-primary">search()</code> returns the matching key or false directly, so <code class="text-primary">all()</code> or <code class="text-primary">final()</code> is not required.
                        </div>

<pre><code class="language-php">$roles = new ArrayEngine([
    'user_101' => 'admin',
    'user_102' => 'editor'
]);

// Returns 'user_101'
$adminKey = $roles->search('admin');

// Returns false
$guestKey = $roles->search('guest');</code></pre>

                        <p>Use <code class="text-primary">unique()</code> to strip duplicate values from the array, preserving original keys.</p>

<pre><code class="language-php">$tags = new ArrayEngine(['php', 'web', 'php', 'backend', 'web']);

$uniqueTags = $tags->unique()->all();
// ['php', 'web', 'backend']</code></pre>

                        <p>Use <code class="text-primary">diff()</code> to keep values not present in a given comparison array, or <code class="text-primary">intersect()</code> to retain only values common to both arrays.</p>

<pre><code class="language-php">$userPermissions = new ArrayEngine(['read', 'write', 'execute', 'delete']);

// Keep permissions NOT in the restricted list
$allowed = $userPermissions->diff(['execute', 'delete'])->all();
// ['read', 'write']

// Keep only permissions that overlap with the required set
$overlapping = $userPermissions->intersect(['read', 'export'])->all();
// ['read']</code></pre>

                        <p>Use <code class="text-primary">reverse()</code> to invert the order of elements in the array.</p>

<pre><code class="language-php">$steps = new ArrayEngine(['Step 1', 'Step 2', 'Step 3']);

$reversed = $steps->reverse()->all();
// ['Step 3', 'Step 2', 'Step 1']</code></pre>


                    </div>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#arrayengine-page').classList.add('text-success');
    </script>
@endpush