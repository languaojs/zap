@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#instantiating-validator">Instantiating Validator</a>
                        <a class="nav-link p-0" href="#retrieving-errors">Retrieving Errors</a>
                        <a class="nav-link p-0" href="#validation-passes">Validation Passes</a>
                        <a class="nav-link p-0" href="#supported-rules">Supported Validation Rules</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>
                    <div id="instantiating-validator" style="scroll-margin-top: 200px;" data-aos="fade"
                        data-aos-duration="1000">
                        <h3 class="title">Instantiating Validator</h3>
                        <p>The <code class="code">Validator</code> class is typically instantiated in the <code class="code">Controller</code>, particularly in a method that validates requests from HTML form or AJAX.</p>
                        <p>To instantiate this class using its <code class="text-primary">__construct()</code>, you need to prepare the <span class="code">data</span> and <span class="code">rules</span>.</p>

<pre><code class="language-php">use Zap\Core\Utils\Validator;
public function registration(Request $request){
$registrationData = $request->all();
$rules = [
    'username' => 'required|min:8',
    'email' => 'required|email'
];
$validator = new Validator($registrationData, $rules);
//rest of the code
}</code></pre>

                        <p>Alternatively, if the <code class="code">Validator</code> class is injected as a dependency in the method, use the <code class="text-primary">make()</code> method.</p>

<pre><code class="language-php">use Zap\Core\Utils\Validator;
public function registration(Request $request, Validator $validator){
$registrationData = $request->all();
$rules = [
   'username' => 'required|min:8',
   'email' => 'required|email'
];
$validator::make($registrationData, $rules);
//rest of the code
}</code></pre>

                    </div>

                    <div id="retrieving-errors" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Retrieving Errors</h3>
                        <p>Retrieving validation errors is useful to return error messages to frontend. However, the form fields in the frontend needs to have their "old" values, which can be done this way: <span class="code">value=@{{ $old['username'] ?? '' }}</span>. This <span class="code">$old</span> variable is of course sent from the controller method.</p>
                        <p>Assuming that the form action targets the same route with that renders the registration page, the routes may look like this:</p>

<pre><code class="language-php">Route::get('/registration', 'AccountController@registration')->name('account.registration.');
Route::post('/registration', 'AccountController@registration')->name('account.registration.');</code></pre>

                        <p>The full controller method, along with errors retrieval, may look like this:</p>

<pre><code class="language-php">public function registration(Request $request, Validator $validator) {
$data = [
        'assets' => $this->assets->setAssets(source: 'local'),
        '_title' => 'Registration',
        '_description' => "" ,
        '_robots' => 'index, follow',
        '_bodyClass' => 'bg-light',
        'navbar' => 'navbars.home-navbar',
        'footer' => 'footers.home-footer',
];

if(!$request->input('username')) {
    $html = $this->render('account/registration', $data);
    return $this->response($html);
}

$rules = [
    //rules...
];

$validator::make($request->all(), $rules);

if($validator->fails()){
    $data = [
        'errors' => $validator->errors(),
        'old' => $request->all()
    ];
    $html = $this->render('account/registration', $data);
    return $this->response($html);
}else{
    // rest of the logic
}

}</code></pre>

                        <p>Then, the blade view may look like this:</p>
<pre><code class="language-html">@@extend('layouts.base')
@@section('content')

&lt;form method=&quot;post&quot; action=&quot;@{{ route(account.registration) }}&quot;&gt;
    &lt;!-- other fields --&gt;
    &lt;input type=&quot;text&quot; name=&quot;username&quot; value=&quot;@{{ $old['username'] ?? '' }}&quot;/&gt;
    &lt;span class=&quot;d-block text-danger&quot;&gt;@{{ $errors['username'][0] ?? '' }}&lt;/span&gt;
    &lt;input type=&quot;email&quot; name=&quot;email&quot; value=&quot;@{{ $old['email'] ?? '' }}&quot;/&gt;
    &lt;span class=&quot;d-block text-danger&quot;&gt;@{{ $errors['email'][0] ?? '' }}&lt;/span&gt;
    &lt;!-- other fields --&gt;
&lt;/form&gt;

@@endsection 
@@push(scripts)
@@endpush</code></pre>

                        <p>If you want to check whether a specific field has validation error, uses <code class="text-primary">hasError(string $field)</code>. If you want to retrieve the first error message for a given field, use <code class="text-primary">first(string $field)</code>, which will return <code>null</code> if no error exists.</p>
                    </div>

                    <div id="validation-passes" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Validation Passes</h3>
                        <p>If validation passes or no error exists, all validated fields and their values can be retrieved by using the method <code class="text-primary">validated()</code>. The content it returns can then be processed further (e.g., adding record to database).</p>
<pre><code class="language-php">public function registration(Request $request, Validator $validator) {
 // existing code 
 $validData = $validator->validated();
 $results = $this->model('AccountModel')->createNewUser($validData);
 // rest of the code
}</code></pre>
                    </div>

                    <div id="supported-rules" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Supported Validation Rules</h3>
                        <p>Rules are applied per field by separating them with a vertical bar (|). Parameters are passed following a colon (:).</p>
                        <table class="table table-striped small">
                            <thead>
                                <tr>
                                    <th>Rule</th>
                                    <th>Parameter Example</th>
                                    <th>Description</th>
                                    <th>Example Error Message</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><span class="code">required</span></td>
                                    <td>N/A</td>
                                    <td>Ensures the field is present and not empty/null</td>
                                    <td><code>field is required</code></td>
                                </tr>
                                <tr>
                                    <td><span class="code">email</span></td>
                                    <td>N/A</td>
                                    <td>Validates format using <span class="code">FILTER_VALIDATE_EMAIL</span></td>
                                    <td><code>field must be a valid email</code></td>
                                </tr>
                                <tr>
                                    <td><span class="code">min</span></td>
                                    <td>min:8</td>
                                    <td>Ensures string length is at least the specified minimum.</td>
                                    <td><code>field must be at least 8 characters</code></td>
                                </tr>
                                <tr>
                                    <td><span class="code">max</span></td>
                                    <td>max:255</td>
                                    <td>Ensures the string length does not exceed the specified maximum</td>
                                    <td><code>field must not exceed 255 characters.</code></td>
                                </tr>
                                <tr>
                                    <td><span class="code">numeric</span></td>
                                    <td>N/A</td>
                                    <td>Checks whether the value is numeric or a numeric string.</td>
                                    <td><code>field must be numeric.</code></td>
                                </tr>
                                <tr>
                                    <td><span class="code">url</span></td>
                                    <td>N/A</td>
                                    <td>Validates URL format using PHP's <span class="code">FILTER_VALIDATE_URL</span>.
                                    </td>
                                    <td><code>field must be a valid URL.</code></td>
                                </tr>
                                <tr>
                                    <td><span class="code">boolean</span></td>
                                    <td>N/A</td>
                                    <td>Validates strict booleans (true/false) or integer/string equivalents (0, 1, '0',
                                        '1').</td>
                                    <td><code>field must be boolean.</code></td>
                                </tr>
                                <tr>
                                    <td><span class="code">in</span></td>
                                    <td>in:admin,user</td>
                                    <td>Ensures the value exists within a comma-separated list of allowed options.</td>
                                    <td><code>field must be one of: admin,user.</code></td>
                                </tr>
                                <tr>
                                    <td><span class="code">array</span></td>
                                    <td>N/A</td>
                                    <td>Validates that the input is an array type.</td>
                                    <td><code>field must be an array.</code></td>
                                </tr>
                                <tr>
                                    <td><span class="code">regex</span></td>
                                    <td>regex:/^[a-z0-9_-]+$/i</td>
                                    <td>Validates the string value against a custom Regular Expression pattern.</td>
                                    <td><code>field format is invalid.</code></td>
                                </tr>
                                <tr>
                                    <td><span class="code">confirmed</span></td>
                                    <td>N/A</td>
                                    <td>Checks if a matching <span class="code">{field}_confirmation</span> exists in the
                                        data and equals the field's value.</td>
                                    <td><code>field confirmation does not match.</code></td>
                                </tr>
                            </tbody>
                        </table>
                        <p>Use the <span class="code">confirmed</span> rule when the form data has fields like
                            <code>password</code> and <code>password_confirmation</code>. The rule may look like this:</p>

<pre><code class="language-php">$rules = [
    //other key-value pairs
    'password' => 'required|min:6|confirmed',
    //other key-valye pairs
];
</code></pre>

                        <p>Validator will check the second field with <code>_confirmation</code> and check whether the values are equal.</p>
                    </div>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#validator-page').classList.add('text-success');
    </script>
@endpush
