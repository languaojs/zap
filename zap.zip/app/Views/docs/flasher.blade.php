@extends('layouts.base')
@section('content')
    <main class="container-fluid">
        <article class="row">
            <section class="col-md-3">
                <div class="sticky-top text-secondary small p-3">
                    <p class="fw-bold"><i class="bi bi-list"></i> On this page</p>
                    <nav id="sidebar-nav" class="nav flex-column">
                        <a class="nav-link p-0" href="#setting-flasher">Setting Flasher</a>
                        <a class="nav-link p-0" href="#flashing">Flashing</a>
                        <a class="nav-link p-0" href="#client-side-flash">Client-side Flash</a>
                    </nav>
                </div>
            </section>
            <section class="col-md-7 h-100 overflow-auto" id="article-content">
                <div class="row my-3">
                    @include('components.docs-search', $routes)
                    <hr>

                    <div id="setting-flasher" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Setting Flasher</h3>
                        <p>Zap has a default simple <code class="code">Flasher</code> utility. The flasher has three settings, including the <code>type</code>, <code>title</code>, and <code>message</code>. Types include error, info, success, and warning.</p>
                        <p>Typically, <code class="code">Flasher</code> is instantiated in the controller, but it will depend on you; you can instantiate it in the model. If you want to instantiate and show the flash message in right in the view, you can use client-side flash method.</p>
                        <p>This is an example of how to instantiate <code class="code">Flasher</code> in the model or controller method:</p>

<pre><code class="language-php">use Zap\Core\Utils\Flasher;
$flasher = new Flasher;
$flasher->set('success', 'Registration', 'Your account has been confirmed!');</code></pre>
                    
                        <p>If in case you want to instantiate it in the view, you can do this:</p>

<pre><code class="language-php">@{!! service('Zap\Core\Utils\Flasher')->set('success', 'Registration', 'Your account has been confirmed!') !!}</code></pre>
                    
                        <p>Zap <code class="code">Flasher</code> uses session. When it is set, it registers a session, which will be unset automatically once the flasher fires.</p>

                        <div class="alert alert-warning">
                            flasher.css and flasher.js in the <em>/public/assets</em> folder are loaded as default assets. Thus, they should not be removed. If you wish to replace it with another flasher class, you need to unregister them in the <em>/config/css.php</em> and <em>/config/js.php</em>. Then, remove the flasher service from the base layout.
                        </div>
                    
                    </div>

                    <div id="flashing" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Flashing</h3>
                        <p>By default, the app checks if flasher session exists when the base layout loads.</p>
            
<pre><code class="language-php">@{!! service('Zap\Core\Utils\Flasher')->flash() !!}</code></pre>

                        <p>Thus, you do not have to fire it manually. If you replace Zap flasher with another flasher class, like said before, you should remove or comment this service in the base layout.</p>

                        <p>Once the flash fires, the flasher session will be automatically unset. The flasher also supports multiple flash messages. So, you can add as many flash messages as needed, but the firing is only once in the base layout.</p>
                        
                    </div>

                    <div id="client-side-flash" style="scroll-margin-top: 200px;" data-aos="fade" data-aos-duration="1000">
                        <h3 class="title">Client-side Flash</h3>
                        <p>Zap <code class="code">Flasher</code> class cannot dynamically trigger flash messages directly from client-side JavaScript actions. However, the <code class="code">flasher.js</code> can both process server-side flash messages on page load and allow you to trigger new ones via JavaScript at any time.</p>

                        <p>For instance, you can fire flash message directly using JavaScript based on the response of an AJAX request by doing this:</p>

<pre><code class="language-javascript">Flasher.show('success', 'Updated!', 'Profile settings saved');</code></pre>
                        
                        <p>Let's give it a try:</p>
                        <div class="col-sm-12 col-md-6">
                            <div class="form-floating mb-3">
                                <select id="flash-type" class="form-control">
                                    <option value="success">Success</option>
                                    <option value="info">Info</option>
                                    <option value="warning">Warning</option>
                                    <option value="error">Error</option>
                                </select>
                                <label for="flash-type">Flash Type</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" id="flash-title" class="form-control">
                                <label for="flash-title">Flash Title</label>
                            </div>
                            <div class="form-floating mb-3">
                                <textarea id="flash-message" class="form-control"></textarea>
                                <label for="flash-message">Flash Message</label>
                            </div>
                            <div class="mb-3">
                                <button type="button" class="btn btn-primary btn-sm" id="show-flash">Show Flash Message</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="col-md-2">
                <div class="sticky-top text-secondary small p-3">
                    @include('components.docs-links')
                </div>
            </section>
        </article>
    </main>
@endsection
@push('scripts')
    <script>
        document.querySelector('#flasher-page').classList.add('text-success');
        const showFlash = document.querySelector('#show-flash');

        showFlash.addEventListener('click', function(){
            const flashType = document.querySelector('#flash-type').value;
            const flashTitle = document.querySelector('#flash-title').value;
            const flashMessage = document.querySelector('#flash-message').value;

            if(flashTitle.length < 1 || flashMessage.length < 1) {
                Flasher.show('error', 'Flasher error', 'Please set all fields!');
            }else{
                Flasher.show(flashType, flashTitle, flashMessage);
            }
        });
    </script>
@endpush