<div id="form-wrapper">
    <form lw-post="/login" lw-target="#form-wrapper" lw-swap="outerHTML">
        <div class="form-group mb-2">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" class="form-control" value="{{ $old['name'] ?? '' }}">
            <span class="d-block text-danger">{{ $errors['name'][0] ?? '' }}</span>
        </div>

        <div class="form-group mb-2">
            <label for="email">Email</label>
            <input type="text" name="email" id="email" class="form-control" value="{{ $old['email'] ?? '' }}">
            <span class="d-block text-danger">{{ $errors['email'][0] ?? '' }}</span>
        </div>

        <button type="submit" class="btn btn-dark btn-sm">Submit</button>
        <span class="litewire-indicator" style="display: none;">Submitting</span>
    </form>
</div>
