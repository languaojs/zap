<div class="d-flex justify-content-between align-items-center py-3">
    <h4 class="text-black-50">{{ $docsTitle ?? 'Documentation' }}</h4>
    <div class="form-group">
        <input type="text" list="docsList" id="docsSearch" class="form-control" placeholder="Type to search..." autocomplete="off" data-routes="{{ json_encode($routerUrlMap) }}">
        
        <datalist id="docsList">
            @foreach ($routes as $routeName => $meta)
                <option value="{{ $meta['title'] }}">
                    {{-- Title &bull; {{ $meta['summary'] ?? 'Documentation' }} --}}
                    {{ $meta['title'] }} : {{ $meta['summary'] ?? 'Documentation' }}
                </option>

                {{-- Individual Keyword Suggestions --}}
                @if (!empty($meta['keywords']) && is_array($meta['keywords']))
                    @foreach ($meta['keywords'] as $keyword)
                        <option value="{{ $keyword }}">
                            {{ $keyword }}
                        </option>
                    @endforeach
                @endif
            @endforeach
        </datalist>

    </div>
    <nav class="nav">
        @if ($prev['title']!== 'None')         
            <a href="{{ $prev['route'] }}" class="nav-link"><i class="bi bi-arrow-left"></i> {{ $prev['title'] }}</a>            
        @endif

        @if ($next['title']!== 'None')
            <a href="{{ $next['route'] }}" class="nav-link">{{ $next['title'] }} <i class="bi bi-arrow-right"></i></a>
        @endif
    </nav>
</div>