
    <p class="fw-bold"><i class="bi bi-list"></i> Go To</p>
    <nav class="nav flex-column">
        <a href="{{ route('home.index') }}" class="nav-link p-0">Homepage</a>
        <a href="{{ route('docs.index') }}" class="nav-link p-0" id="getting-started">Getting Started</a>
        <a href="{{ route('docs.basic.configuration') }}" class="nav-link p-0" id="basic-configuration">Basic Configuration</a>
        <a href="{{ route('docs.routing') }}" class="nav-link p-0" id="routing-page">Routing</a>
        <span class="text-secondary my-2">UTILITIES</span>
        <a href="{{ route('docs.session') }}" class="nav-link p-0" id="session-manager-page">Session Manager</a>
        <a href="{{ route('docs.file') }}" class="nav-link p-0" id="file-page">File</a>
        <a href="{{ route('docs.security') }}" class="nav-link p-0" id="security-page">Security</a>
        <a href="{{ route('docs.validator') }}" class="nav-link p-0" id="validator-page">Validator</a>
        <a href="{{ route('docs.flasher') }}" class="nav-link p-0" id="flasher-page">Flasher</a>
        <a href="{{ route('docs.hasher') }}" class="nav-link p-0" id="hasher-page">Hasher</a>
        <a href="{{ route('docs.arrayengine') }}" class="nav-link p-0" id="arrayengine-page">Array Engine</a>
        <span class="text-secondary my-2">BATTERIES</span>
        <a href="{{ route('docs.database') }}" class="nav-link p-0" id="database-page">Database</a>
        <a href="{{ route('docs.cli') }}" class="nav-link p-0" id="cli-page">CLI</a>
        <a href="{{ route('docs.litewire') }}" class="nav-link p-0" id="litewire-page">Litewire</a>
        <a href="{{ route('docs.vite') }}" class="nav-link p-0" id="vite-page">Vite</a>
        <a href="{{ route('docs.assetsmanagement') }}" class="nav-link p-0" id="assets-management-page">Assets Management</a>
    </nav>
