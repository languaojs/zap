<footer class="docs-footer">
    <style>
        .docs-footer {
            margin-top: 5rem;
            padding: 2rem 0;
            color: #68756f;
            background: #f7f8f4;
            border-top: 1px solid #e6eae3;
            font-size: .875rem;
        }
        .docs-footer .footer-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1.5rem;
        }
        .docs-footer .footer-brand {
            display: inline-flex;
            align-items: center;
            gap: .65rem;
            color: #18221f;
            font-weight: 700;
            letter-spacing: -.02em;
            text-decoration: none;
        }
        .docs-footer .footer-mark {
            width: 2rem;
            height: 2rem;
            display: grid;
            place-items: center;
            color: #fff;
            background: #146c52;
            border-radius: .65rem;
            font-size: .8rem;
            letter-spacing: -.06em;
        }
        .docs-footer .footer-copy { margin: .35rem 0 0; }
        .docs-footer .footer-links {
            display: flex;
            align-items: center;
            gap: 1.4rem;
        }
        .docs-footer .footer-links a {
            color: #68756f;
            text-decoration: none;
            transition: color .15s ease;
        }
        .docs-footer .footer-links a:hover { color: #146c52; }
        @@media (max-width: 575.98px) {
            .docs-footer .footer-inner {
                align-items: flex-start;
                flex-direction: column;
                gap: 1rem;
            }
            .docs-footer .footer-links { gap: 1rem; }
        }
    </style>
    <div class="container">
        <div class="footer-inner">
            <div>
                <a class="footer-brand" href="{{ route('home.index') }}">
                    <span class="footer-mark" aria-hidden="true">Z</span>
                    <span>{{ config('app.short_name') }}</span>
                </a>
                <p class="footer-copy">&copy; {{ date('Y') }} {{ config('app.long_name') }}. All rights reserved.</p>
            </div>
            <nav class="footer-links" aria-label="Footer navigation">
                <a href="{{ route('docs.index') }}">Documentation</a>
                <a href="{{ route('home.index') }}">Home</a>
            </nav>
        </div>
    </div>
</footer>
