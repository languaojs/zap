@php
    $file = service('Zap\Core\Utils\File');
@endphp
<nav class="navbar navbar-expand-lg navbar-light sticky-top bg-white border-bottom mb-5" style="z-index: 999999">
    <div class="container py-4">
        <a class="navbar-brand text-green-500" href="{{ route('docs.index') }}">
            <img src="{{ $file->get_media('svgs/zap-logo.svg') }}" alt="Zap Logo" class="img-fluid"
                style="max-height: 70px;">
        </a>
        <button class="navbar-toggler shadow-none" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="bi bi-list"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" id="intro-page" href="{{ route('docs.index') }}"> Introduction</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="basic-configuration-page" href="{{ route('docs.basic.configuration') }}">Basic Configuration</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="routing-page" href="{{ route('docs.routing') }}">Routing</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="javascript:void(0);" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false" id="utilities-page">
                         Utilities
                    </a>
                    <ul class="dropdown-menu border-0 shadow">
                        <li>
                            <a class="dropdown-item small" href="{{ route('docs.session') }}"
                                id="util-session-page">
                                Session Manager
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item small" href="{{ route('docs.file') }}"
                                id="util-file-page">
                                File
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item small" href="{{ route('docs.security') }}"
                                id="util-security-page">
                                Security
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item small" href="{{ route('docs.validator') }}"
                                id="util-validator-page">
                                Validator
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item small" href="#"
                                id="util-flasher-page">
                                Flasher
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item small" href="#"
                                id="util-hasher-page">
                                Hasher
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item small" href="#"
                                id="util-array-engine-page">
                                Array Engine
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item small" href="#"
                                id="util-envy-page">
                                Envy
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="database-page" href="#">Database</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="litewire-page" href="#">Litewire</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="cli-page" href="#">CLI</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
