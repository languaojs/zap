export default class TaskList {
    constructor(element) {
        this.element = element;
        this.tasks = [];

        const heading = document.createElement('p');
        heading.className = 'mb-2';
        heading.textContent = 'Task list component';

        const form = document.createElement('form');
        form.className = 'd-flex gap-2';

        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'form-control';
        input.placeholder = 'Add a task';
        input.setAttribute('aria-label', 'New task');

        const addButton = document.createElement('button');
        addButton.type = 'submit';
        addButton.className = 'btn btn-primary';
        addButton.textContent = 'Add';

        const list = document.createElement('ul');
        list.className = 'list-group list-group-flush mt-3';
        list.setAttribute('aria-live', 'polite');

        const renderTasks = () => {
            list.replaceChildren();

            this.tasks.forEach((task, index) => {
                const item = document.createElement('li');
                item.className = 'list-group-item d-flex justify-content-between align-items-center px-0';

                const text = document.createElement('span');
                text.textContent = task;

                const removeButton = document.createElement('button');
                removeButton.type = 'button';
                removeButton.className = 'btn btn-sm btn-outline-danger';
                removeButton.textContent = 'Remove';
                removeButton.setAttribute('aria-label', `Remove ${task}`);
                removeButton.addEventListener('click', () => {
                    this.tasks.splice(index, 1);
                    renderTasks();
                });

                item.append(text, removeButton);
                list.append(item);
            });
        };

        form.addEventListener('submit', event => {
            event.preventDefault();

            const task = input.value.trim();
            if (!task) return;

            this.tasks.push(task);
            input.value = '';
            renderTasks();
            input.focus();
        });

        form.append(input, addButton);
        this.element.replaceChildren(heading, form, list);
    }
}
