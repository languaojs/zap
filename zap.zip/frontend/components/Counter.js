export default class Counter {
    constructor(element, params = {}) {
        const parsedStart = Number.parseInt(params.start ?? '0', 10);
        this.count = Number.isNaN(parsedStart) ? 0 : parsedStart;
        this.element = element;
        this.render();
    }

    render() {
        this.element.replaceChildren();

        const label = document.createElement('p');
        label.className = 'mb-2';
        label.textContent = 'Counter component';

        const controls = document.createElement('div');
        controls.className = 'd-flex align-items-center gap-2';

        const decrease = document.createElement('button');
        decrease.type = 'button';
        decrease.className = 'btn btn-outline-primary';
        decrease.textContent = '−';
        decrease.setAttribute('aria-label', 'Decrease count');
        decrease.addEventListener('click', () => {
            this.count -= 1;
            value.textContent = String(this.count);
        });

        const value = document.createElement('output');
        value.className = 'fw-bold';
        value.setAttribute('aria-live', 'polite');
        value.textContent = String(this.count);

        const increase = document.createElement('button');
        increase.type = 'button';
        increase.className = 'btn btn-outline-primary';
        increase.textContent = '+';
        increase.setAttribute('aria-label', 'Increase count');
        increase.addEventListener('click', () => {
            this.count += 1;
            value.textContent = String(this.count);
        });

        controls.append(decrease, value, increase);
        this.element.append(label, controls);
    }
}
