export default function imageUploader(element, data = {}) {
    const acceptAttribute = data.accept || 'image/*';
    element.innerHTML = /* html */ `
        <div class="card" style="width: 18rem;">
            <img
                src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIiB2aWV3Qm94PSIwIDAgMjAwIDIwMCI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0iI2VlZWVlZSIvPjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTYiIGZpbGw9IiM4ODg4ODgiIGRvbWluYW50LWJhc2VsaW5lPSJtaWRkbGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiPk5vIEltYWdlPC90ZXh0Pjwvc3ZnPg=="
                alt=""
                class="card-img-top"
                id="imgPreview"
                style="height: 200px; object-fit: cover; object-position: center;"
            >

            <div class="card-body">
                <form
                    action="${data.action || ''}"
                    method="post"
                    enctype="multipart/form-data"
                    id="imageForm"
                >
                    <input
                        type="file"
                        name="file"
                        id="file"
                        accept="${acceptAttribute}"
                        hidden
                    >

                    <div class="d-flex justify-content-between">
                        <p
                            class="small text-muted mb-0 text-truncate"
                            id="filename"
                            style="max-width: 150px;"
                        >
                            Select an image
                        </p>

                        <div id="buttons">
                            <label
                                for="file"
                                id="selectBtn"
                                style="cursor: pointer;"
                            >
                                <i class="bi bi-file-earmark-plus"></i>
                            </label>

                            <button
                                type="button"
                                class="btn btn-sm"
                                id="resetBtn"
                                style="cursor: pointer;"
                                hidden
                            >
                                <i class="bi bi-x-circle text-red-400"></i>
                            </button>

                            <button
                                type="submit"
                                class="btn btn-sm"
                                id="startUploadBtn"
                                style="cursor: pointer;"
                            >
                                <i class="bi bi-upload"></i>
                            </button>
                        </div>
                    </div>

                    <div
                        class="progress mt-2 mb-0 d-none"
                        id="upload-progress-container"
                    >
                        <div
                            id="upload-progress"
                            class="progress-bar"
                            role="progressbar"
                            style="width: 0%;"
                        >
                            0%
                        </div>
                    </div>
                </form>
            </div>
        </div>
    `;

    const fileInput = element.querySelector('#file');
    const filename = element.querySelector('#filename');
    const imagePreview = element.querySelector('#imgPreview');
    const selectButton = element.querySelector('#selectBtn');
    const resetButton = element.querySelector('#resetBtn');
    const imageForm = element.querySelector('#imageForm');
    const progressContainer = element.querySelector('#upload-progress-container');
    const progressBar = element.querySelector('#upload-progress');

    let previewUrl = null;

    fileInput.addEventListener('change', function () {
        const file = this.files[0];
        if (!file) return;

        filename.textContent = file.name;
        filename.title = file.name;

        if (previewUrl) {
            URL.revokeObjectURL(previewUrl);
        }

        previewUrl = URL.createObjectURL(file);
        imagePreview.src = previewUrl;

        selectButton.hidden = true;
        resetButton.hidden = false;
    });

    resetButton.addEventListener('click', function () {
        resetFileInput();
    });

    imageForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const file = fileInput.files[0];
        if (!file) return;

        progressContainer.classList.remove('d-none');
        progressBar.style.width = '0%';
        progressBar.textContent = '0%';

        const formData = new FormData();
        formData.append('file', file);
        if (data.maxsize) formData.append('maxsize', data.maxsize);
        if (data.uploadPath) formData.append('upload_path', data.uploadPath);
        if (data.fileName) formData.append('file_name', data.fileName);

        // Native Vanilla JS XMLHttpRequest with upload progress support (replacing $.ajax)
        const xhr = new XMLHttpRequest();
        xhr.open(imageForm.method.toUpperCase(), imageForm.action, true);

        // Attach CSRF Token if present
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
        if (csrfToken) {
            xhr.setRequestHeader('X-CSRF-TOKEN', csrfToken);
        }

        xhr.upload.addEventListener('progress', function (event) {
            if (!event.lengthComputable) return;

            const percent = Math.round((event.loaded / event.total) * 100);
            progressBar.style.width = `${percent}%`;
            progressBar.textContent = `${percent}%`;
        });

        xhr.onload = function () {
            let response;
            try {
                response = JSON.parse(xhr.responseText);
            } catch {
                response = { error: 'Invalid response format' };
            }

            if (xhr.status >= 200 && xhr.status < 300 && !response.error) {
                setProgressState('success');
                progressBar.textContent = 'Upload Complete';
                // console.log('Upload complete', response);
            } else {
                setProgressState('error');
                progressBar.textContent = response.error || 'Upload failed';
                // console.error('Upload failed', response);
            }
        };

        xhr.onerror = function () {
            setProgressState('error');
            progressBar.textContent = 'Network Error';
        };

        xhr.send(formData);
    });

    function resetFileInput() {
        const noImage =
            "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIiB2aWV3Qm94PSIwIDAgMjAwIDIwMCI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0iI2VlZWVlZSIvPjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTYiIGZpbGw9IiM4ODg4ODgiIGRvbWluYW50LWJhc2VsaW5lPSJtaWRkbGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiPk5vIEltYWdlPC90ZXh0Pjwvc3ZnPg==";

        filename.textContent = 'Select an image';
        filename.removeAttribute('title');
        imagePreview.src = noImage;
        fileInput.value = '';

        selectButton.hidden = false;
        resetButton.hidden = true;

        progressContainer.classList.add('d-none');
        progressBar.style.width = '0%';
        progressBar.textContent = '0%';

        if (previewUrl) {
            URL.revokeObjectURL(previewUrl);
            previewUrl = null;
        }
    }

    function setProgressState(state) {
        progressBar.classList.remove('bg-success', 'bg-danger', 'bg-warning');

        if (state === 'success') progressBar.classList.add('bg-success');
        if (state === 'error') progressBar.classList.add('bg-danger');
        if (state === 'warning') progressBar.classList.add('bg-warning');
    }
}