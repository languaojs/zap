export default class Greeting {
    constructor(element, params = {}) {
        this.element = element;
        this.name = params.name ?? '';

        const label = document.createElement('label');
        label.className = 'form-label';
        label.textContent = 'Enter a name';

        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'form-control';
        input.value = this.name;
        input.autocomplete = 'off';
        label.append(input);

        const greeting = document.createElement('p');
        greeting.className = 'mt-2 mb-0';
        greeting.setAttribute('aria-live', 'polite');

        const updateGreeting = () => {
            greeting.textContent = this.name
                ? `Hello, ${this.name}!`
                : 'Type your name to see a greeting.';
        };

        input.addEventListener('input', () => {
            this.name = input.value;
            updateGreeting();
        });

        this.element.replaceChildren(label, greeting);
        updateGreeting();
    }
}
