export function renderDashboard(element, data = {}) {
    element.innerHTML = `
        <div class="dashboard">
            <h1>Dashboard</h1>

            <p>Welcome, ${data.name} to your dashboard!</p>

            <button class="btn btn-primary" id="dashboardButton">
                Click Me
            </button>

            <p id="message"></p>
        </div>
    `;

    const button = element.querySelector("#dashboardButton");
    const message = element.querySelector("#message");

    button.addEventListener("click", () => {
        message.textContent = `Hello ${data.name}! You clicked the button.`;
    });
}