<?php

/**
 * ZAP
 * /routes/web.php
 * Define routes here
 */

use Zap\Core\Routing\RouteFacade as Route;



Route::get('/', 'HomeController@index')->name('home.index')->middleware('guest');
Route::post('/upload', 'HomeController@upload')->name('upload');
Route::get('/testphpx', 'HomeController@testPhpX')->name('testphpx');
Route::post('/testphpx', 'HomeController@testPhpX')->name('testphpx');
Route::get('/search', 'HomeController@search')->name('home.search');
Route::get('/search', 'HomeController@search')->name('home.search');
Route::get('/login', 'HomeController@login')->name('home.login');
Route::post('/login', 'HomeController@login')->name('home.login');


/**
 * Documentation routes
 */
Route::get('/docs', 'DocsController@index')->name('docs.index');
Route::get('/docs/basic-configuration', 'DocsController@basicConfiguration')->name('docs.basic.configuration');
Route::get('/docs/routing', 'DocsController@routing')->name('docs.routing');
Route::get('/docs/utils/session-manager', 'DocsController@sessionManager')->name('docs.session');
Route::get('/docs/utils/file', 'DocsController@file')->name('docs.file');
//File download route 
Route::get('/download', 'DocsController@download')->name('download');
Route::get('/docs/utils/security', 'DocsController@security')->name('docs.security');
Route::get('/docs/utils/validator', 'DocsController@validator')->name('docs.validator');
Route::get('/docs/utils/flasher', 'DocsController@flasher')->name('docs.flasher');
Route::get('/docs/utils/hasher', 'DocsController@hasher')->name('docs.hasher');
Route::get('/docs/utils/array-engine', 'DocsController@arrayEngine')->name('docs.arrayengine');
Route::get('/docs/database', 'DocsController@database')->name('docs.database');
Route::get('/docs/cli', 'DocsController@cli')->name('docs.cli');
Route::get('/docs/litewire', 'DocsController@litewire')->name('docs.litewire');
Route::get('/docs/vite', 'DocsController@vite')->name('docs.vite');
Route::get('/docs/assets-management', 'DocsController@assetsManagement')->name('docs.assetsmanagement');