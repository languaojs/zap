<?php
return array (
  'GET' => 
  array (
    0 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/',
       'action' => 'HomeController@index',
       'name' => 'home.index',
       'middleware' => 
      array (
        0 => 'guest',
      ),
       'compiledPattern' => '#^/$#',
       'parameterNames' => 
      array (
      ),
    )),
    1 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/testphpx',
       'action' => 'HomeController@testPhpX',
       'name' => 'testphpx',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/testphpx$#',
       'parameterNames' => 
      array (
      ),
    )),
    2 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/search',
       'action' => 'HomeController@search',
       'name' => 'home.search',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/search$#',
       'parameterNames' => 
      array (
      ),
    )),
    3 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/search',
       'action' => 'HomeController@search',
       'name' => 'home.search',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/search$#',
       'parameterNames' => 
      array (
      ),
    )),
    4 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/login',
       'action' => 'HomeController@login',
       'name' => 'home.login',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/login$#',
       'parameterNames' => 
      array (
      ),
    )),
    5 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs',
       'action' => 'DocsController@index',
       'name' => 'docs.index',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs$#',
       'parameterNames' => 
      array (
      ),
    )),
    6 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/basic-configuration',
       'action' => 'DocsController@basicConfiguration',
       'name' => 'docs.basic.configuration',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/basic-configuration$#',
       'parameterNames' => 
      array (
      ),
    )),
    7 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/routing',
       'action' => 'DocsController@routing',
       'name' => 'docs.routing',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/routing$#',
       'parameterNames' => 
      array (
      ),
    )),
    8 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/utils/session-manager',
       'action' => 'DocsController@sessionManager',
       'name' => 'docs.session',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/utils/session-manager$#',
       'parameterNames' => 
      array (
      ),
    )),
    9 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/utils/file',
       'action' => 'DocsController@file',
       'name' => 'docs.file',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/utils/file$#',
       'parameterNames' => 
      array (
      ),
    )),
    10 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/download',
       'action' => 'DocsController@download',
       'name' => 'download',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/download$#',
       'parameterNames' => 
      array (
      ),
    )),
    11 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/utils/security',
       'action' => 'DocsController@security',
       'name' => 'docs.security',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/utils/security$#',
       'parameterNames' => 
      array (
      ),
    )),
    12 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/utils/validator',
       'action' => 'DocsController@validator',
       'name' => 'docs.validator',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/utils/validator$#',
       'parameterNames' => 
      array (
      ),
    )),
    13 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/utils/flasher',
       'action' => 'DocsController@flasher',
       'name' => 'docs.flasher',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/utils/flasher$#',
       'parameterNames' => 
      array (
      ),
    )),
    14 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/utils/hasher',
       'action' => 'DocsController@hasher',
       'name' => 'docs.hasher',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/utils/hasher$#',
       'parameterNames' => 
      array (
      ),
    )),
    15 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/utils/array-engine',
       'action' => 'DocsController@arrayEngine',
       'name' => 'docs.arrayengine',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/utils/array-engine$#',
       'parameterNames' => 
      array (
      ),
    )),
    16 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/database',
       'action' => 'DocsController@database',
       'name' => 'docs.database',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/database$#',
       'parameterNames' => 
      array (
      ),
    )),
    17 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/cli',
       'action' => 'DocsController@cli',
       'name' => 'docs.cli',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/cli$#',
       'parameterNames' => 
      array (
      ),
    )),
    18 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/litewire',
       'action' => 'DocsController@litewire',
       'name' => 'docs.litewire',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/litewire$#',
       'parameterNames' => 
      array (
      ),
    )),
    19 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/vite',
       'action' => 'DocsController@vite',
       'name' => 'docs.vite',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/vite$#',
       'parameterNames' => 
      array (
      ),
    )),
    20 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'GET',
       'uri' => '/docs/assets-management',
       'action' => 'DocsController@assetsManagement',
       'name' => 'docs.assetsmanagement',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/docs/assets-management$#',
       'parameterNames' => 
      array (
      ),
    )),
  ),
  'POST' => 
  array (
    0 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'POST',
       'uri' => '/upload',
       'action' => 'HomeController@upload',
       'name' => 'upload',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/upload$#',
       'parameterNames' => 
      array (
      ),
    )),
    1 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'POST',
       'uri' => '/testphpx',
       'action' => 'HomeController@testPhpX',
       'name' => 'testphpx',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/testphpx$#',
       'parameterNames' => 
      array (
      ),
    )),
    2 => 
    \Zap\Core\Routing\Route::__set_state(array(
       'method' => 'POST',
       'uri' => '/login',
       'action' => 'HomeController@login',
       'name' => 'home.login',
       'middleware' => 
      array (
      ),
       'compiledPattern' => '#^/login$#',
       'parameterNames' => 
      array (
      ),
    )),
  ),
  'PUT' => 
  array (
  ),
  'DELETE' => 
  array (
  ),
);
