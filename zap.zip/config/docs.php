<?php 

return [
    'docs.routing' => [
        'title' => 'Routing',
        'keywords' => ['routes', 'routing', 'HTTP methods', 'named routes', 'middleware'],
        'summary' => 'Learn how to define custom static and dynamic URL routes.',
    ],
    'docs.session' => [
        'title' => 'Session Manager',
        'keywords' => ['starting session', 'adding session', 'getting session', 'updating session', 'destroying session'],
        'summary' => 'Learn how to manage session in the app.'
    ],
    'docs.file' => [
        'title' => 'File',
        'keywords' => ['listing files', 'get file content', 'writing file content', 'appending file content', 'deleting files', 'uploading files'],
        'summary' => 'Learn how to work with files.'
    ],
    'docs.basic.configuration' => [
        'title' => 'Basic Configuration',
        'keywords' => ['environment', '.env', 'base URL'],
        'summary' => 'Initial configuration of the app'
    ],
    'docs.security' => [
        'title' => 'Security',
        'keywords' => ['csrf token', 'CSRF', 'cross site resource forgery'],
        'summary' => 'Learn how to secure the app'
    ],
    'docs.validator' => [
        'title' => 'Validator',
        'keywords' => ['input validation', 'form validation', 'input rules'],
        'summary' => 'Learn how to validate input'
    ],
    'docs.flasher' => [
        'title' => 'Flasher',
        'keywords' => ['flash', 'flash message'],
        'summary' => 'Learn how to set and fire flash messages'
    ],
    'docs.hasher' => [
        'title' => 'Hasher',
        'keywords' => ['password', 'hash', 'verify hash', 'uuid'],
        'summary' => 'Learn how to generate and verify hashes'
    ],
    'docs.arrayengine' => [
        'title' => 'Array Engine',
        'keywords' => ['array', 'array operations', 'sanitizing data'],
        'summary' => 'Learn how to work with arrays'
    ],
    'docs.index' => [
        'title' => 'Getting Started',
        'keywords' => ['assets loading', 'controller', 'model'],
        'summary' => 'The basics'
    ],
    'docs.database' => [
        'title' => 'Database',
        'keywords' => ['database', 'CRUD', 'mysql', 'sqlite', 'schema', 'blueprint', 'query builder'],
        'summary' => 'Database operations'
    ],
    'docs.litewire' => [
        'title' => 'Litewire',
        'keywords' => ['AJAX', 'reactive state', 'components', 'directives', 'models'],
        'summary' => 'Build interactive interfaces with Litewire.'
    ]
];