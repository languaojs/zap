<?php 

$hasher = new \Zap\Core\Utils\Hasher;

return [
    'account' => [
        'username' => '1205038302',
        'email' => 'umangternate@gmail.com',
        'password_string' => 'admin',
        'password_hash' => $hasher->hash('admin'),
        'profile_table' => 'dosen',
        'role' => 'universitas',
        'role_str' => 'Admin Universitas'
    ],
    'profile' => [
        'nidn' => '1205038302',
        'fullname' => 'Zainurrahman',
        'front_degree' => 'Dr.',
        'back_degree' => 'M.Pd'
    ],
    'php_info' => [
        'max_execution_time' => ini_get('max_execution_time'),
        'post_max_size' => ini_get('post_max_size'),
        'memory_limit' => ini_get('memory_limit'),
        'upload_max_filesize' => ini_get('upload_max_filesize'),
        'max_input_time' => ini_get('max_input_time')
    ]
];