<?php 

return [
    'bootstrap' => [
        'local' => 'bootstrap.min.css',
        'cdn' => 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css',
        'default' => 'header',
    ],
    'icons' => [
        'local' => 'bootstrap-icons.min.css',
        'cdn' => 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css',
        'default' => 'none',
    ],
    'classless' => [
        'local' => 'classless.css',
        'cdn' => 'none',
        'default' => 'none',
    ],
    'flasher' => [
        'local' => 'flasher.css',
        'cdn' => 'none',
        'default' => 'header',
    ],
    'filepond' => [
        'local' => 'filepond.css',
        'cdn' => 'https://unpkg.com/filepond@4.32.12/dist/filepond.css',
        'default' => 'none',
    ],
    'swal' => [
        'local' => 'sweetalert2.min.css',
        'cdn' => 'https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.26.25/sweetalert2.css',
        'default' => 'none'
    ],
    'aos' => [
        'local' => 'aos.css',
        'cdn' => 'https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css',
        'default' => 'none',
    ],
    'atom' => [
        'local' => 'atom-one-dark.min.css',
        'cdn' => 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-dark.min.css',
        'default' => 'header'
    ],
    'main' => [
        'local' => 'main.css',
        'cdn' => 'none',
        'default' => 'header',
    ]
];