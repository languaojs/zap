<?php

return [
    'jquery' => [
        'local' => 'jquery.min.js',
        'cdn' => 'https://code.jquery.com/jquery-4.0.0.min.js',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => '',
    ],
    'bootstrap' => [
        'local' => 'bootstrap.bundle.min.js',
        'cdn' => 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js',
        'default' => 'footer',
        'type' => 'text/javascript',
        'attributes' => '',
    ],
    'tiny' => [
        'local' => 'tinymce/tinymce.min.js',
        'cdn' => 'none',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => '',
    ],
    'flasher' => [
        'local' => 'flasher.js',
        'cdn' => 'none',
        'default' => 'footer',
        'type' => 'text/javascript',
        'attributes' => '',
    ],
    'alpine-ajax' => [
        'local' => 'alpine-ajax.min.js',
        'cdn' => 'https://cdn.jsdelivr.net/npm/@imacrayon/alpine-ajax@0.12.7/dist/cdn.min.js',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => 'defer',
    ],
    'alpine' => [
        'local' => 'alpine.min.js',
        'cdn' => 'https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => 'defer',
    ],
    'htmx' => [
        'local' => 'htmx.min.js',
        'cdn' => 'https://unpkg.com/htmx.org@2.0.4',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => '',
    ],
    'filepond' => [
        'local' => 'filepond.js',
        'cdn' => 'https://unpkg.com/filepond@4.32.12/dist/filepond.js',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => '',
    ],
    'main' => [
        'local' => 'main.js',
        'cdn' => 'none',
        'default' => 'none',
        'type' => 'module',
        'attributes' => '',
    ],
    'swal' => [
        'local' => 'sweetalert2.all.min.js',
        'cdn' => 'https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.26.25/sweetalert2.all.js',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => '',
    ],
    'printer' => [
        'local' => 'printThis.js',
        'cdn' => 'none',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => 'defer'
    ],
    'litewire' => [
        'local' => 'litewire.min.js',
        'cdn' => 'none',
        'default' => 'none',
        'type' => 'module',
        'attributes' => 'defer'
    ],
    'litewire-auto-csrf-plugin' => [
        'local' => 'litewire-auto-csrf-plugin.js',
        'cdn' => 'none',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => ''
    ],
    'aos' => [
        'local' => 'aos.js',
        'cdn' => 'none',
        'default' => 'https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js',
        'type' => 'text/javascript',
        'attributes' => ''
    ],
    'highlightjs' => [
        'local' => 'highlight.min.js',
        'cdn' => 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js',
        'default' => 'footer',
        'type' => 'text/javascript',
        'attributes' => ''
    ],
    'docs' => [
        'local' => 'docs.js',
        'cdn' => 'none',
        'default' => 'none',
        'type' => 'text/javascript',
        'attributes' => ''
    ]
];