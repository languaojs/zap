<?php

namespace Zap\Core\Utils;

class SitemapGenerator
{
    private string $domain;
    private array $urls = [];

    private const ALLOWED_FREQUENCIES = [
        'always', 'hourly', 'daily', 'weekly', 'monthly', 'yearly', 'never'
    ];

    public function __construct(string $domain)
    {
        $this->domain = rtrim($domain, '/');
    }

    public function addUrl(
        string $path,
        ?string $lastModified = null,
        ?string $changeFreq = null,
        ?float $priority = null
    ): self {
        $path = '/' . ltrim($path, '/');
        $fullUrl = $this->domain . $path;

        if ($changeFreq !== null && !in_array(strtolower($changeFreq), self::ALLOWED_FREQUENCIES, true)) {
            throw new \InvalidArgumentException("Invalid change frequency: {$changeFreq}");
        }

        if ($priority !== null && ($priority < 0.0 || $priority > 1.0)) {
            throw new \InvalidArgumentException("Priority must be a float between 0.0 and 1.0.");
        }

        $formattedDate = null;
        if ($lastModified !== null) {
            $formattedDate = date('Y-m-d', strtotime($lastModified));
        }

        $this->urls[] = array_filter([
            'loc'        => $fullUrl,
            'lastmod'    => $formattedDate,
            'changefreq' => $changeFreq ? strtolower($changeFreq) : null,
            'priority'   => $priority !== null ? number_format($priority, 1, '.', '') : null,
        ], fn($value) => $value !== null);

        return $this;
    }

    /**
     * Structure array specifically for Response::arrayToXml compatibility.
     */
    public function toArray(): array
    {
        $data = [];

        foreach ($this->urls as $url) {
            // Nest each item under a 'url' key so arrayToXml uses <url> instead of <item>
            $data[] = ['url' => $url];
        }

        return $data;
    }

    public function generate(): string
    {
        $xml = new \SimpleXMLElement(
            '<?xml version="1.0" encoding="UTF-8"?>' .
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"/>'
        );

        foreach ($this->urls as $item) {
            $urlTag = $xml->addChild('url');
            foreach ($item as $key => $value) {
                $urlTag->addChild($key, htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8'));
            }
        }

        $dom = dom_import_simplexml($xml)->ownerDocument;
        $dom->formatOutput = true;
        return $dom->saveXML();
    }

    public function saveToFile(string $filePath): bool
    {
        $directory = dirname($filePath);

        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            throw new \RuntimeException("Directory '{$directory}' could not be created.");
        }

        $xmlContent = $this->generate();
        $result = file_put_contents($filePath, $xmlContent, LOCK_EX);

        if ($result === false) {
            throw new \RuntimeException("Failed to write sitemap to '{$filePath}'.");
        }

        return true;
    }
}